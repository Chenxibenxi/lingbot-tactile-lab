"""Explicit opt-in parameters for frozen-backbone contact VLA training."""

def configure_contact_training(policy):
    required=('model.tactile_adapter.','model.action_contact_head.')
    names=dict(policy.named_parameters())
    if any(not any(name.startswith(prefix) for name in names) for prefix in required):
        raise ValueError('both observation adapter and action-conditioned head required')
    for name,parameter in names.items():
        # Legacy unconditional head is unused by V3; exclude dead parameters.
        enabled=name.startswith(required) and not name.startswith('model.tactile_adapter.contact_head.')
        parameter.requires_grad_(enabled)
        parameter.grad=None
    groups=[]
    for prefix in required:
        chosen=[p for name,p in names.items() if name.startswith(prefix) and p.requires_grad]
        if not chosen:raise ValueError('empty contact training group')
        groups.append({'params':chosen,'name':prefix.removesuffix('.')})
    verify_contact_optimizer(policy,groups)
    return groups

def verify_contact_optimizer(policy,groups):
    selected=[p for group in groups for p in group['params']]
    if len(selected)!=len({id(p) for p in selected}):raise ValueError('duplicate optimizer parameter')
    expected={id(p) for name,p in policy.named_parameters() if p.requires_grad}
    actual={id(p) for p in selected}
    if actual!=expected:raise ValueError('optimizer must contain every and only trainable parameter')
    allowed=('model.tactile_adapter.','model.action_contact_head.')
    if any(p.requires_grad and not name.startswith(allowed) for name,p in policy.named_parameters()):
        raise ValueError('base parameters unexpectedly trainable')
    return {'trainable_parameters':sum(p.numel() for p in selected),'optimizer_parameter_tensors':len(selected)}
