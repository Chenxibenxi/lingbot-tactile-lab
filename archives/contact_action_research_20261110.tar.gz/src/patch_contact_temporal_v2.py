"""Isolated candidate-action auxiliary variant; preserve v1 and base checkpoints."""
from patch_contact_temporal_v1 import generate as generate_v1, SOURCE
from patch_model_v2 import once

def generate(source):
 s=generate_v1(source)
 s=once(s,'from contact_temporal_conditioner import ContactTemporalConditioner, insert_conditions, contact_auxiliary_loss','from contact_temporal_conditioner import ContactTemporalConditioner, insert_conditions, contact_auxiliary_loss\nfrom action_conditioned_contact import ActionConditionedContactHead')
 s=once(s,'        self.action_in_proj = nn.Linear(self.config.max_action_dim, self.config.proj_width)','        self.action_contact_head = (ActionConditionedContactHead(self.config.proj_width)\n                                    if getattr(self.config, "tactile_enabled", False) else None)\n        self.action_in_proj = nn.Linear(self.config.max_action_dim, self.config.proj_width)')
 s=once(s,'        contact_aux_weight=0.0,','        contact_aux_weight=0.0,\n        contact_candidate_actions=None,\n        contact_candidate_mask=None,')
 s=once(s,'            contact_aux = contact_auxiliary_loss(tactile_delta["contact_logits"], contact_targets, contact_target_mask)','''            if contact_candidate_actions is None or contact_candidate_mask is None:
                raise ValueError("future contact targets require explicit clean candidate actions")
            prediction = self.action_contact_head(tactile_delta, contact_candidate_actions, contact_candidate_mask)
            contact_aux = contact_auxiliary_loss(prediction["contact_logits"], contact_targets,
                                                  contact_target_mask & prediction["prediction_valid"])''')
 s=once(s,'            contact_aux_weight=kwargs.get("contact_aux_weight", 0.0),','''            contact_aux_weight=kwargs.get("contact_aux_weight", 0.0),
            contact_candidate_actions=kwargs.get("contact_candidate_actions"),
            contact_candidate_mask=kwargs.get("contact_candidate_mask"),''')
 compile(s,'contact_temporal_v2.py','exec')
 return s

if __name__=='__main__':
 from pathlib import Path
 out=Path(__file__).resolve().parents[1]/'work/contact_temporal_model_v2/modeling_lingbot_vla_v2.py'
 out.parent.mkdir(exist_ok=True)
 with out.open('x') as f:f.write(generate(SOURCE.read_text()))
 print(out)
