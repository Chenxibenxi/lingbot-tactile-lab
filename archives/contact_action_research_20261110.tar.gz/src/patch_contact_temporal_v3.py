"""Isolated v3: contact loss reduced outside action joint/padding weighting."""
from patch_contact_temporal_v2 import generate as generate_v2,SOURCE
from patch_model_v2 import once

def generate(source):
 s=generate_v2(source)
 s=once(s,'from action_conditioned_contact import ActionConditionedContactHead','from action_conditioned_contact import ActionConditionedContactHead\nfrom contact_loss_reduction import valid_contact_mean')
 s=once(s,'            losses = losses + contact_aux_weight * contact_aux[:, None, None]','            contact_valid = contact_target_mask & prediction["prediction_valid"]')
 s=once(s,'            moe_metrics["contact/aux_loss_batch_mean"] = contact_aux.detach().mean()', '''            contact_mean = valid_contact_mean(contact_aux, contact_valid)
            moe_metrics["contact/aux_loss_valid_mean"] = contact_mean.detach()
            moe_metrics["_contact_weighted_loss"] = contact_aux_weight * contact_mean''')
 s=once(s,'        loss_dict["batch_mean_losses"] = batch_mean_losses.detach()', '''        contact_loss = moe_metrics.pop("_contact_weighted_loss", 0.0) if moe_metrics else 0.0
        loss_dict["batch_mean_losses"] = batch_mean_losses.detach()''')
 s=once(s,'            loss_vla\n            + loss_depth','            loss_vla\n            + contact_loss\n            + loss_depth')
 compile(s,'contact_temporal_v3.py','exec');return s
if __name__=='__main__':
 from pathlib import Path
 p=Path(__file__).resolve().parents[1]/'work/contact_temporal_model_v3/modeling_lingbot_vla_v2.py';p.parent.mkdir(exist_ok=True)
 with p.open('x') as f:f.write(generate(SOURCE.read_text()))
 print(p)
