"""Candidate-action contact prediction; outputs never become policy input tokens.

Candidates are clean proposed commands for the NEXT 100 ms (5 x 20 ms).
Do not pass flow-matching noisy actions or label-only privileged geometry.
This optional head does not replace the VLA action loss.
"""
import torch
from torch import nn

class ActionConditionedContactHead(nn.Module):
    def __init__(self, width):
        super().__init__()
        self.action_encoder = nn.Sequential(nn.Linear(5 * 14, width), nn.SiLU())
        self.head = nn.Linear(2 * width, 5)

    def forward(self, observation, candidate_actions, action_mask):
        tokens, padding = observation['tokens'], observation['padding']
        b, _, width = tokens.shape
        if padding.shape != tokens.shape[:2] or padding.dtype != torch.bool:
            raise ValueError('observation token mask required')
        if candidate_actions.shape != (b, 5, 14) or action_mask.shape != (b, 5) or action_mask.dtype != torch.bool:
            raise ValueError('five clean 20ms candidate commands and boolean mask required')
        if not padding.any(-1).all():
            raise ValueError('empty observation')
        if not torch.isfinite(tokens[padding]).all() or not torch.isfinite(candidate_actions[action_mask]).all():
            raise ValueError('nonfinite valid inputs')
        grips = candidate_actions[action_mask][:, [6, 13]]
        if ((grips < 0) | (grips > 1)).any():
            raise ValueError('normalized gripper command required')
        dtype = self.head.weight.dtype
        pooled = torch.where(padding[..., None], tokens, 0).sum(1) / padding.sum(1, keepdim=True)
        actions = torch.where(action_mask[..., None], candidate_actions, 0).to(dtype)
        logits = self.head(torch.cat([pooled.to(dtype), self.action_encoder(actions.flatten(1))], -1))
        # Incomplete future commands cannot supervise the full 100ms horizon.
        return {'contact_logits': logits, 'prediction_valid': action_mask.all(-1)}
