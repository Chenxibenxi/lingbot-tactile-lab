"""Opt-in action group balancing; preserves invalid elements and total weight.

Use only for a separately declared supervision ablation. This changes the
objective, never the policy input or action target. Decisions must be identified
from the robot action contract, not from future outcomes on evaluation examples.
"""
import torch


def balanced_action_weights(valid_mask, decision_columns, decision_share=0.5):
    if valid_mask.ndim != 3 or valid_mask.numel()==0:
        raise ValueError('nonempty B,H,D validity mask required')
    if not torch.isfinite(valid_mask).all() or not ((valid_mask==0)|(valid_mask==1)).all():
        raise ValueError('binary validity mask required')
    if not 0 < decision_share < 1:
        raise ValueError('both action groups need positive weight')
    columns=list(decision_columns)
    if not columns or len(columns)!=len(set(columns)) or any(type(c) is not int or c<0 or c>=valid_mask.shape[-1] for c in columns):
        raise ValueError('unique valid decision columns required')
    valid=valid_mask.bool();decision=torch.zeros_like(valid);decision[:,:,columns]=valid[:,:,columns]
    remaining=valid & ~decision
    n=valid.sum((1,2),keepdim=True).float();a=decision.sum((1,2),keepdim=True).float();b=remaining.sum((1,2),keepdim=True).float()
    if (a==0).any() or (b==0).any():raise ValueError('both groups must have valid targets per example')
    return decision.float()*(n*decision_share/a)+remaining.float()*(n*(1-decision_share)/b)
