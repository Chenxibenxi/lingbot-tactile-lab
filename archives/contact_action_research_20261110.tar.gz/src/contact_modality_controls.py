"""Matched-architecture contact controls; change sensor payload only."""
import hashlib
import torch
TOUCH=('tactile_history','tactile_mask','tactile_age_ms','tactile_valid')

def observation_control(observation,mode,*,donor=None):
    out={k:v.clone() for k,v in observation.items()}
    if mode=='true':return out
    if mode=='zero':
        out['tactile_history'].zero_()  # preserve availability/age, test force content
    elif mode=='missing':
        out['tactile_history'].zero_();out['tactile_valid'].zero_();out['tactile_age_ms'].zero_()
    elif mode=='mismatch':
        if donor is None:raise ValueError('explicit independent training donor required')
        for key in TOUCH:
            if donor[key].shape!=observation[key].shape:raise ValueError('donor sensor shape mismatch')
            out[key]=donor[key].clone()
    else:raise ValueError('unknown modality control')
    return out

def training_donor_map(metadata):
    """Deterministic different-seed map, independent of outcomes/material labels.

    Entire donor episodes are precollected training data. Each donor payload must
    itself be a causal observation window. This is a training negative control,
    not a live cross-episode sensor or an evaluation policy.
    """
    if any(m['split']!='train' for m in metadata):raise ValueError('training-only donor pool')
    ids=[m['sample_id'] for m in metadata]
    if len(ids)!=len(set(ids)):raise ValueError('duplicate sample identity')
    mapping={}
    for m in metadata:
        choices=sorted(x['sample_id'] for x in metadata if x['seed']!=m['seed'])
        if not choices:raise ValueError('independent donor seed missing')
        index=int.from_bytes(hashlib.sha256(m['sample_id'].encode()).digest()[:8],'big')%len(choices)
        mapping[m['sample_id']]=choices[index]
    return mapping
