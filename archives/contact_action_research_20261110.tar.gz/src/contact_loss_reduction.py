"""Reduce contact supervision independently of action padding/joint counts."""
import torch

def valid_contact_mean(per_sample,valid):
    if per_sample.ndim!=1 or valid.shape!=per_sample.shape or valid.dtype!=torch.bool:
        raise ValueError('one loss and boolean validity per sample required')
    if not torch.isfinite(per_sample[valid]).all():raise ValueError('nonfinite valid contact loss')
    return torch.where(valid,per_sample,0).sum()/valid.sum().clamp(min=1)
