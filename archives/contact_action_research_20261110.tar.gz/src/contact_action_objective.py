"""Local preferred-action regression with a fixed reference ranking threshold.

Not DPO and not evidence of expert recovery. Reference rejected losses must be
cached before optimization using the same noise/time as the preferred loss.
No gradient or online worsening of rejected actions can lower this objective.
Independent held-out simulation is still required to measure learned behavior.
"""
import torch


def anchored_action_loss(preferred, reference_rejected, *, margin=0.0, ranking_weight=0.25):
    if preferred.ndim != 1 or reference_rejected.shape != preferred.shape:
        raise ValueError('one loss per pair with matching shapes required')
    if preferred.numel() == 0:
        raise ValueError('empty action batch')
    if reference_rejected.requires_grad:
        raise ValueError('reference losses must be frozen before optimization')
    if margin < 0 or ranking_weight < 0:
        raise ValueError('nonnegative objective coefficients required')
    if not torch.isfinite(preferred).all() or not torch.isfinite(reference_rejected).all():
        raise ValueError('finite action losses required')
    if (preferred < 0).any() or (reference_rejected < 0).any():
        raise ValueError('nonnegative regression losses required')
    regression = preferred.mean()
    ranking = torch.relu(preferred - reference_rejected.detach() + margin).mean()
    return regression + ranking_weight * ranking, {
        'preferred_regression': regression.detach(),
        'reference_ranking_penalty': ranking.detach(),
    }
