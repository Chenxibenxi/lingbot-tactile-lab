"""Opt-in observation tokens and contact head; no action targets enter encoder."""
import torch
from torch import nn

class ContactTemporalConditioner(nn.Module):
    def __init__(self,width):
        super().__init__()
        self.tactile=nn.Sequential(nn.Linear(17,width),nn.SiLU(),nn.Linear(width,width))
        self.proprio=nn.Linear(32,width)
        self.history=nn.Linear(14,width)
        self.time_embedding=nn.Parameter(torch.randn(5,width)*.01)
        self.history_embedding=nn.Parameter(torch.randn(4,width)*.01)
        self.contact_head=nn.Linear(width,5)

    def forward(self,tactile,mask,age_ms,valid,proprio,history,history_mask):
        b=tactile.shape[0]
        shapes=[(tactile,(b,5,4,3)),(mask,(b,5,4)),(age_ms,(b,)),(valid,(b,)),(proprio,(b,32)),(history,(b,4,14)),(history_mask,(b,4))]
        if any(tuple(x.shape)!=shape for x,shape in shapes):raise ValueError('observation condition shape mismatch')
        if valid.dtype!=torch.bool or history_mask.dtype!=torch.bool:raise ValueError('explicit boolean validity masks required')
        if not torch.isfinite(proprio).all() or not torch.isfinite(mask).all() or ((mask<0)|(mask>1)).any():raise ValueError('invalid measured inputs')
        # Invalid sensor/history bytes have no effect, including NaN payloads.
        selected=tactile[valid]
        if not torch.isfinite(selected).all() or (selected<0).any() or not torch.isfinite(age_ms[valid]).all() or (age_ms[valid]<0).any():raise ValueError('invalid valid tactile sample')
        if not torch.isfinite(history[history_mask]).all():raise ValueError('invalid valid history')
        dtype=self.proprio.weight.dtype
        tactile=torch.where(valid[:,None,None,None],tactile,0).to(dtype)
        # Fixed physical-feature transform; no fitting on validation/test.
        features=torch.cat([torch.log1p(tactile[...,:2]),tactile[...,2:]],dim=-1).flatten(2)
        ages=torch.where(valid,age_ms,0).to(dtype)[:,None,None].expand(-1,5,1)/1000
        touch=self.tactile(torch.cat([features,mask.to(dtype),ages],dim=-1))+self.time_embedding[None]
        touch_mask=valid[:,None]&(mask.min(-1).values>0)
        touch=torch.where(touch_mask[:,:,None],touch,0)
        actual=self.proprio(proprio.to(dtype))[:,None]
        hist=self.history(torch.where(history_mask[:,:,None],history,0).to(dtype))+self.history_embedding[None]
        hist=torch.where(history_mask[:,:,None],hist,0)
        tokens=torch.cat([actual,touch,hist],dim=1)
        padding=torch.cat([torch.ones((b,1),device=valid.device,dtype=torch.bool),touch_mask,history_mask],dim=1)
        pooled=tokens.sum(1)/padding.sum(1,keepdim=True)
        return {'tokens':tokens,'padding':padding,'contact_logits':self.contact_head(pooled)}

def insert_conditions(embeddings,padding,attention,condition):
    if condition is None:return embeddings,padding,attention
    tokens=condition['tokens'].to(embeddings.dtype);valid=condition['padding']
    if tokens.shape[0]!=embeddings.shape[0] or tokens.shape[2]!=embeddings.shape[2] or valid.shape!=tokens.shape[:2]:raise ValueError('condition/suffix mismatch')
    # State and all past-observation tokens share a block; first action starts
    # the next block. Thus conditioning cannot read the noisy action targets.
    return (torch.cat([embeddings[:,:1],tokens,embeddings[:,1:]],dim=1),
            torch.cat([padding[:,:1],valid,padding[:,1:]],dim=1),
            torch.cat([attention[:,:1],torch.zeros_like(valid),attention[:,1:]],dim=1))

def contact_auxiliary_loss(logits,targets,valid):
    if targets.shape!=logits.shape or valid.shape!=logits.shape[:1] or valid.dtype!=torch.bool:raise ValueError('auxiliary target shape/mask mismatch')
    selected=targets[valid]
    if not torch.isfinite(selected).all() or (selected<0).any() or not torch.allclose(selected.sum(-1),torch.ones_like(selected.sum(-1)),atol=1e-5):raise ValueError('valid targets must be probability distributions')
    safe=torch.where(valid[:,None],targets,0).to(logits.dtype)
    per_sample=-(safe*torch.log_softmax(logits,dim=-1)).sum(-1)
    return per_sample*valid.to(logits.dtype)
