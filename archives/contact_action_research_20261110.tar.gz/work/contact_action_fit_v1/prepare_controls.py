import hashlib,json
from pathlib import Path
R=Path('/mnt/relaydata/lingbot-tactile-lab')
base=(R/'work/contact_action_fit_v1/run.py').read_text()
for mode in ('missing','zero','mismatch'):
 name='contact_action_fit_'+mode+'_v1';w=R/'work'/name;w.mkdir(exist_ok=False)
 script=base.replace('contact_action_fit_v1',name)
 script=script.replace('from contact_action_objective import anchored_action_loss','from contact_action_objective import anchored_action_loss\nfrom contact_modality_controls import observation_control, training_donor_map')
 script=script.replace(' def forward(index,preferred,noise):', " metadata=[dict(sample_id=str(i),seed=p['metadata']['seed'],split='train') for i,p in enumerate(pairs)]\n donors=training_donor_map(metadata)\n def forward(index,preferred,noise):")
 script=script.replace("  args={k:v.cuda() for k,v in x['contact']['observation'].items()}","  donor_pair=pairs[int(donors[str(index)])]\n  donor=donor_pair['candidates'][donor_pair['preferred']]['contact']['observation']\n  controlled=observation_control(x['contact']['observation'],"+repr(mode)+",donor=donor)\n  args={k:v.cuda() for k,v in controlled.items()}")
 script=script.replace("scope='two training seeds", "modality="+repr(mode)+",scope='two training seeds")
 script=script.replace('# VLA局部动作学习首轮','# VLA局部动作学习对照：'+mode)
 (w/'run.py').write_text(script)
 manifest=json.loads((R/'work/contact_action_fit_v1/manifest.json').read_text());manifest['modality']=mode
 del manifest['files']['work/contact_action_fit_v1/run.py']
 for path in ['work/'+name+'/run.py','src/contact_modality_controls.py']:
  manifest['files'][path]=hashlib.sha256((R/path).read_bytes()).hexdigest()
 (w/'manifest.json').write_text(json.dumps(manifest,indent=2))
 (w/'run.sh').write_text((R/'work/contact_action_fit_v1/run.sh').read_text().replace('contact_action_fit_v1',name))
print('Prepared three matched 8-step controls; not started')
