import json,subprocess,time
from pathlib import Path
R=Path('/mnt/relaydata/lingbot-tactile-lab');W=R/'work/contact_action_fit_v1'
first=json.loads((R/'data/reports/contact_action_fit_v1/result.json').read_text());assert first['status']=='completed' and first['optimizer_steps']==8
results={'true':first};status='failed'
try:
 for mode in ('missing','zero','mismatch'):
  name='contact_action_fit_'+mode+'_v1';w=R/'work'/name
  with (w/'run.log').open('xb') as out:
   p=subprocess.run(['bash',str(w/'run.sh')],stdout=out,stderr=subprocess.STDOUT,cwd=R)
  assert p.returncode==0,(mode,p.returncode)
  result=json.loads((R/'data/reports'/name/'result.json').read_text());assert result['status']=='completed' and result['optimizer_steps']==8
  results[mode]=result
 status='completed'
finally:
 o=R/'data/reports/contact_action_fit_controls_v1';o.mkdir(exist_ok=False)
 (o/'result.json').write_text(json.dumps(dict(status=status,results=results),indent=2))
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 fig,ax=plt.subplots(figsize=(8,4))
 for mode,r in results.items():ax.plot([x['step'] for x in r['rows']],[x['action_loss'] for x in r['rows']],marker='.',label=mode)
 ax.legend();ax.set(xlabel='Optimizer step (different sample/noise)',ylabel='Training action loss');fig.tight_layout();fig.savefig(o/'loss.png',dpi=150)
 (o/'report.md').write_text('# 同预算触觉输入训练能力对照\n\n各组相同初始化种子、四决策、噪声、8步、batch=1及学习率，只改变触觉输入。冻结参考误差在各组自身初始化模型上计算；不是同一个数值阈值。跨seed供体由独立于结果标签的固定映射选取。主干冻结，各组保存新模块检查点。\n\n![loss](loss.png)\n\n训练曲线混合不同样本与噪声，不能解读为逐步收敛或触觉因果提升；仅检验优化过程。尚须统一固定噪声前后测、独立seed仿真和动作延迟评测。\n\n状态：'+status+'\n')
