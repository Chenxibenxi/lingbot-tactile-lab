import json,time,subprocess
from pathlib import Path
R=Path('/mnt/relaydata/lingbot-tactile-lab');W=R/'work/contact_action_intervention_v1';p=json.loads((R/'work/contact_action_budget128_v1/process.json').read_text())
for _ in range(400):
 f=Path(f"/proc/{p['pid']}/stat")
 if not f.exists():break
 parts=f.read_text().split()
 if parts[21]!=p['start_ticks'] or parts[2]=='Z':break
 time.sleep(5)
else:raise RuntimeError('prior batch still running')
s=json.loads((R/'data/reports/contact_action_budget128_v1/status.json').read_text());assert s['status']=='completed'
with (W/'run.log').open('xb') as out:
 p=subprocess.run(['bash',str(W/'run.sh')],stdout=out,stderr=subprocess.STDOUT,cwd=R)
assert p.returncode==0
subprocess.run(['/mnt/relaydata/lingbot/conda/envs/lingbot-eval310/bin/python',str(W/'analyze.py')],check=True)
