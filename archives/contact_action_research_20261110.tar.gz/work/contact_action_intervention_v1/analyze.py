import json
from pathlib import Path
import torch
R=Path('/mnt/relaydata/lingbot-tactile-lab');O=R/'data/reports/contact_action_intervention_v1';a=torch.load(O/'normalized_actions.pt',map_location='cpu',weights_only=False);rows=[]
for stage in ('before','after'):
 for mode in ('missing','zero','mismatch'):
  for i in range(4):
   delta=a[mode,stage,i]-a['true',stage,i]
   rows.append(dict(stage=stage,intervention=mode,pair=i,right_gripper_mean_abs_delta=float(delta[:,:,29].abs().mean()),right_gripper_max_abs_delta=float(delta[:,:,29].abs().max()),bitwise_identical=torch.equal(a[mode,stage,i],a['true',stage,i])))
(O/'intervention_deltas.json').write_text(json.dumps(rows,indent=2))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,ax=plt.subplots(figsize=(8,4))
for mode in ('missing','zero','mismatch'):
 ax.plot(['before','after'],[sum(x['right_gripper_mean_abs_delta'] for x in rows if x['stage']==s and x['intervention']==mode)/4 for s in ('before','after')],marker='o',label=mode)
ax.legend();ax.set_ylabel('Right gripper normalized action change');fig.tight_layout();fig.savefig(O/'intervention.png',dpi=150)
with (O/'report.md').open('a') as f:f.write('\n\n## 同参数触觉干预差异\n\n![intervention](intervention.png)\n\n替换触觉可能形成物理上不一致输入，只衡量模型敏感性，不证明触觉对成功有益。缺失控制会改变有效token数量；置零与错配用于辅助区分内容和可用性。\n\n```json\n'+json.dumps(rows,indent=2)+'\n```\n')
