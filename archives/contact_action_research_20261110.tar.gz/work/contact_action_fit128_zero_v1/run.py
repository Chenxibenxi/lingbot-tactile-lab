import json,time,hashlib
from pathlib import Path
import torch
import run_cwmj_m7_training as b
from contact_temporal_conditioner import ContactTemporalConditioner
from action_conditioned_contact import ActionConditionedContactHead
from contact_trainable_parameters import configure_contact_training
from contact_action_objective import anchored_action_loss
from contact_modality_controls import observation_control, training_donor_map
R=b.REPO;W=R/'work/contact_action_fit128_zero_v1';O=R/'data/reports/contact_action_fit128_zero_v1';O.mkdir(exist_ok=False)
rows=[];start=time.time();status='failed';error=None
try:
 manifest=json.loads((W/'manifest.json').read_text())
 for path,digest in manifest['files'].items():assert hashlib.sha256((R/path).read_bytes()).hexdigest()==digest,path
 b.require_reproducibility_gate();b.require_gpu_window();_,_,weights=b.verify_fixed_inputs(R)
 from lingbotvla.models.vla.lingbot_vla.qwen3vl_in_vla import apply_lingbot_qwen3_vl_patch
 apply_lingbot_qwen3_vl_patch();torch.manual_seed(17011)
 cfg=b.build_old_config();cfg.use_cache=False;cfg.num_steps=2
 model,proof=b.load_model(cfg,R/'work/contact_temporal_model_v3/modeling_lingbot_vla_v2.py',weights)
 model.model.tactile_adapter=ContactTemporalConditioner(cfg.proj_width).float().cuda()
 model.model.action_contact_head=ActionConditionedContactHead(cfg.proj_width).float().cuda()
 optimizer=torch.optim.AdamW(configure_contact_training(model),lr=1e-4)
 model.train()
 D=R/'data/reports/contact_action_training_batches_v1';summary=json.loads((D/'summary.json').read_text());pairs=[]
 for row in summary['pairs']:
  path=D/row['tensor_file'];assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256']
  pairs.append(torch.load(path,map_location='cpu',weights_only=False))
 metadata=[dict(sample_id=str(i),seed=p['metadata']['seed'],split='train') for i,p in enumerate(pairs)]
 donors=training_donor_map(metadata)
 def forward(index,preferred,noise):
  p=pairs[index];key=p['preferred'] if preferred else ('abort' if p['preferred']=='closed' else 'closed');x=p['candidates'][key]
  batch={k:b.gpu(v) for k,v in x['batch'].items()}
  donor_pair=pairs[int(donors[str(index)])]
  donor=donor_pair['candidates'][donor_pair['preferred']]['contact']['observation']
  controlled=observation_control(x['contact']['observation'],'zero',donor=donor)
  args={k:v.cuda() for k,v in controlled.items()}
  args.update({k:v.cuda() for k,v in x['contact']['supervision'].items()});args['contact_aux_weight']=.1
  torch.manual_seed(noise)
  return model(**batch,**args)
 references=[]
 with torch.no_grad():
  for step in range(128):
   out=forward(step%4,False,81000+step);references.append(float(out[1]));del out
 (O/'references.json').write_text(json.dumps(references))
 initial={n:p.detach().cpu().clone() for n,p in model.named_parameters() if p.requires_grad}
 for step in range(128):
  t=time.monotonic();optimizer.zero_grad(set_to_none=True)
  out=forward(step%4,True,81000+step)
  action,metrics=anchored_action_loss(out[1].reshape(1),torch.tensor([references[step]],device='cuda'))
  # Preserve independent auxiliary/router terms; replace only pure VLA regression.
  loss=action+(out[0]-out[1]);assert torch.isfinite(loss)
  loss.backward();norm=torch.nn.utils.clip_grad_norm_([p for g in optimizer.param_groups for p in g['params']],1.,error_if_nonfinite=True)
  optimizer.step();torch.cuda.synchronize()
  rows.append(dict(step=step+1,pair=step%4,loss=float(loss.detach()),action_loss=float(out[1].detach()),reference_rejected=references[step],gradient_norm=float(norm),seconds=time.monotonic()-t))
  if (step+1)%32==0:
   ck=R/'models'/'contact_action_fit128_zero_v1';ck.mkdir(exist_ok=True)
   torch.save(dict(parameters={n:p.detach().cpu().clone() for n,p in model.named_parameters() if p.requires_grad},steps=step+1),ck/f'intermediate{step+1}.pt')
  (O/'progress.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows[-1]),flush=True);del out,loss,action
 learned={n:p.detach().cpu() for n,p in model.named_parameters() if p.requires_grad}
 assert any(not torch.equal(initial[n],p) for n,p in learned.items())
 assert not any(p.requires_grad for n,p in model.named_parameters() if not n.startswith(('model.tactile_adapter.','model.action_contact_head.')))
 checkpoint=R/'models/contact_action_fit128_zero_v1';checkpoint.mkdir(exist_ok=True)
 torch.save(dict(parameters=learned,optimizer=optimizer.state_dict(),steps=128,manifest=manifest),checkpoint/'step128.pt')
 status='completed'
except Exception as exc:
 error=repr(exc);raise
finally:
 result=dict(status=status,error=error,optimizer_steps=len(rows),elapsed_seconds=time.time()-start,rows=rows,independent_evaluation=False,modality='zero',scope='two training seeds, four local action decisions; capability fit only, not recovery or generalization')
 (O/'result.json').write_text(json.dumps(result,indent=2))
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 fig,ax=plt.subplots(figsize=(7,4));ax.plot([x['step'] for x in rows],[x['action_loss'] for x in rows],marker='o');ax.set(xlabel='Optimizer step',ylabel='Preferred action loss');fig.tight_layout();fig.savefig(O/'loss.png',dpi=150)
 (O/'report.md').write_text('# VLA局部动作学习对照：zero\n\n实际更新触觉时序适配器和动作条件接触头，主干冻结。micro-batch=1，global-batch=1，AdamW学习率1e-4，上限128次更新。四个训练决策循环32遍，各步固定噪声与训练前参考；辅助权重0.1、排序权重0.25。此为训练能力试验，尚无匹配对照或独立仿真评测；不同步的样本和噪声不同，曲线不可直接视为收敛趋势。\n\n![loss](loss.png)\n\n```json\n'+json.dumps(result,ensure_ascii=False,indent=2)+'\n```\n')
