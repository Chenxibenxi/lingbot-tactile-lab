import json,time,hashlib
from pathlib import Path
import torch
import run_cwmj_m7_training as b
from contact_temporal_conditioner import ContactTemporalConditioner
from action_conditioned_contact import ActionConditionedContactHead
from contact_trainable_parameters import configure_contact_training
from contact_action_objective import anchored_action_loss
R=b.REPO;W=R/'work/contact_action_gradient_diagnosis_v1';O=R/'data/reports/contact_action_gradient_diagnosis_v1';O.mkdir(exist_ok=False)
rows=[];start=time.time();status='failed';error=None
try:
 manifest=json.loads((W/'manifest.json').read_text())
 for path,digest in manifest['files'].items():assert hashlib.sha256((R/path).read_bytes()).hexdigest()==digest,path
 b.require_reproducibility_gate();b.require_gpu_window();_,_,weights=b.verify_fixed_inputs(R)
 from lingbotvla.models.vla.lingbot_vla.qwen3vl_in_vla import apply_lingbot_qwen3_vl_patch
 apply_lingbot_qwen3_vl_patch();torch.manual_seed(17011)
 cfg=b.build_old_config();cfg.use_cache=False;cfg.num_steps=2
 model,proof=b.load_model(cfg,R/'work/contact_temporal_model_v3/modeling_lingbot_vla_v2.py',weights)
 model.model.tactile_adapter=ContactTemporalConditioner(cfg.proj_width).float().cuda()
 model.model.action_contact_head=ActionConditionedContactHead(cfg.proj_width).float().cuda()
 groups=configure_contact_training(model)
 model.train()
 D=R/'data/reports/contact_action_training_batches_v1';summary=json.loads((D/'summary.json').read_text());pairs=[]
 for row in summary['pairs']:
  path=D/row['tensor_file'];assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256']
  pairs.append(torch.load(path,map_location='cpu',weights_only=False))
 def forward(index,preferred,noise):
  p=pairs[index];key=p['preferred'] if preferred else ('abort' if p['preferred']=='closed' else 'closed');x=p['candidates'][key]
  batch={k:b.gpu(v) for k,v in x['batch'].items()}
  args={k:v.cuda() for k,v in x['contact']['observation'].items()}
  args.update({k:v.cuda() for k,v in x['contact']['supervision'].items()});args['contact_aux_weight']=.1
  torch.manual_seed(noise)
  return model(**batch,**args)
 checkpoint=R/'models/contact_action_fit128_true_v1/step128.pt';saved=torch.load(checkpoint,map_location='cpu',weights_only=False)['parameters'];names=dict(model.named_parameters())
 assert set(saved)=={n for n,p in names.items() if p.requires_grad}
 with torch.no_grad():
  for n,value in saved.items():names[n].copy_(value)
 selected=[(n,p) for n,p in names.items() if p.requires_grad];params=[p for n,p in selected]
 for i,pair in enumerate(pairs):
  x=pair['candidates'][pair['preferred']];batch={k:b.gpu(v) for k,v in x['batch'].items() if k not in ('joint_mask','action_is_pad')};obs={k:v.cuda() for k,v in x['contact']['observation'].items()};sup={k:v.cuda() for k,v in x['contact']['supervision'].items()}
  mask=x['batch']['joint_mask'].cuda().bool();grip=torch.zeros_like(mask);grip[:,:,29]=mask[:,:,29];other=mask&~grip
  for timestep in (.1,.5,.9):
   torch.manual_seed(99000+i);noise=torch.randn_like(batch['actions']);time_tensor=torch.tensor([timestep],device='cuda',dtype=torch.bfloat16)
   result=model.model.forward(**batch,**obs,**sup,contact_aux_weight=.1,noise=noise,time=time_tensor,loss_type=cfg.loss_type)
   losses=result[0];terms={'gripper':losses[grip].mean(),'other':losses[other].mean(),'auxiliary':result[7]['_contact_weighted_loss']}
   vectors={};metrics={}
   for j,(key,loss) in enumerate(terms.items()):
    grads=torch.autograd.grad(loss,params,retain_graph=j<2,allow_unused=True)
    vectors[key]={n:(g.detach().float().cpu().flatten() if g is not None else torch.zeros(p.numel())) for (n,p),g in zip(selected,grads)}
   for group,prefixes in {'touch':('model.tactile_adapter.tactile.','model.tactile_adapter.time_embedding'),'proprio':('model.tactile_adapter.proprio.',),'history':('model.tactile_adapter.history',),'contact_head':('model.action_contact_head.',)}.items():
    v={k:torch.cat([a for n,a in d.items() if n.startswith(prefixes)]) for k,d in vectors.items()}
    metrics[group]={k+'_norm':float(a.norm()) for k,a in v.items()}
    denom=v['gripper'].norm()*v['auxiliary'].norm();metrics[group]['gripper_aux_cosine']=float(torch.dot(v['gripper'],v['auxiliary'])/denom) if denom>0 else None
    # Original mean action loss gives gripper 1/14 and other dimensions 13/14.
    metrics[group]['weighted_gripper_norm']=float(v['gripper'].norm()/14)
    metrics[group]['weighted_other_norm']=float(v['other'].norm()*13/14)
   row=dict(pair=i,preferred=pair['preferred'],time=timestep,losses={k:float(v.detach()) for k,v in terms.items()},gradients=metrics);rows.append(row);print(json.dumps(row),flush=True)
   del result,terms,vectors
 status='completed'
except Exception as exc:error=repr(exc);raise
finally:
 result=dict(status=status,error=error,rows=rows,optimizer_steps=0,scope='trained true model; fixed training observations and three FM times; no generation or task success claim')
 (O/'result.json').write_text(json.dumps(result,indent=2))
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 fig,ax=plt.subplots(figsize=(9,4))
 for key in ('weighted_gripper_norm','weighted_other_norm','auxiliary_norm'):
  ax.plot(range(len(rows)),[r['gradients']['touch'][key] for r in rows],marker='.',label=key)
 ax.set(yscale='symlog',xlabel='Pair/time diagnostic',ylabel='Touch encoder gradient norm');ax.legend();fig.tight_layout();fig.savefig(O/'gradients.png',dpi=150)
 (O/'report.md').write_text('# 夹爪、其余动作与辅助梯度分解\n\n加载真实触觉128步模块，只计算四训练决策×三个固定flow-matching时间点，不更新参数。夹爪和其余动作先分别求均值，再显示原全动作平均的1/14与13/14贡献；辅助梯度已经乘0.1。夹爪与辅助方向余弦只作局部诊断，不能证明优化全程冲突；不包含额外偏好hinge或路由项，不是总更新方向。\n\n![gradients](gradients.png)\n\n```json\n'+json.dumps(result,indent=2)+'\n```\n')
