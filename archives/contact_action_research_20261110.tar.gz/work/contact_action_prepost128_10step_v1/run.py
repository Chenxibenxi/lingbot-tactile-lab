import json,time,hashlib
from pathlib import Path
import torch
import run_cwmj_m7_training as b
from contact_temporal_conditioner import ContactTemporalConditioner
from action_conditioned_contact import ActionConditionedContactHead
from contact_trainable_parameters import configure_contact_training
from contact_modality_controls import observation_control,training_donor_map
R=b.REPO;O=R/'data/reports/contact_action_prepost128_10step_v1';O.mkdir(exist_ok=False);rows=[];status='failed';error=None
try:
 b.require_reproducibility_gate();b.require_gpu_window();_,_,weights=b.verify_fixed_inputs(R)
 from lingbotvla.models.vla.lingbot_vla.qwen3vl_in_vla import apply_lingbot_qwen3_vl_patch
 apply_lingbot_qwen3_vl_patch();torch.manual_seed(17011);cfg=b.build_old_config();cfg.use_cache=True;cfg.num_steps=10
 model,proof=b.load_model(cfg,R/'work/contact_temporal_model_v3/modeling_lingbot_vla_v2.py',weights)
 model.model.tactile_adapter=ContactTemporalConditioner(cfg.proj_width).float().cuda()
 model.model.action_contact_head=ActionConditionedContactHead(cfg.proj_width).float().cuda()
 configure_contact_training(model);model.eval()
 initial={n:p.detach().cpu().clone() for n,p in model.named_parameters() if p.requires_grad};parameters=dict(model.named_parameters())
 D=R/'data/reports/contact_action_training_batches_v1';summary=json.loads((D/'summary.json').read_text());pairs=[]
 for row in summary['pairs']:
  path=D/row['tensor_file'];assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'];pairs.append(torch.load(path,weights_only=False,map_location='cpu'))
 donors=training_donor_map([dict(sample_id=str(i),seed=p['metadata']['seed'],split='train') for i,p in enumerate(pairs)])
 actions={};hashes={}
 for mode in ('true','missing','zero','mismatch'):
  name='contact_action_fit128_'+mode+'_v1'
  cp=R/'models'/name/'step128.pt';hashes[mode]=hashlib.sha256(cp.read_bytes()).hexdigest();trained=torch.load(cp,map_location='cpu',weights_only=False)['parameters'];assert set(trained)==set(initial)
  for stage,values in [('before',initial),('after',trained)]:
   with torch.no_grad():
    for n,value in values.items():parameters[n].copy_(value)
   for i,pair in enumerate(pairs):
    x=pair['candidates'][pair['preferred']];batch=x['batch'];donor=pairs[int(donors[str(i)])];donor=donor['candidates'][donor['preferred']]['contact']['observation']
    obs={k:v.cuda() for k,v in observation_control(x['contact']['observation'],mode,donor=donor).items()}
    visual={k:b.gpu(v) for k,v in batch.items() if k not in ('actions','joint_mask','action_is_pad')}
    torch.manual_seed(91000+i);noise=torch.randn((1,50,55),device='cuda',dtype=torch.bfloat16)
    torch.cuda.synchronize();t=time.monotonic()
    with torch.inference_mode():action=model.model.sample_actions(**visual,**obs,noise=noise)
    torch.cuda.synchronize();seconds=time.monotonic()-t;action=action.float().cpu();assert torch.isfinite(action).all()
    mask=batch['joint_mask'].float();target=batch['actions'].float()
    assert action.shape==target.shape
    mask=torch.broadcast_to(mask,action.shape)
    mse=float(((action-target).square()*mask).sum()/mask.sum())
    other='abort' if pair['preferred']=='closed' else 'closed';rejected=pair['candidates'][other]['batch']['actions'].float()
    other_mse=float(((action-rejected).square()*mask).sum()/mask.sum())
    actions[mode,stage,i]=action
    rows.append(dict(mode=mode,stage=stage,pair=i,preferred_mse=mse,rejected_mse=other_mse,preferred_closer=mse<other_mse,seconds=seconds))
    print(json.dumps(rows[-1]),flush=True)
 torch.save(actions,O/'normalized_actions.pt');status='completed'
except Exception as exc:error=repr(exc);raise
finally:
 result=dict(status=status,error=error,rows=rows,scope='training decisions only; ten denoising steps; no simulation execution or generalization claim')
 (O/'result.json').write_text(json.dumps(result,indent=2))
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 fig,ax=plt.subplots(figsize=(8,4))
 for mode in ('true','missing','zero','mismatch'):
  vals=[sum(x['preferred_mse'] for x in rows if x['mode']==mode and x['stage']==s)/4 for s in ('before','after')]
  if any(x['mode']==mode for x in rows):ax.plot(['before','after'],vals,marker='o',label=mode)
 ax.legend();ax.set_ylabel('Normalized action MSE on training decisions');fig.tight_layout();fig.savefig(O/'actions.png',dpi=150)
 (O/'report.md').write_text('# 固定噪声动作生成前后测\n\n各组训练前后采用相同观测、固定噪声与10步去噪，比较真实生成动作到优选/非优选动作的归一化误差，并记录同步GPU推理耗时。只使用四个训练决策，不是独立泛化或仿真成功率。首条推理含预热开销；平均动作误差可能掩盖夹爪维度差异，不能直接作控制效果结论。\n\n![actions](actions.png)\n\n```json\n'+json.dumps(result,ensure_ascii=False,indent=2)+'\n```\n')
