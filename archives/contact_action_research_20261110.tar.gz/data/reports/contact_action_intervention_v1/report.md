# 固定其他输入的触觉干预

所有输入干预共用真实触觉训练的同一个checkpoint及同一初始模型，固定图像/本体/历史/噪声，仅改触觉；采用2步去噪，比较真实生成动作到优选/非优选动作的归一化误差，并记录同步GPU推理耗时。只使用四个训练决策，不是独立泛化或仿真成功率。首条推理含预热开销；平均动作误差可能掩盖夹爪维度差异，不能直接作控制效果结论。

![actions](actions.png)

```json
{
  "status": "completed",
  "error": null,
  "rows": [
    {
      "mode": "true",
      "stage": "before",
      "pair": 0,
      "preferred_mse": 0.018861614167690277,
      "rejected_mse": 0.20193442702293396,
      "preferred_closer": true,
      "seconds": 0.9625647619977826
    },
    {
      "mode": "true",
      "stage": "before",
      "pair": 1,
      "preferred_mse": 0.19961349666118622,
      "rejected_mse": 0.01611202582716942,
      "preferred_closer": false,
      "seconds": 0.19526611600304022
    },
    {
      "mode": "true",
      "stage": "before",
      "pair": 2,
      "preferred_mse": 0.005198648199439049,
      "rejected_mse": 0.1885751187801361,
      "preferred_closer": true,
      "seconds": 0.19594475800113287
    },
    {
      "mode": "true",
      "stage": "before",
      "pair": 3,
      "preferred_mse": 0.18747931718826294,
      "rejected_mse": 0.004442213103175163,
      "preferred_closer": false,
      "seconds": 0.18877117001102306
    },
    {
      "mode": "true",
      "stage": "after",
      "pair": 0,
      "preferred_mse": 0.0133002158254385,
      "rejected_mse": 0.19658736884593964,
      "preferred_closer": true,
      "seconds": 0.19123938099073712
    },
    {
      "mode": "true",
      "stage": "after",
      "pair": 1,
      "preferred_mse": 0.19530253112316132,
      "rejected_mse": 0.011193792335689068,
      "preferred_closer": false,
      "seconds": 0.21287397200649139
    },
    {
      "mode": "true",
      "stage": "after",
      "pair": 2,
      "preferred_mse": 0.0012923087924718857,
      "rejected_mse": 0.18549036979675293,
      "preferred_closer": true,
      "seconds": 0.18929713800025638
    },
    {
      "mode": "true",
      "stage": "after",
      "pair": 3,
      "preferred_mse": 0.18394069373607635,
      "rejected_mse": 0.0011357903713360429,
      "preferred_closer": false,
      "seconds": 0.19203572100377642
    },
    {
      "mode": "missing",
      "stage": "before",
      "pair": 0,
      "preferred_mse": 0.012403747998178005,
      "rejected_mse": 0.19406557083129883,
      "preferred_closer": true,
      "seconds": 0.1917706289968919
    },
    {
      "mode": "missing",
      "stage": "before",
      "pair": 1,
      "preferred_mse": 0.19366633892059326,
      "rejected_mse": 0.011218646541237831,
      "preferred_closer": false,
      "seconds": 0.19145188199763652
    },
    {
      "mode": "missing",
      "stage": "before",
      "pair": 2,
      "preferred_mse": 0.0037113253492861986,
      "rejected_mse": 0.18689130246639252,
      "preferred_closer": true,
      "seconds": 0.19234798499383032
    },
    {
      "mode": "missing",
      "stage": "before",
      "pair": 3,
      "preferred_mse": 0.18611526489257812,
      "rejected_mse": 0.003631849540397525,
      "preferred_closer": false,
      "seconds": 0.1874186069908319
    },
    {
      "mode": "missing",
      "stage": "after",
      "pair": 0,
      "preferred_mse": 0.009840232320129871,
      "rejected_mse": 0.19162708520889282,
      "preferred_closer": true,
      "seconds": 0.19193316699238494
    },
    {
      "mode": "missing",
      "stage": "after",
      "pair": 1,
      "preferred_mse": 0.1906139850616455,
      "rejected_mse": 0.008684256114065647,
      "preferred_closer": false,
      "seconds": 0.19138086000748444
    },
    {
      "mode": "missing",
      "stage": "after",
      "pair": 2,
      "preferred_mse": 0.002891141688451171,
      "rejected_mse": 0.18566033244132996,
      "preferred_closer": true,
      "seconds": 0.1887820560077671
    },
    {
      "mode": "missing",
      "stage": "after",
      "pair": 3,
      "preferred_mse": 0.18523246049880981,
      "rejected_mse": 0.0027311674784868956,
      "preferred_closer": false,
      "seconds": 0.19272184999135789
    },
    {
      "mode": "zero",
      "stage": "before",
      "pair": 0,
      "preferred_mse": 0.01951831951737404,
      "rejected_mse": 0.2019481509923935,
      "preferred_closer": true,
      "seconds": 0.19285865500569344
    },
    {
      "mode": "zero",
      "stage": "before",
      "pair": 1,
      "preferred_mse": 0.19994693994522095,
      "rejected_mse": 0.016838401556015015,
      "preferred_closer": false,
      "seconds": 0.20304086699616164
    },
    {
      "mode": "zero",
      "stage": "before",
      "pair": 2,
      "preferred_mse": 0.004637797363102436,
      "rejected_mse": 0.18822859227657318,
      "preferred_closer": true,
      "seconds": 0.19807771799969487
    },
    {
      "mode": "zero",
      "stage": "before",
      "pair": 3,
      "preferred_mse": 0.1872478425502777,
      "rejected_mse": 0.0043357680551707745,
      "preferred_closer": false,
      "seconds": 0.19243734500196297
    },
    {
      "mode": "zero",
      "stage": "after",
      "pair": 0,
      "preferred_mse": 0.017066029831767082,
      "rejected_mse": 0.19987095892429352,
      "preferred_closer": true,
      "seconds": 0.22530822399130557
    },
    {
      "mode": "zero",
      "stage": "after",
      "pair": 1,
      "preferred_mse": 0.19732406735420227,
      "rejected_mse": 0.014108371920883656,
      "preferred_closer": false,
      "seconds": 0.19849450299807359
    },
    {
      "mode": "zero",
      "stage": "after",
      "pair": 2,
      "preferred_mse": 0.003925272263586521,
      "rejected_mse": 0.18755176663398743,
      "preferred_closer": true,
      "seconds": 0.19580893400416244
    },
    {
      "mode": "zero",
      "stage": "after",
      "pair": 3,
      "preferred_mse": 0.186162069439888,
      "rejected_mse": 0.003446455579251051,
      "preferred_closer": false,
      "seconds": 0.19236251100664958
    },
    {
      "mode": "mismatch",
      "stage": "before",
      "pair": 0,
      "preferred_mse": 0.01864449866116047,
      "rejected_mse": 0.20153871178627014,
      "preferred_closer": true,
      "seconds": 0.1902183159982087
    },
    {
      "mode": "mismatch",
      "stage": "before",
      "pair": 1,
      "preferred_mse": 0.1995195895433426,
      "rejected_mse": 0.016071684658527374,
      "preferred_closer": false,
      "seconds": 0.2016199749923544
    },
    {
      "mode": "mismatch",
      "stage": "before",
      "pair": 2,
      "preferred_mse": 0.005208470858633518,
      "rejected_mse": 0.18844203650951385,
      "preferred_closer": true,
      "seconds": 0.1926848409930244
    },
    {
      "mode": "mismatch",
      "stage": "before",
      "pair": 3,
      "preferred_mse": 0.18704110383987427,
      "rejected_mse": 0.00446838466450572,
      "preferred_closer": false,
      "seconds": 0.19403847999637946
    },
    {
      "mode": "mismatch",
      "stage": "after",
      "pair": 0,
      "preferred_mse": 0.013080432079732418,
      "rejected_mse": 0.19626042246818542,
      "preferred_closer": true,
      "seconds": 0.19050331600010395
    },
    {
      "mode": "mismatch",
      "stage": "after",
      "pair": 1,
      "preferred_mse": 0.19493041932582855,
      "rejected_mse": 0.011089595034718513,
      "preferred_closer": false,
      "seconds": 0.19038692199683283
    },
    {
      "mode": "mismatch",
      "stage": "after",
      "pair": 2,
      "preferred_mse": 0.0012803645804524422,
      "rejected_mse": 0.18538911640644073,
      "preferred_closer": true,
      "seconds": 0.19156938699597958
    },
    {
      "mode": "mismatch",
      "stage": "after",
      "pair": 3,
      "preferred_mse": 0.1839989572763443,
      "rejected_mse": 0.001140460604801774,
      "preferred_closer": false,
      "seconds": 0.1931094640021911
    }
  ],
  "scope": "training decisions only; two denoising steps; no simulation execution or generalization claim"
}
```


## 同参数触觉干预差异

![intervention](intervention.png)

替换触觉可能形成物理上不一致输入，只衡量模型敏感性，不证明触觉对成功有益。缺失控制会改变有效token数量；置零与错配用于辅助区分内容和可用性。

```json
[
  {
    "stage": "before",
    "intervention": "missing",
    "pair": 0,
    "right_gripper_mean_abs_delta": 0.008515625260770321,
    "right_gripper_max_abs_delta": 0.015625,
    "bitwise_identical": false
  },
  {
    "stage": "before",
    "intervention": "missing",
    "pair": 1,
    "right_gripper_mean_abs_delta": 0.006796875037252903,
    "right_gripper_max_abs_delta": 0.01953125,
    "bitwise_identical": false
  },
  {
    "stage": "before",
    "intervention": "missing",
    "pair": 2,
    "right_gripper_mean_abs_delta": 0.0052343751303851604,
    "right_gripper_max_abs_delta": 0.0234375,
    "bitwise_identical": false
  },
  {
    "stage": "before",
    "intervention": "missing",
    "pair": 3,
    "right_gripper_mean_abs_delta": 0.006796875037252903,
    "right_gripper_max_abs_delta": 0.0234375,
    "bitwise_identical": false
  },
  {
    "stage": "before",
    "intervention": "zero",
    "pair": 0,
    "right_gripper_mean_abs_delta": 0.0043750000186264515,
    "right_gripper_max_abs_delta": 0.015625,
    "bitwise_identical": false
  },
  {
    "stage": "before",
    "intervention": "zero",
    "pair": 1,
    "right_gripper_mean_abs_delta": 0.00390625,
    "right_gripper_max_abs_delta": 0.015625,
    "bitwise_identical": false
  },
  {
    "stage": "before",
    "intervention": "zero",
    "pair": 2,
    "right_gripper_mean_abs_delta": 0.00390625,
    "right_gripper_max_abs_delta": 0.0078125,
    "bitwise_identical": false
  },
  {
    "stage": "before",
    "intervention": "zero",
    "pair": 3,
    "right_gripper_mean_abs_delta": 0.0035156249068677425,
    "right_gripper_max_abs_delta": 0.015625,
    "bitwise_identical": false
  },
  {
    "stage": "before",
    "intervention": "mismatch",
    "pair": 0,
    "right_gripper_mean_abs_delta": 0.0026562500279396772,
    "right_gripper_max_abs_delta": 0.0078125,
    "bitwise_identical": false
  },
  {
    "stage": "before",
    "intervention": "mismatch",
    "pair": 1,
    "right_gripper_mean_abs_delta": 0.0022656249348074198,
    "right_gripper_max_abs_delta": 0.01171875,
    "bitwise_identical": false
  },
  {
    "stage": "before",
    "intervention": "mismatch",
    "pair": 2,
    "right_gripper_mean_abs_delta": 0.0023437500931322575,
    "right_gripper_max_abs_delta": 0.0078125,
    "bitwise_identical": false
  },
  {
    "stage": "before",
    "intervention": "mismatch",
    "pair": 3,
    "right_gripper_mean_abs_delta": 0.002031249925494194,
    "right_gripper_max_abs_delta": 0.0078125,
    "bitwise_identical": false
  },
  {
    "stage": "after",
    "intervention": "missing",
    "pair": 0,
    "right_gripper_mean_abs_delta": 0.0078125,
    "right_gripper_max_abs_delta": 0.0234375,
    "bitwise_identical": false
  },
  {
    "stage": "after",
    "intervention": "missing",
    "pair": 1,
    "right_gripper_mean_abs_delta": 0.011093749664723873,
    "right_gripper_max_abs_delta": 0.0234375,
    "bitwise_identical": false
  },
  {
    "stage": "after",
    "intervention": "missing",
    "pair": 2,
    "right_gripper_mean_abs_delta": 0.008593750186264515,
    "right_gripper_max_abs_delta": 0.0234375,
    "bitwise_identical": false
  },
  {
    "stage": "after",
    "intervention": "missing",
    "pair": 3,
    "right_gripper_mean_abs_delta": 0.005546874832361937,
    "right_gripper_max_abs_delta": 0.015625,
    "bitwise_identical": false
  },
  {
    "stage": "after",
    "intervention": "zero",
    "pair": 0,
    "right_gripper_mean_abs_delta": 0.0052343751303851604,
    "right_gripper_max_abs_delta": 0.01953125,
    "bitwise_identical": false
  },
  {
    "stage": "after",
    "intervention": "zero",
    "pair": 1,
    "right_gripper_mean_abs_delta": 0.005156250204890966,
    "right_gripper_max_abs_delta": 0.015625,
    "bitwise_identical": false
  },
  {
    "stage": "after",
    "intervention": "zero",
    "pair": 2,
    "right_gripper_mean_abs_delta": 0.0053125000558793545,
    "right_gripper_max_abs_delta": 0.01953125,
    "bitwise_identical": false
  },
  {
    "stage": "after",
    "intervention": "zero",
    "pair": 3,
    "right_gripper_mean_abs_delta": 0.004921874962747097,
    "right_gripper_max_abs_delta": 0.015625,
    "bitwise_identical": false
  },
  {
    "stage": "after",
    "intervention": "mismatch",
    "pair": 0,
    "right_gripper_mean_abs_delta": 0.0023437500931322575,
    "right_gripper_max_abs_delta": 0.015625,
    "bitwise_identical": false
  },
  {
    "stage": "after",
    "intervention": "mismatch",
    "pair": 1,
    "right_gripper_mean_abs_delta": 0.0017968750325962901,
    "right_gripper_max_abs_delta": 0.01171875,
    "bitwise_identical": false
  },
  {
    "stage": "after",
    "intervention": "mismatch",
    "pair": 2,
    "right_gripper_mean_abs_delta": 0.001953125,
    "right_gripper_max_abs_delta": 0.01171875,
    "bitwise_identical": false
  },
  {
    "stage": "after",
    "intervention": "mismatch",
    "pair": 3,
    "right_gripper_mean_abs_delta": 0.0016406249487772584,
    "right_gripper_max_abs_delta": 0.0078125,
    "bitwise_identical": false
  }
]
```
