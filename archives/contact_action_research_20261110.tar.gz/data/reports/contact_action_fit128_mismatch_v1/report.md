# VLA局部动作学习对照：mismatch

实际更新触觉时序适配器和动作条件接触头，主干冻结。micro-batch=1，global-batch=1，AdamW学习率1e-4，上限128次更新。四个训练决策循环32遍，各步固定噪声与训练前参考；辅助权重0.1、排序权重0.25。此为训练能力试验，尚无匹配对照或独立仿真评测；不同步的样本和噪声不同，曲线不可直接视为收敛趋势。

![loss](loss.png)

```json
{
  "status": "completed",
  "error": null,
  "optimizer_steps": 128,
  "elapsed_seconds": 71.23551750183105,
  "rows": [
    {
      "step": 1,
      "pair": 0,
      "loss": 0.4233502745628357,
      "action_loss": 0.2412109375,
      "reference_rejected": 0.24609375,
      "gradient_norm": 1.393627405166626,
      "seconds": 0.3269581040076446
    },
    {
      "step": 2,
      "pair": 1,
      "loss": 0.40878209471702576,
      "action_loss": 0.244140625,
      "reference_rejected": 0.2119140625,
      "gradient_norm": 0.7178546786308289,
      "seconds": 0.2432580230088206
    },
    {
      "step": 3,
      "pair": 2,
      "loss": 0.21726086735725403,
      "action_loss": 0.06494140625,
      "reference_rejected": 0.1435546875,
      "gradient_norm": 1.0209907293319702,
      "seconds": 0.24435671699757222
    },
    {
      "step": 4,
      "pair": 3,
      "loss": 0.2909758687019348,
      "action_loss": 0.13671875,
      "reference_rejected": 0.1484375,
      "gradient_norm": 0.8754345178604126,
      "seconds": 0.24264449000474997
    },
    {
      "step": 5,
      "pair": 0,
      "loss": 0.33175423741340637,
      "action_loss": 0.203125,
      "reference_rejected": 0.232421875,
      "gradient_norm": 1.1980620622634888,
      "seconds": 0.24282104699523188
    },
    {
      "step": 6,
      "pair": 1,
      "loss": 0.41542109847068787,
      "action_loss": 0.25390625,
      "reference_rejected": 0.1806640625,
      "gradient_norm": 1.686354160308838,
      "seconds": 0.24416814500000328
    },
    {
      "step": 7,
      "pair": 2,
      "loss": 0.22971004247665405,
      "action_loss": 0.11572265625,
      "reference_rejected": 0.14453125,
      "gradient_norm": 0.9062840938568115,
      "seconds": 0.24224089700146578
    },
    {
      "step": 8,
      "pair": 3,
      "loss": 0.2959604263305664,
      "action_loss": 0.1474609375,
      "reference_rejected": 0.134765625,
      "gradient_norm": 0.9054089188575745,
      "seconds": 0.24385177200019825
    },
    {
      "step": 9,
      "pair": 0,
      "loss": 0.30509793758392334,
      "action_loss": 0.208984375,
      "reference_rejected": 0.283203125,
      "gradient_norm": 1.4652738571166992,
      "seconds": 0.24344131900579669
    },
    {
      "step": 10,
      "pair": 1,
      "loss": 0.2653825879096985,
      "action_loss": 0.1279296875,
      "reference_rejected": 0.1357421875,
      "gradient_norm": 0.8902851343154907,
      "seconds": 0.24432684399653226
    },
    {
      "step": 11,
      "pair": 2,
      "loss": 0.18843762576580048,
      "action_loss": 0.0986328125,
      "reference_rejected": 0.1064453125,
      "gradient_norm": 2.1168482303619385,
      "seconds": 0.24147529600304551
    },
    {
      "step": 12,
      "pair": 3,
      "loss": 0.3182920813560486,
      "action_loss": 0.1630859375,
      "reference_rejected": 0.10009765625,
      "gradient_norm": 1.4664063453674316,
      "seconds": 0.24427677498897538
    },
    {
      "step": 13,
      "pair": 0,
      "loss": 0.21956482529640198,
      "action_loss": 0.1416015625,
      "reference_rejected": 0.240234375,
      "gradient_norm": 2.025196075439453,
      "seconds": 0.24395540299883578
    },
    {
      "step": 14,
      "pair": 1,
      "loss": 0.410885751247406,
      "action_loss": 0.244140625,
      "reference_rejected": 0.1171875,
      "gradient_norm": 1.5184847116470337,
      "seconds": 0.243920895998599
    },
    {
      "step": 15,
      "pair": 2,
      "loss": 0.19309423863887787,
      "action_loss": 0.11572265625,
      "reference_rejected": 0.1142578125,
      "gradient_norm": 1.8985501527786255,
      "seconds": 0.24145340301038232
    },
    {
      "step": 16,
      "pair": 3,
      "loss": 0.3106609284877777,
      "action_loss": 0.158203125,
      "reference_rejected": 0.09033203125,
      "gradient_norm": 1.921830415725708,
      "seconds": 0.2442667659925064
    },
    {
      "step": 17,
      "pair": 0,
      "loss": 0.2101099044084549,
      "action_loss": 0.142578125,
      "reference_rejected": 0.1669921875,
      "gradient_norm": 1.3161406517028809,
      "seconds": 0.24346468900330365
    },
    {
      "step": 18,
      "pair": 1,
      "loss": 0.43201398849487305,
      "action_loss": 0.263671875,
      "reference_rejected": 0.12890625,
      "gradient_norm": 1.073318600654602,
      "seconds": 0.242858099998557
    },
    {
      "step": 19,
      "pair": 2,
      "loss": 0.17506080865859985,
      "action_loss": 0.10693359375,
      "reference_rejected": 0.119140625,
      "gradient_norm": 1.5710842609405518,
      "seconds": 0.24266313799307682
    },
    {
      "step": 20,
      "pair": 3,
      "loss": 0.40114814043045044,
      "action_loss": 0.228515625,
      "reference_rejected": 0.07177734375,
      "gradient_norm": 1.1977033615112305,
      "seconds": 0.245514099005959
    },
    {
      "step": 21,
      "pair": 0,
      "loss": 0.18534579873085022,
      "action_loss": 0.125,
      "reference_rejected": 0.2734375,
      "gradient_norm": 1.1837509870529175,
      "seconds": 0.24168447600095533
    },
    {
      "step": 22,
      "pair": 1,
      "loss": 0.34228405356407166,
      "action_loss": 0.2041015625,
      "reference_rejected": 0.1904296875,
      "gradient_norm": 3.0775604248046875,
      "seconds": 0.24275788699742407
    },
    {
      "step": 23,
      "pair": 2,
      "loss": 0.21721288561820984,
      "action_loss": 0.1552734375,
      "reference_rejected": 0.1796875,
      "gradient_norm": 2.115389108657837,
      "seconds": 0.24281840900948737
    },
    {
      "step": 24,
      "pair": 3,
      "loss": 0.3895910680294037,
      "action_loss": 0.22265625,
      "reference_rejected": 0.08251953125,
      "gradient_norm": 2.420484781265259,
      "seconds": 0.24336282700824086
    },
    {
      "step": 25,
      "pair": 0,
      "loss": 0.13719308376312256,
      "action_loss": 0.08251953125,
      "reference_rejected": 0.1611328125,
      "gradient_norm": 0.922825813293457,
      "seconds": 0.24449610900774132
    },
    {
      "step": 26,
      "pair": 1,
      "loss": 0.2831345498561859,
      "action_loss": 0.146484375,
      "reference_rejected": 0.1875,
      "gradient_norm": 0.9265921115875244,
      "seconds": 0.24438057599763852
    },
    {
      "step": 27,
      "pair": 2,
      "loss": 0.12285303324460983,
      "action_loss": 0.06591796875,
      "reference_rejected": 0.14453125,
      "gradient_norm": 0.9108700752258301,
      "seconds": 0.2446093050093623
    },
    {
      "step": 28,
      "pair": 3,
      "loss": 0.3562137484550476,
      "action_loss": 0.1953125,
      "reference_rejected": 0.08203125,
      "gradient_norm": 1.1465619802474976,
      "seconds": 0.24573444899579044
    },
    {
      "step": 29,
      "pair": 0,
      "loss": 0.17972509562969208,
      "action_loss": 0.1298828125,
      "reference_rejected": 0.208984375,
      "gradient_norm": 0.9225383400917053,
      "seconds": 0.24459060799563304
    },
    {
      "step": 30,
      "pair": 1,
      "loss": 0.25787028670310974,
      "action_loss": 0.119140625,
      "reference_rejected": 0.1533203125,
      "gradient_norm": 0.7776820659637451,
      "seconds": 0.24224374399636872
    },
    {
      "step": 31,
      "pair": 2,
      "loss": 0.123858742415905,
      "action_loss": 0.07080078125,
      "reference_rejected": 0.142578125,
      "gradient_norm": 1.169927716255188,
      "seconds": 0.24344786700385157
    },
    {
      "step": 32,
      "pair": 3,
      "loss": 0.23224011063575745,
      "action_loss": 0.09912109375,
      "reference_rejected": 0.095703125,
      "gradient_norm": 1.076612114906311,
      "seconds": 0.24325288999534678
    },
    {
      "step": 33,
      "pair": 0,
      "loss": 0.16767674684524536,
      "action_loss": 0.12060546875,
      "reference_rejected": 0.1982421875,
      "gradient_norm": 1.0318659543991089,
      "seconds": 0.24652365599467885
    },
    {
      "step": 34,
      "pair": 1,
      "loss": 0.2762612998485565,
      "action_loss": 0.13671875,
      "reference_rejected": 0.1630859375,
      "gradient_norm": 0.8421414494514465,
      "seconds": 0.2432923029991798
    },
    {
      "step": 35,
      "pair": 2,
      "loss": 0.12834058701992035,
      "action_loss": 0.0771484375,
      "reference_rejected": 0.1943359375,
      "gradient_norm": 1.2110673189163208,
      "seconds": 0.24547491800331045
    },
    {
      "step": 36,
      "pair": 3,
      "loss": 0.27003079652786255,
      "action_loss": 0.1396484375,
      "reference_rejected": 0.1953125,
      "gradient_norm": 1.7264506816864014,
      "seconds": 0.24029535500449128
    },
    {
      "step": 37,
      "pair": 0,
      "loss": 0.19150987267494202,
      "action_loss": 0.1455078125,
      "reference_rejected": 0.26953125,
      "gradient_norm": 1.4514402151107788,
      "seconds": 0.24293128499994054
    },
    {
      "step": 38,
      "pair": 1,
      "loss": 0.2598898708820343,
      "action_loss": 0.12060546875,
      "reference_rejected": 0.1533203125,
      "gradient_norm": 0.8562150597572327,
      "seconds": 0.2426920090074418
    },
    {
      "step": 39,
      "pair": 2,
      "loss": 0.10545653849840164,
      "action_loss": 0.054931640625,
      "reference_rejected": 0.1259765625,
      "gradient_norm": 0.7276074290275574,
      "seconds": 0.24351272400235757
    },
    {
      "step": 40,
      "pair": 3,
      "loss": 0.36343690752983093,
      "action_loss": 0.2060546875,
      "reference_rejected": 0.0888671875,
      "gradient_norm": 1.0274994373321533,
      "seconds": 0.24313868400349747
    },
    {
      "step": 41,
      "pair": 0,
      "loss": 0.13733205199241638,
      "action_loss": 0.09130859375,
      "reference_rejected": 0.1630859375,
      "gradient_norm": 0.8883270025253296,
      "seconds": 0.24716752000676934
    },
    {
      "step": 42,
      "pair": 1,
      "loss": 0.40607625246047974,
      "action_loss": 0.24609375,
      "reference_rejected": 0.16015625,
      "gradient_norm": 1.1558661460876465,
      "seconds": 0.24474259300041012
    },
    {
      "step": 43,
      "pair": 2,
      "loss": 0.20023085176944733,
      "action_loss": 0.1494140625,
      "reference_rejected": 0.275390625,
      "gradient_norm": 1.228434681892395,
      "seconds": 0.24682412399852183
    },
    {
      "step": 44,
      "pair": 3,
      "loss": 0.27858561277389526,
      "action_loss": 0.140625,
      "reference_rejected": 0.08984375,
      "gradient_norm": 1.0149099826812744,
      "seconds": 0.24408978900464717
    },
    {
      "step": 45,
      "pair": 0,
      "loss": 0.21852244436740875,
      "action_loss": 0.171875,
      "reference_rejected": 0.2353515625,
      "gradient_norm": 2.4162659645080566,
      "seconds": 0.24924974799796473
    },
    {
      "step": 46,
      "pair": 1,
      "loss": 0.23598253726959229,
      "action_loss": 0.09912109375,
      "reference_rejected": 0.126953125,
      "gradient_norm": 0.7275410890579224,
      "seconds": 0.24286506600037683
    },
    {
      "step": 47,
      "pair": 2,
      "loss": 0.13623028993606567,
      "action_loss": 0.083984375,
      "reference_rejected": 0.1875,
      "gradient_norm": 1.0129570960998535,
      "seconds": 0.24467350100167096
    },
    {
      "step": 48,
      "pair": 3,
      "loss": 0.2139786034822464,
      "action_loss": 0.0927734375,
      "reference_rejected": 0.12890625,
      "gradient_norm": 1.6477512121200562,
      "seconds": 0.24431989699951373
    },
    {
      "step": 49,
      "pair": 0,
      "loss": 0.16426406800746918,
      "action_loss": 0.11572265625,
      "reference_rejected": 0.1884765625,
      "gradient_norm": 1.2258570194244385,
      "seconds": 0.24670975099434145
    },
    {
      "step": 50,
      "pair": 1,
      "loss": 0.2823316752910614,
      "action_loss": 0.1474609375,
      "reference_rejected": 0.1611328125,
      "gradient_norm": 0.7343566417694092,
      "seconds": 0.24505972799670417
    },
    {
      "step": 51,
      "pair": 2,
      "loss": 0.13742268085479736,
      "action_loss": 0.083984375,
      "reference_rejected": 0.1513671875,
      "gradient_norm": 0.7465081810951233,
      "seconds": 0.24289106599462684
    },
    {
      "step": 52,
      "pair": 3,
      "loss": 0.19540390372276306,
      "action_loss": 0.07666015625,
      "reference_rejected": 0.150390625,
      "gradient_norm": 0.8937492370605469,
      "seconds": 0.24254919099621475
    },
    {
      "step": 53,
      "pair": 0,
      "loss": 0.17467685043811798,
      "action_loss": 0.125,
      "reference_rejected": 0.1806640625,
      "gradient_norm": 1.1881026029586792,
      "seconds": 0.2445635469921399
    },
    {
      "step": 54,
      "pair": 1,
      "loss": 0.3419807255268097,
      "action_loss": 0.1982421875,
      "reference_rejected": 0.158203125,
      "gradient_norm": 1.0833089351654053,
      "seconds": 0.24369908499647863
    },
    {
      "step": 55,
      "pair": 2,
      "loss": 0.12154380232095718,
      "action_loss": 0.0673828125,
      "reference_rejected": 0.14453125,
      "gradient_norm": 0.872464120388031,
      "seconds": 0.24236162699526176
    },
    {
      "step": 56,
      "pair": 3,
      "loss": 0.2105635404586792,
      "action_loss": 0.09375,
      "reference_rejected": 0.10986328125,
      "gradient_norm": 0.76237952709198,
      "seconds": 0.2429869640036486
    },
    {
      "step": 57,
      "pair": 0,
      "loss": 0.17611059546470642,
      "action_loss": 0.1259765625,
      "reference_rejected": 0.2578125,
      "gradient_norm": 1.4862196445465088,
      "seconds": 0.251061311995727
    },
    {
      "step": 58,
      "pair": 1,
      "loss": 0.25189751386642456,
      "action_loss": 0.119140625,
      "reference_rejected": 0.1455078125,
      "gradient_norm": 0.7988895773887634,
      "seconds": 0.2428458509966731
    },
    {
      "step": 59,
      "pair": 2,
      "loss": 0.10169850289821625,
      "action_loss": 0.047119140625,
      "reference_rejected": 0.2119140625,
      "gradient_norm": 0.7400298714637756,
      "seconds": 0.24529941800574306
    },
    {
      "step": 60,
      "pair": 3,
      "loss": 0.2656186521053314,
      "action_loss": 0.140625,
      "reference_rejected": 0.1015625,
      "gradient_norm": 1.7485005855560303,
      "seconds": 0.24427239000215195
    },
    {
      "step": 61,
      "pair": 0,
      "loss": 0.22695903480052948,
      "action_loss": 0.1767578125,
      "reference_rejected": 0.2490234375,
      "gradient_norm": 1.2329291105270386,
      "seconds": 0.2445337009994546
    },
    {
      "step": 62,
      "pair": 1,
      "loss": 0.35896730422973633,
      "action_loss": 0.208984375,
      "reference_rejected": 0.1396484375,
      "gradient_norm": 1.8952140808105469,
      "seconds": 0.2444919050030876
    },
    {
      "step": 63,
      "pair": 2,
      "loss": 0.11904691904783249,
      "action_loss": 0.06591796875,
      "reference_rejected": 0.1015625,
      "gradient_norm": 2.6812078952789307,
      "seconds": 0.24278093400062062
    },
    {
      "step": 64,
      "pair": 3,
      "loss": 0.3694033622741699,
      "action_loss": 0.2216796875,
      "reference_rejected": 0.09423828125,
      "gradient_norm": 1.2485530376434326,
      "seconds": 0.2474602199945366
    },
    {
      "step": 65,
      "pair": 0,
      "loss": 0.179413303732872,
      "action_loss": 0.130859375,
      "reference_rejected": 0.24609375,
      "gradient_norm": 1.6584397554397583,
      "seconds": 0.25869672698900104
    },
    {
      "step": 66,
      "pair": 1,
      "loss": 0.39688822627067566,
      "action_loss": 0.263671875,
      "reference_rejected": 0.2890625,
      "gradient_norm": 2.048464775085449,
      "seconds": 0.24533773100120015
    },
    {
      "step": 67,
      "pair": 2,
      "loss": 0.18619467318058014,
      "action_loss": 0.1337890625,
      "reference_rejected": 0.1708984375,
      "gradient_norm": 1.7327368259429932,
      "seconds": 0.24427534200367518
    },
    {
      "step": 68,
      "pair": 3,
      "loss": 0.3353009521961212,
      "action_loss": 0.19140625,
      "reference_rejected": 0.0791015625,
      "gradient_norm": 1.0384876728057861,
      "seconds": 0.24230718601029366
    },
    {
      "step": 69,
      "pair": 0,
      "loss": 0.14948055148124695,
      "action_loss": 0.1015625,
      "reference_rejected": 0.2255859375,
      "gradient_norm": 1.0258324146270752,
      "seconds": 0.24189312200178392
    },
    {
      "step": 70,
      "pair": 1,
      "loss": 0.24106526374816895,
      "action_loss": 0.10791015625,
      "reference_rejected": 0.12158203125,
      "gradient_norm": 0.942659318447113,
      "seconds": 0.24337199900764972
    },
    {
      "step": 71,
      "pair": 2,
      "loss": 0.13320301473140717,
      "action_loss": 0.0810546875,
      "reference_rejected": 0.150390625,
      "gradient_norm": 0.8861638903617859,
      "seconds": 0.24135749800188933
    },
    {
      "step": 72,
      "pair": 3,
      "loss": 0.3136109411716461,
      "action_loss": 0.1982421875,
      "reference_rejected": 0.2353515625,
      "gradient_norm": 1.5231852531433105,
      "seconds": 0.24393610400147736
    },
    {
      "step": 73,
      "pair": 0,
      "loss": 0.17899158596992493,
      "action_loss": 0.1318359375,
      "reference_rejected": 0.1884765625,
      "gradient_norm": 1.4549763202667236,
      "seconds": 0.24646497800131328
    },
    {
      "step": 74,
      "pair": 1,
      "loss": 0.2962513267993927,
      "action_loss": 0.1630859375,
      "reference_rejected": 0.171875,
      "gradient_norm": 0.7513272762298584,
      "seconds": 0.24476668499119114
    },
    {
      "step": 75,
      "pair": 2,
      "loss": 0.09656604379415512,
      "action_loss": 0.044921875,
      "reference_rejected": 0.185546875,
      "gradient_norm": 0.7223179340362549,
      "seconds": 0.2529952540062368
    },
    {
      "step": 76,
      "pair": 3,
      "loss": 0.3060232996940613,
      "action_loss": 0.1669921875,
      "reference_rejected": 0.07080078125,
      "gradient_norm": 0.9363964796066284,
      "seconds": 0.2386942830053158
    },
    {
      "step": 77,
      "pair": 0,
      "loss": 0.18621200323104858,
      "action_loss": 0.1396484375,
      "reference_rejected": 0.1943359375,
      "gradient_norm": 1.061832308769226,
      "seconds": 0.23017047600296792
    },
    {
      "step": 78,
      "pair": 1,
      "loss": 0.3274042010307312,
      "action_loss": 0.1943359375,
      "reference_rejected": 0.232421875,
      "gradient_norm": 1.159385323524475,
      "seconds": 0.23301035701297224
    },
    {
      "step": 79,
      "pair": 2,
      "loss": 0.09253939986228943,
      "action_loss": 0.04150390625,
      "reference_rejected": 0.2158203125,
      "gradient_norm": 1.0186091661453247,
      "seconds": 0.23395078899920918
    },
    {
      "step": 80,
      "pair": 3,
      "loss": 0.2406655102968216,
      "action_loss": 0.1220703125,
      "reference_rejected": 0.10693359375,
      "gradient_norm": 1.0400787591934204,
      "seconds": 0.23840431099233683
    },
    {
      "step": 81,
      "pair": 0,
      "loss": 0.12398768961429596,
      "action_loss": 0.078125,
      "reference_rejected": 0.28515625,
      "gradient_norm": 0.8568954467773438,
      "seconds": 0.24480761199083645
    },
    {
      "step": 82,
      "pair": 1,
      "loss": 0.3275037109851837,
      "action_loss": 0.1943359375,
      "reference_rejected": 0.2353515625,
      "gradient_norm": 1.2605928182601929,
      "seconds": 0.24334980999992695
    },
    {
      "step": 83,
      "pair": 2,
      "loss": 0.0953151285648346,
      "action_loss": 0.044921875,
      "reference_rejected": 0.08935546875,
      "gradient_norm": 1.046035885810852,
      "seconds": 0.24583173100836575
    },
    {
      "step": 84,
      "pair": 3,
      "loss": 0.23188328742980957,
      "action_loss": 0.1171875,
      "reference_rejected": 0.1337890625,
      "gradient_norm": 1.843564748764038,
      "seconds": 0.2460518640000373
    },
    {
      "step": 85,
      "pair": 0,
      "loss": 0.12597836554050446,
      "action_loss": 0.08154296875,
      "reference_rejected": 0.1533203125,
      "gradient_norm": 0.9049040079116821,
      "seconds": 0.24107710800308269
    },
    {
      "step": 86,
      "pair": 1,
      "loss": 0.2990596890449524,
      "action_loss": 0.1650390625,
      "reference_rejected": 0.1796875,
      "gradient_norm": 0.9904748201370239,
      "seconds": 0.3297084070072742
    },
    {
      "step": 87,
      "pair": 2,
      "loss": 0.1302163004875183,
      "action_loss": 0.08154296875,
      "reference_rejected": 0.2255859375,
      "gradient_norm": 1.2443547248840332,
      "seconds": 0.24239230901002884
    },
    {
      "step": 88,
      "pair": 3,
      "loss": 0.34611791372299194,
      "action_loss": 0.1982421875,
      "reference_rejected": 0.0712890625,
      "gradient_norm": 1.167870044708252,
      "seconds": 0.2436696579970885
    },
    {
      "step": 89,
      "pair": 0,
      "loss": 0.11300252377986908,
      "action_loss": 0.0703125,
      "reference_rejected": 0.224609375,
      "gradient_norm": 0.7900083065032959,
      "seconds": 0.24209625300136395
    },
    {
      "step": 90,
      "pair": 1,
      "loss": 0.2655576467514038,
      "action_loss": 0.130859375,
      "reference_rejected": 0.1484375,
      "gradient_norm": 1.2009575366973877,
      "seconds": 0.2421792199893389
    },
    {
      "step": 91,
      "pair": 2,
      "loss": 0.0959404706954956,
      "action_loss": 0.048583984375,
      "reference_rejected": 0.1435546875,
      "gradient_norm": 0.8768269419670105,
      "seconds": 0.2445748879981693
    },
    {
      "step": 92,
      "pair": 3,
      "loss": 0.2642688453197479,
      "action_loss": 0.1474609375,
      "reference_rejected": 0.150390625,
      "gradient_norm": 2.578993558883667,
      "seconds": 0.2423293769970769
    },
    {
      "step": 93,
      "pair": 0,
      "loss": 0.14229615032672882,
      "action_loss": 0.1015625,
      "reference_rejected": 0.181640625,
      "gradient_norm": 1.010907769203186,
      "seconds": 0.24763000299572013
    },
    {
      "step": 94,
      "pair": 1,
      "loss": 0.2562982439994812,
      "action_loss": 0.1201171875,
      "reference_rejected": 0.197265625,
      "gradient_norm": 0.9210666418075562,
      "seconds": 0.2413095129886642
    },
    {
      "step": 95,
      "pair": 2,
      "loss": 0.11341769993305206,
      "action_loss": 0.068359375,
      "reference_rejected": 0.1533203125,
      "gradient_norm": 0.8826212882995605,
      "seconds": 0.24724937599967234
    },
    {
      "step": 96,
      "pair": 3,
      "loss": 0.20058493316173553,
      "action_loss": 0.08154296875,
      "reference_rejected": 0.103515625,
      "gradient_norm": 1.1135448217391968,
      "seconds": 0.24343266698997468
    },
    {
      "step": 97,
      "pair": 0,
      "loss": 0.1481674760580063,
      "action_loss": 0.109375,
      "reference_rejected": 0.263671875,
      "gradient_norm": 1.7189913988113403,
      "seconds": 0.2446618980029598
    },
    {
      "step": 98,
      "pair": 1,
      "loss": 0.2924455404281616,
      "action_loss": 0.1552734375,
      "reference_rejected": 0.1845703125,
      "gradient_norm": 0.9065127372741699,
      "seconds": 0.24554197100223973
    },
    {
      "step": 99,
      "pair": 2,
      "loss": 0.11706652492284775,
      "action_loss": 0.0732421875,
      "reference_rejected": 0.1201171875,
      "gradient_norm": 0.8962862491607666,
      "seconds": 0.24556287300947588
    },
    {
      "step": 100,
      "pair": 3,
      "loss": 0.20622028410434723,
      "action_loss": 0.0869140625,
      "reference_rejected": 0.09033203125,
      "gradient_norm": 0.8730570077896118,
      "seconds": 0.24261486499744933
    },
    {
      "step": 101,
      "pair": 0,
      "loss": 0.1159733310341835,
      "action_loss": 0.07763671875,
      "reference_rejected": 0.1474609375,
      "gradient_norm": 0.7843159437179565,
      "seconds": 0.24251590800122358
    },
    {
      "step": 102,
      "pair": 1,
      "loss": 0.252300888299942,
      "action_loss": 0.11572265625,
      "reference_rejected": 0.1396484375,
      "gradient_norm": 0.8680528998374939,
      "seconds": 0.24205154899391346
    },
    {
      "step": 103,
      "pair": 2,
      "loss": 0.09562551230192184,
      "action_loss": 0.0517578125,
      "reference_rejected": 0.251953125,
      "gradient_norm": 1.0924150943756104,
      "seconds": 0.24220184999285266
    },
    {
      "step": 104,
      "pair": 3,
      "loss": 0.2581399381160736,
      "action_loss": 0.138671875,
      "reference_rejected": 0.1337890625,
      "gradient_norm": 2.091895341873169,
      "seconds": 0.24602033800329082
    },
    {
      "step": 105,
      "pair": 0,
      "loss": 0.11108756065368652,
      "action_loss": 0.07275390625,
      "reference_rejected": 0.1474609375,
      "gradient_norm": 0.9671010971069336,
      "seconds": 0.24258602400368545
    },
    {
      "step": 106,
      "pair": 1,
      "loss": 0.2972845435142517,
      "action_loss": 0.1611328125,
      "reference_rejected": 0.181640625,
      "gradient_norm": 0.721393883228302,
      "seconds": 0.24254676200507674
    },
    {
      "step": 107,
      "pair": 2,
      "loss": 0.09293697774410248,
      "action_loss": 0.049560546875,
      "reference_rejected": 0.2119140625,
      "gradient_norm": 0.7253572940826416,
      "seconds": 0.24455522799689788
    },
    {
      "step": 108,
      "pair": 3,
      "loss": 0.30710312724113464,
      "action_loss": 0.1884765625,
      "reference_rejected": 0.28125,
      "gradient_norm": 1.1721322536468506,
      "seconds": 0.24033606899320148
    },
    {
      "step": 109,
      "pair": 0,
      "loss": 0.10522875934839249,
      "action_loss": 0.0673828125,
      "reference_rejected": 0.2578125,
      "gradient_norm": 0.7144485712051392,
      "seconds": 0.24366820299474057
    },
    {
      "step": 110,
      "pair": 1,
      "loss": 0.24175138771533966,
      "action_loss": 0.10595703125,
      "reference_rejected": 0.1650390625,
      "gradient_norm": 0.8468654751777649,
      "seconds": 0.24172744899988174
    },
    {
      "step": 111,
      "pair": 2,
      "loss": 0.2620718479156494,
      "action_loss": 0.21875,
      "reference_rejected": 0.25,
      "gradient_norm": 1.5960136651992798,
      "seconds": 0.2413870960008353
    },
    {
      "step": 112,
      "pair": 3,
      "loss": 0.30106738209724426,
      "action_loss": 0.1630859375,
      "reference_rejected": 0.08203125,
      "gradient_norm": 1.0559349060058594,
      "seconds": 0.24250406099599786
    },
    {
      "step": 113,
      "pair": 0,
      "loss": 0.16625970602035522,
      "action_loss": 0.1279296875,
      "reference_rejected": 0.263671875,
      "gradient_norm": 1.1385972499847412,
      "seconds": 0.2422894030023599
    },
    {
      "step": 114,
      "pair": 1,
      "loss": 0.31706732511520386,
      "action_loss": 0.1826171875,
      "reference_rejected": 0.2197265625,
      "gradient_norm": 0.814031720161438,
      "seconds": 0.24065206499653868
    },
    {
      "step": 115,
      "pair": 2,
      "loss": 0.10189041495323181,
      "action_loss": 0.057861328125,
      "reference_rejected": 0.0888671875,
      "gradient_norm": 0.6637367606163025,
      "seconds": 0.24182035999547224
    },
    {
      "step": 116,
      "pair": 3,
      "loss": 0.3838100731372833,
      "action_loss": 0.2578125,
      "reference_rejected": 0.216796875,
      "gradient_norm": 5.061975002288818,
      "seconds": 0.2416374219901627
    },
    {
      "step": 117,
      "pair": 0,
      "loss": 0.16572034358978271,
      "action_loss": 0.126953125,
      "reference_rejected": 0.1953125,
      "gradient_norm": 0.8552854061126709,
      "seconds": 0.24052468899753876
    },
    {
      "step": 118,
      "pair": 1,
      "loss": 0.24649859964847565,
      "action_loss": 0.11279296875,
      "reference_rejected": 0.1611328125,
      "gradient_norm": 0.7646402716636658,
      "seconds": 0.24279840900271665
    },
    {
      "step": 119,
      "pair": 2,
      "loss": 0.10044519603252411,
      "action_loss": 0.056884765625,
      "reference_rejected": 0.1669921875,
      "gradient_norm": 0.8070909976959229,
      "seconds": 0.24116479700023774
    },
    {
      "step": 120,
      "pair": 3,
      "loss": 0.22784873843193054,
      "action_loss": 0.10693359375,
      "reference_rejected": 0.08740234375,
      "gradient_norm": 0.8828867077827454,
      "seconds": 0.2427736819954589
    },
    {
      "step": 121,
      "pair": 0,
      "loss": 0.1266021728515625,
      "action_loss": 0.08837890625,
      "reference_rejected": 0.1298828125,
      "gradient_norm": 0.7480589747428894,
      "seconds": 0.24178008201124612
    },
    {
      "step": 122,
      "pair": 1,
      "loss": 0.2632315754890442,
      "action_loss": 0.1298828125,
      "reference_rejected": 0.162109375,
      "gradient_norm": 0.7742543816566467,
      "seconds": 0.2433495360019151
    },
    {
      "step": 123,
      "pair": 2,
      "loss": 0.09804559499025345,
      "action_loss": 0.0546875,
      "reference_rejected": 0.1650390625,
      "gradient_norm": 0.6545889973640442,
      "seconds": 0.2453938010003185
    },
    {
      "step": 124,
      "pair": 3,
      "loss": 0.22599062323570251,
      "action_loss": 0.1064453125,
      "reference_rejected": 0.08935546875,
      "gradient_norm": 0.8453038930892944,
      "seconds": 0.24467648899008054
    },
    {
      "step": 125,
      "pair": 0,
      "loss": 0.11747787147760391,
      "action_loss": 0.0791015625,
      "reference_rejected": 0.2734375,
      "gradient_norm": 0.736467719078064,
      "seconds": 0.2414376860106131
    },
    {
      "step": 126,
      "pair": 1,
      "loss": 0.2528340220451355,
      "action_loss": 0.11865234375,
      "reference_rejected": 0.1123046875,
      "gradient_norm": 0.8052420616149902,
      "seconds": 0.24569560299278237
    },
    {
      "step": 127,
      "pair": 2,
      "loss": 0.10679204016923904,
      "action_loss": 0.06298828125,
      "reference_rejected": 0.1845703125,
      "gradient_norm": 0.96067875623703,
      "seconds": 0.24172971599909943
    },
    {
      "step": 128,
      "pair": 3,
      "loss": 0.2418421059846878,
      "action_loss": 0.1279296875,
      "reference_rejected": 0.2197265625,
      "gradient_norm": 1.3852605819702148,
      "seconds": 0.24076162299024872
    }
  ],
  "independent_evaluation": false,
  "modality": "mismatch",
  "scope": "two training seeds, four local action decisions; capability fit only, not recovery or generalization"
}
```
