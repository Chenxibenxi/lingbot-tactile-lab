# 固定噪声动作生成前后测

各组训练前后采用相同观测、固定噪声与10步去噪，比较真实生成动作到优选/非优选动作的归一化误差，并记录同步GPU推理耗时。只使用四个训练决策，不是独立泛化或仿真成功率。首条推理含预热开销；平均动作误差可能掩盖夹爪维度差异，不能直接作控制效果结论。

![actions](actions.png)

```json
{
  "status": "completed",
  "error": null,
  "rows": [
    {
      "mode": "true",
      "stage": "before",
      "pair": 0,
      "preferred_mse": 0.019053984433412552,
      "rejected_mse": 0.2007158100605011,
      "preferred_closer": true,
      "seconds": 1.3126749960065354
    },
    {
      "mode": "true",
      "stage": "before",
      "pair": 1,
      "preferred_mse": 0.1975771188735962,
      "rejected_mse": 0.015450921840965748,
      "preferred_closer": false,
      "seconds": 0.6402626649942249
    },
    {
      "mode": "true",
      "stage": "before",
      "pair": 2,
      "preferred_mse": 0.00448540598154068,
      "rejected_mse": 0.1861293613910675,
      "preferred_closer": true,
      "seconds": 0.6280813420016784
    },
    {
      "mode": "true",
      "stage": "before",
      "pair": 3,
      "preferred_mse": 0.18572314083576202,
      "rejected_mse": 0.0038291162345558405,
      "preferred_closer": false,
      "seconds": 0.6049522130051628
    },
    {
      "mode": "true",
      "stage": "after",
      "pair": 0,
      "preferred_mse": 0.014554639346897602,
      "rejected_mse": 0.19514483213424683,
      "preferred_closer": true,
      "seconds": 0.6228607319935691
    },
    {
      "mode": "true",
      "stage": "after",
      "pair": 1,
      "preferred_mse": 0.19167275726795197,
      "rejected_mse": 0.010546766221523285,
      "preferred_closer": false,
      "seconds": 0.6051348890032386
    },
    {
      "mode": "true",
      "stage": "after",
      "pair": 2,
      "preferred_mse": 0.0018430256750434637,
      "rejected_mse": 0.18089719116687775,
      "preferred_closer": true,
      "seconds": 0.5851647590025095
    },
    {
      "mode": "true",
      "stage": "after",
      "pair": 3,
      "preferred_mse": 0.18155455589294434,
      "rejected_mse": 0.0011072640772908926,
      "preferred_closer": false,
      "seconds": 0.5846256539953174
    },
    {
      "mode": "missing",
      "stage": "before",
      "pair": 0,
      "preferred_mse": 0.010639703832566738,
      "rejected_mse": 0.192890927195549,
      "preferred_closer": true,
      "seconds": 0.5908020039933035
    },
    {
      "mode": "missing",
      "stage": "before",
      "pair": 1,
      "preferred_mse": 0.19212916493415833,
      "rejected_mse": 0.00891347136348486,
      "preferred_closer": false,
      "seconds": 0.605165989996749
    },
    {
      "mode": "missing",
      "stage": "before",
      "pair": 2,
      "preferred_mse": 0.0029228911735117435,
      "rejected_mse": 0.18501336872577667,
      "preferred_closer": true,
      "seconds": 0.5873620069905883
    },
    {
      "mode": "missing",
      "stage": "before",
      "pair": 3,
      "preferred_mse": 0.18517735600471497,
      "rejected_mse": 0.002747506368905306,
      "preferred_closer": false,
      "seconds": 0.6162867539969739
    },
    {
      "mode": "missing",
      "stage": "after",
      "pair": 0,
      "preferred_mse": 0.009844283573329449,
      "rejected_mse": 0.19079169631004333,
      "preferred_closer": true,
      "seconds": 0.5918637060094625
    },
    {
      "mode": "missing",
      "stage": "after",
      "pair": 1,
      "preferred_mse": 0.1892727017402649,
      "rejected_mse": 0.0072893863543868065,
      "preferred_closer": false,
      "seconds": 0.6472007440024754
    },
    {
      "mode": "missing",
      "stage": "after",
      "pair": 2,
      "preferred_mse": 0.0025840532034635544,
      "rejected_mse": 0.1828170269727707,
      "preferred_closer": true,
      "seconds": 0.6268044890020974
    },
    {
      "mode": "missing",
      "stage": "after",
      "pair": 3,
      "preferred_mse": 0.18234387040138245,
      "rejected_mse": 0.001968011260032654,
      "preferred_closer": false,
      "seconds": 0.6555589040071936
    },
    {
      "mode": "zero",
      "stage": "before",
      "pair": 0,
      "preferred_mse": 0.01984342746436596,
      "rejected_mse": 0.2019517719745636,
      "preferred_closer": true,
      "seconds": 0.6028277090081247
    },
    {
      "mode": "zero",
      "stage": "before",
      "pair": 1,
      "preferred_mse": 0.19905976951122284,
      "rejected_mse": 0.016915708780288696,
      "preferred_closer": false,
      "seconds": 0.6214567319984781
    },
    {
      "mode": "zero",
      "stage": "before",
      "pair": 2,
      "preferred_mse": 0.004767194390296936,
      "rejected_mse": 0.18617895245552063,
      "preferred_closer": true,
      "seconds": 0.6045239550003316
    },
    {
      "mode": "zero",
      "stage": "before",
      "pair": 3,
      "preferred_mse": 0.1858103722333908,
      "rejected_mse": 0.004166403319686651,
      "preferred_closer": false,
      "seconds": 0.5901166020048549
    },
    {
      "mode": "zero",
      "stage": "after",
      "pair": 0,
      "preferred_mse": 0.012091798707842827,
      "rejected_mse": 0.19268199801445007,
      "preferred_closer": true,
      "seconds": 0.5986445570015348
    },
    {
      "mode": "zero",
      "stage": "after",
      "pair": 1,
      "preferred_mse": 0.1891712099313736,
      "rejected_mse": 0.00849170982837677,
      "preferred_closer": false,
      "seconds": 0.6133540489972802
    },
    {
      "mode": "zero",
      "stage": "after",
      "pair": 2,
      "preferred_mse": 0.0015760468086227775,
      "rejected_mse": 0.18170185387134552,
      "preferred_closer": true,
      "seconds": 0.6319806539977435
    },
    {
      "mode": "zero",
      "stage": "after",
      "pair": 3,
      "preferred_mse": 0.18131276965141296,
      "rejected_mse": 0.0008833329775370657,
      "preferred_closer": false,
      "seconds": 0.6020202439976856
    },
    {
      "mode": "mismatch",
      "stage": "before",
      "pair": 0,
      "preferred_mse": 0.019184473901987076,
      "rejected_mse": 0.2006140947341919,
      "preferred_closer": true,
      "seconds": 0.6002138129988452
    },
    {
      "mode": "mismatch",
      "stage": "before",
      "pair": 1,
      "preferred_mse": 0.1975962370634079,
      "rejected_mse": 0.01538071595132351,
      "preferred_closer": false,
      "seconds": 0.5836993369885022
    },
    {
      "mode": "mismatch",
      "stage": "before",
      "pair": 2,
      "preferred_mse": 0.004474180284887552,
      "rejected_mse": 0.18618959188461304,
      "preferred_closer": true,
      "seconds": 0.5836829640029464
    },
    {
      "mode": "mismatch",
      "stage": "before",
      "pair": 3,
      "preferred_mse": 0.1857655942440033,
      "rejected_mse": 0.0038537303917109966,
      "preferred_closer": false,
      "seconds": 0.604335051990347
    },
    {
      "mode": "mismatch",
      "stage": "after",
      "pair": 0,
      "preferred_mse": 0.01375461183488369,
      "rejected_mse": 0.19477345049381256,
      "preferred_closer": true,
      "seconds": 0.5848846070002764
    },
    {
      "mode": "mismatch",
      "stage": "after",
      "pair": 1,
      "preferred_mse": 0.19179308414459229,
      "rejected_mse": 0.010381313972175121,
      "preferred_closer": false,
      "seconds": 0.5932210929895518
    },
    {
      "mode": "mismatch",
      "stage": "after",
      "pair": 2,
      "preferred_mse": 0.0013757562264800072,
      "rejected_mse": 0.18135866522789001,
      "preferred_closer": true,
      "seconds": 0.6278027719963575
    },
    {
      "mode": "mismatch",
      "stage": "after",
      "pair": 3,
      "preferred_mse": 0.18182460963726044,
      "rejected_mse": 0.0009665079414844513,
      "preferred_closer": false,
      "seconds": 0.613779853010783
    }
  ],
  "scope": "training decisions only; ten denoising steps; no simulation execution or generalization claim"
}
```
