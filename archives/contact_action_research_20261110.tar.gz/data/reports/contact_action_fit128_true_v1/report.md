# VLA局部动作学习首轮

实际更新触觉时序适配器和动作条件接触头，主干冻结。micro-batch=1，global-batch=1，AdamW学习率1e-4，上限128次更新。四个训练决策循环32遍，各步固定噪声与训练前参考；辅助权重0.1、排序权重0.25。此为训练能力试验，尚无匹配对照或独立仿真评测；不同步的样本和噪声不同，曲线不可直接视为收敛趋势。

![loss](loss.png)

```json
{
  "status": "completed",
  "error": null,
  "optimizer_steps": 128,
  "elapsed_seconds": 70.9705057144165,
  "rows": [
    {
      "step": 1,
      "pair": 0,
      "loss": 0.42349615693092346,
      "action_loss": 0.2412109375,
      "reference_rejected": 0.2412109375,
      "gradient_norm": 1.4002221822738647,
      "seconds": 0.3349061180051649
    },
    {
      "step": 2,
      "pair": 1,
      "loss": 0.40391528606414795,
      "action_loss": 0.240234375,
      "reference_rejected": 0.2119140625,
      "gradient_norm": 0.7124277949333191,
      "seconds": 0.24588517998927273
    },
    {
      "step": 3,
      "pair": 2,
      "loss": 0.21754226088523865,
      "action_loss": 0.0654296875,
      "reference_rejected": 0.1455078125,
      "gradient_norm": 1.0194931030273438,
      "seconds": 0.24251754800206982
    },
    {
      "step": 4,
      "pair": 3,
      "loss": 0.2918992340564728,
      "action_loss": 0.1376953125,
      "reference_rejected": 0.1484375,
      "gradient_norm": 0.8776595592498779,
      "seconds": 0.24325259700708557
    },
    {
      "step": 5,
      "pair": 0,
      "loss": 0.33168336749076843,
      "action_loss": 0.203125,
      "reference_rejected": 0.2314453125,
      "gradient_norm": 1.1882137060165405,
      "seconds": 0.24157619499601424
    },
    {
      "step": 6,
      "pair": 1,
      "loss": 0.41538822650909424,
      "action_loss": 0.25390625,
      "reference_rejected": 0.1806640625,
      "gradient_norm": 1.68355393409729,
      "seconds": 0.24156385399692226
    },
    {
      "step": 7,
      "pair": 2,
      "loss": 0.22945116460323334,
      "action_loss": 0.11572265625,
      "reference_rejected": 0.14453125,
      "gradient_norm": 0.9038814902305603,
      "seconds": 0.24081823699816596
    },
    {
      "step": 8,
      "pair": 3,
      "loss": 0.2984103262424469,
      "action_loss": 0.1494140625,
      "reference_rejected": 0.134765625,
      "gradient_norm": 0.8897081017494202,
      "seconds": 0.24438546800229233
    },
    {
      "step": 9,
      "pair": 0,
      "loss": 0.3048549294471741,
      "action_loss": 0.208984375,
      "reference_rejected": 0.283203125,
      "gradient_norm": 1.3205218315124512,
      "seconds": 0.24034524499438703
    },
    {
      "step": 10,
      "pair": 1,
      "loss": 0.26349136233329773,
      "action_loss": 0.1259765625,
      "reference_rejected": 0.1357421875,
      "gradient_norm": 0.8950077891349792,
      "seconds": 0.24259568100387696
    },
    {
      "step": 11,
      "pair": 2,
      "loss": 0.18939663469791412,
      "action_loss": 0.10009765625,
      "reference_rejected": 0.1064453125,
      "gradient_norm": 2.0091824531555176,
      "seconds": 0.2391378329921281
    },
    {
      "step": 12,
      "pair": 3,
      "loss": 0.32837966084480286,
      "action_loss": 0.1708984375,
      "reference_rejected": 0.10009765625,
      "gradient_norm": 1.5087335109710693,
      "seconds": 0.24393621199124027
    },
    {
      "step": 13,
      "pair": 0,
      "loss": 0.21385090053081512,
      "action_loss": 0.13671875,
      "reference_rejected": 0.240234375,
      "gradient_norm": 2.0052754878997803,
      "seconds": 0.24081581200880464
    },
    {
      "step": 14,
      "pair": 1,
      "loss": 0.40785953402519226,
      "action_loss": 0.2412109375,
      "reference_rejected": 0.1162109375,
      "gradient_norm": 1.4379255771636963,
      "seconds": 0.2423904450115515
    },
    {
      "step": 15,
      "pair": 2,
      "loss": 0.18730837106704712,
      "action_loss": 0.111328125,
      "reference_rejected": 0.1142578125,
      "gradient_norm": 1.4468430280685425,
      "seconds": 0.24096326300059445
    },
    {
      "step": 16,
      "pair": 3,
      "loss": 0.30782637000083923,
      "action_loss": 0.1552734375,
      "reference_rejected": 0.0908203125,
      "gradient_norm": 2.249037265777588,
      "seconds": 0.24221507800393738
    },
    {
      "step": 17,
      "pair": 0,
      "loss": 0.21247488260269165,
      "action_loss": 0.146484375,
      "reference_rejected": 0.1630859375,
      "gradient_norm": 1.3368403911590576,
      "seconds": 0.24021240399451926
    },
    {
      "step": 18,
      "pair": 1,
      "loss": 0.4278424084186554,
      "action_loss": 0.259765625,
      "reference_rejected": 0.1298828125,
      "gradient_norm": 1.0697647333145142,
      "seconds": 0.2431326760124648
    },
    {
      "step": 19,
      "pair": 2,
      "loss": 0.17861254513263702,
      "action_loss": 0.1123046875,
      "reference_rejected": 0.11767578125,
      "gradient_norm": 1.5494379997253418,
      "seconds": 0.23998797999229282
    },
    {
      "step": 20,
      "pair": 3,
      "loss": 0.4055141806602478,
      "action_loss": 0.23046875,
      "reference_rejected": 0.0712890625,
      "gradient_norm": 1.1941494941711426,
      "seconds": 0.24341038698912598
    },
    {
      "step": 21,
      "pair": 0,
      "loss": 0.19794538617134094,
      "action_loss": 0.1396484375,
      "reference_rejected": 0.2734375,
      "gradient_norm": 1.3931705951690674,
      "seconds": 0.24227349399006926
    },
    {
      "step": 22,
      "pair": 1,
      "loss": 0.3459858298301697,
      "action_loss": 0.2060546875,
      "reference_rejected": 0.1904296875,
      "gradient_norm": 2.888181686401367,
      "seconds": 0.24013844100409187
    },
    {
      "step": 23,
      "pair": 2,
      "loss": 0.2105008065700531,
      "action_loss": 0.150390625,
      "reference_rejected": 0.1787109375,
      "gradient_norm": 1.9084408283233643,
      "seconds": 0.2429374900093535
    },
    {
      "step": 24,
      "pair": 3,
      "loss": 0.39003029465675354,
      "action_loss": 0.2216796875,
      "reference_rejected": 0.0830078125,
      "gradient_norm": 1.5296204090118408,
      "seconds": 0.2398384870029986
    },
    {
      "step": 25,
      "pair": 0,
      "loss": 0.12553910911083221,
      "action_loss": 0.072265625,
      "reference_rejected": 0.16015625,
      "gradient_norm": 1.0103957653045654,
      "seconds": 0.24179123500653077
    },
    {
      "step": 26,
      "pair": 1,
      "loss": 0.2887803912162781,
      "action_loss": 0.1513671875,
      "reference_rejected": 0.1875,
      "gradient_norm": 1.1345285177230835,
      "seconds": 0.24123128099017777
    },
    {
      "step": 27,
      "pair": 2,
      "loss": 0.12895871698856354,
      "action_loss": 0.0732421875,
      "reference_rejected": 0.14453125,
      "gradient_norm": 1.171647548675537,
      "seconds": 0.24149947900150437
    },
    {
      "step": 28,
      "pair": 3,
      "loss": 0.36307722330093384,
      "action_loss": 0.2001953125,
      "reference_rejected": 0.08203125,
      "gradient_norm": 1.198880910873413,
      "seconds": 0.2408306610013824
    },
    {
      "step": 29,
      "pair": 0,
      "loss": 0.17519782483577728,
      "action_loss": 0.1259765625,
      "reference_rejected": 0.208984375,
      "gradient_norm": 0.9938784241676331,
      "seconds": 0.2410796809999738
    },
    {
      "step": 30,
      "pair": 1,
      "loss": 0.2634007930755615,
      "action_loss": 0.12451171875,
      "reference_rejected": 0.1513671875,
      "gradient_norm": 0.8442338109016418,
      "seconds": 0.24181367200799286
    },
    {
      "step": 31,
      "pair": 2,
      "loss": 0.12489428371191025,
      "action_loss": 0.072265625,
      "reference_rejected": 0.142578125,
      "gradient_norm": 1.3925639390945435,
      "seconds": 0.24361811199923977
    },
    {
      "step": 32,
      "pair": 3,
      "loss": 0.24370849132537842,
      "action_loss": 0.1083984375,
      "reference_rejected": 0.09521484375,
      "gradient_norm": 1.7144657373428345,
      "seconds": 0.24133683599939104
    },
    {
      "step": 33,
      "pair": 0,
      "loss": 0.15836073458194733,
      "action_loss": 0.111328125,
      "reference_rejected": 0.2001953125,
      "gradient_norm": 1.1027991771697998,
      "seconds": 0.2412154509947868
    },
    {
      "step": 34,
      "pair": 1,
      "loss": 0.2829735577106476,
      "action_loss": 0.1435546875,
      "reference_rejected": 0.1630859375,
      "gradient_norm": 0.9730052351951599,
      "seconds": 0.2426752830069745
    },
    {
      "step": 35,
      "pair": 2,
      "loss": 0.1169338971376419,
      "action_loss": 0.06591796875,
      "reference_rejected": 0.1943359375,
      "gradient_norm": 1.2421540021896362,
      "seconds": 0.24339369199879002
    },
    {
      "step": 36,
      "pair": 3,
      "loss": 0.25502052903175354,
      "action_loss": 0.12451171875,
      "reference_rejected": 0.1953125,
      "gradient_norm": 1.5117987394332886,
      "seconds": 0.24005861399928108
    },
    {
      "step": 37,
      "pair": 0,
      "loss": 0.198446124792099,
      "action_loss": 0.15234375,
      "reference_rejected": 0.267578125,
      "gradient_norm": 1.3074235916137695,
      "seconds": 0.24179245300183538
    },
    {
      "step": 38,
      "pair": 1,
      "loss": 0.2640911638736725,
      "action_loss": 0.125,
      "reference_rejected": 0.1533203125,
      "gradient_norm": 1.001328468322754,
      "seconds": 0.23915731499437243
    },
    {
      "step": 39,
      "pair": 2,
      "loss": 0.10619600117206573,
      "action_loss": 0.0556640625,
      "reference_rejected": 0.1259765625,
      "gradient_norm": 0.680823028087616,
      "seconds": 0.24159834699821658
    },
    {
      "step": 40,
      "pair": 3,
      "loss": 0.3636361062526703,
      "action_loss": 0.2060546875,
      "reference_rejected": 0.08837890625,
      "gradient_norm": 0.9142069816589355,
      "seconds": 0.2433665970020229
    },
    {
      "step": 41,
      "pair": 0,
      "loss": 0.15320448577404022,
      "action_loss": 0.10693359375,
      "reference_rejected": 0.1640625,
      "gradient_norm": 0.9058104157447815,
      "seconds": 0.24256046100344975
    },
    {
      "step": 42,
      "pair": 1,
      "loss": 0.4094340205192566,
      "action_loss": 0.2490234375,
      "reference_rejected": 0.16015625,
      "gradient_norm": 1.100659966468811,
      "seconds": 0.24286357600067277
    },
    {
      "step": 43,
      "pair": 2,
      "loss": 0.21704645454883575,
      "action_loss": 0.166015625,
      "reference_rejected": 0.2734375,
      "gradient_norm": 1.3314971923828125,
      "seconds": 0.24053036500117742
    },
    {
      "step": 44,
      "pair": 3,
      "loss": 0.2736304998397827,
      "action_loss": 0.13671875,
      "reference_rejected": 0.08984375,
      "gradient_norm": 0.8547948598861694,
      "seconds": 0.24185067000507843
    },
    {
      "step": 45,
      "pair": 0,
      "loss": 0.23856012523174286,
      "action_loss": 0.19140625,
      "reference_rejected": 0.232421875,
      "gradient_norm": 1.6222505569458008,
      "seconds": 0.2402376020036172
    },
    {
      "step": 46,
      "pair": 1,
      "loss": 0.2379831075668335,
      "action_loss": 0.1015625,
      "reference_rejected": 0.126953125,
      "gradient_norm": 0.7350046038627625,
      "seconds": 0.2424136030022055
    },
    {
      "step": 47,
      "pair": 2,
      "loss": 0.13117389380931854,
      "action_loss": 0.07861328125,
      "reference_rejected": 0.1875,
      "gradient_norm": 1.006975769996643,
      "seconds": 0.24151554399577435
    },
    {
      "step": 48,
      "pair": 3,
      "loss": 0.23114365339279175,
      "action_loss": 0.10986328125,
      "reference_rejected": 0.12890625,
      "gradient_norm": 2.5414347648620605,
      "seconds": 0.24258223400101997
    },
    {
      "step": 49,
      "pair": 0,
      "loss": 0.16275295615196228,
      "action_loss": 0.1142578125,
      "reference_rejected": 0.1875,
      "gradient_norm": 1.1551047563552856,
      "seconds": 0.2409011309937341
    },
    {
      "step": 50,
      "pair": 1,
      "loss": 0.28348520398139954,
      "action_loss": 0.1484375,
      "reference_rejected": 0.1611328125,
      "gradient_norm": 0.8091526031494141,
      "seconds": 0.24315649500931613
    },
    {
      "step": 51,
      "pair": 2,
      "loss": 0.13433976471424103,
      "action_loss": 0.08154296875,
      "reference_rejected": 0.150390625,
      "gradient_norm": 0.7780860662460327,
      "seconds": 0.2415245110023534
    },
    {
      "step": 52,
      "pair": 3,
      "loss": 0.19132313132286072,
      "action_loss": 0.0712890625,
      "reference_rejected": 0.150390625,
      "gradient_norm": 0.8604052066802979,
      "seconds": 0.24148623101064004
    },
    {
      "step": 53,
      "pair": 0,
      "loss": 0.16479280591011047,
      "action_loss": 0.1162109375,
      "reference_rejected": 0.1806640625,
      "gradient_norm": 1.4126383066177368,
      "seconds": 0.24205074401106685
    },
    {
      "step": 54,
      "pair": 1,
      "loss": 0.34636688232421875,
      "action_loss": 0.201171875,
      "reference_rejected": 0.158203125,
      "gradient_norm": 1.1662318706512451,
      "seconds": 0.24372426499030553
    },
    {
      "step": 55,
      "pair": 2,
      "loss": 0.11744531989097595,
      "action_loss": 0.064453125,
      "reference_rejected": 0.1435546875,
      "gradient_norm": 0.8967998623847961,
      "seconds": 0.2427773950039409
    },
    {
      "step": 56,
      "pair": 3,
      "loss": 0.21414174139499664,
      "action_loss": 0.095703125,
      "reference_rejected": 0.1083984375,
      "gradient_norm": 0.8100265264511108,
      "seconds": 0.24370944499969482
    },
    {
      "step": 57,
      "pair": 0,
      "loss": 0.1768994927406311,
      "action_loss": 0.1279296875,
      "reference_rejected": 0.2578125,
      "gradient_norm": 0.9962296485900879,
      "seconds": 0.24375499600137118
    },
    {
      "step": 58,
      "pair": 1,
      "loss": 0.25232523679733276,
      "action_loss": 0.11865234375,
      "reference_rejected": 0.14453125,
      "gradient_norm": 0.8129247426986694,
      "seconds": 0.24337696199654602
    },
    {
      "step": 59,
      "pair": 2,
      "loss": 0.09934704005718231,
      "action_loss": 0.04638671875,
      "reference_rejected": 0.212890625,
      "gradient_norm": 0.7457453608512878,
      "seconds": 0.24066159600624815
    },
    {
      "step": 60,
      "pair": 3,
      "loss": 0.28035593032836914,
      "action_loss": 0.150390625,
      "reference_rejected": 0.1005859375,
      "gradient_norm": 1.814120888710022,
      "seconds": 0.2417498720024014
    },
    {
      "step": 61,
      "pair": 0,
      "loss": 0.23956918716430664,
      "action_loss": 0.19140625,
      "reference_rejected": 0.2470703125,
      "gradient_norm": 1.1470731496810913,
      "seconds": 0.23966456699417904
    },
    {
      "step": 62,
      "pair": 1,
      "loss": 0.287133127450943,
      "action_loss": 0.150390625,
      "reference_rejected": 0.1396484375,
      "gradient_norm": 1.9266833066940308,
      "seconds": 0.24692539300303906
    },
    {
      "step": 63,
      "pair": 2,
      "loss": 0.09868369996547699,
      "action_loss": 0.047607421875,
      "reference_rejected": 0.10205078125,
      "gradient_norm": 0.833586573600769,
      "seconds": 0.24214845399546903
    },
    {
      "step": 64,
      "pair": 3,
      "loss": 0.3397231698036194,
      "action_loss": 0.1953125,
      "reference_rejected": 0.09423828125,
      "gradient_norm": 1.3657909631729126,
      "seconds": 0.24323377000109758
    },
    {
      "step": 65,
      "pair": 0,
      "loss": 0.16436298191547394,
      "action_loss": 0.119140625,
      "reference_rejected": 0.24609375,
      "gradient_norm": 1.643905758857727,
      "seconds": 0.2674369989981642
    },
    {
      "step": 66,
      "pair": 1,
      "loss": 0.3313368856906891,
      "action_loss": 0.1953125,
      "reference_rejected": 0.2890625,
      "gradient_norm": 1.5593953132629395,
      "seconds": 0.2422114170040004
    },
    {
      "step": 67,
      "pair": 2,
      "loss": 0.14372090995311737,
      "action_loss": 0.09521484375,
      "reference_rejected": 0.169921875,
      "gradient_norm": 1.6832716464996338,
      "seconds": 0.24547954999434296
    },
    {
      "step": 68,
      "pair": 3,
      "loss": 0.3366541564464569,
      "action_loss": 0.1884765625,
      "reference_rejected": 0.0791015625,
      "gradient_norm": 0.8457070589065552,
      "seconds": 0.2462564699962968
    },
    {
      "step": 69,
      "pair": 0,
      "loss": 0.15634863078594208,
      "action_loss": 0.11279296875,
      "reference_rejected": 0.2275390625,
      "gradient_norm": 1.5834485292434692,
      "seconds": 0.2544447200052673
    },
    {
      "step": 70,
      "pair": 1,
      "loss": 0.2442609667778015,
      "action_loss": 0.10791015625,
      "reference_rejected": 0.123046875,
      "gradient_norm": 0.8730403780937195,
      "seconds": 0.24097567600256298
    },
    {
      "step": 71,
      "pair": 2,
      "loss": 0.12874886393547058,
      "action_loss": 0.08056640625,
      "reference_rejected": 0.1484375,
      "gradient_norm": 0.8009646534919739,
      "seconds": 0.2434594110090984
    },
    {
      "step": 72,
      "pair": 3,
      "loss": 0.31512463092803955,
      "action_loss": 0.1953125,
      "reference_rejected": 0.234375,
      "gradient_norm": 0.9727882742881775,
      "seconds": 0.23713271200540476
    },
    {
      "step": 73,
      "pair": 0,
      "loss": 0.16768163442611694,
      "action_loss": 0.12353515625,
      "reference_rejected": 0.1884765625,
      "gradient_norm": 1.692217469215393,
      "seconds": 0.24120423999556806
    },
    {
      "step": 74,
      "pair": 1,
      "loss": 0.2910790741443634,
      "action_loss": 0.15625,
      "reference_rejected": 0.171875,
      "gradient_norm": 0.7249882817268372,
      "seconds": 0.23888450300728437
    },
    {
      "step": 75,
      "pair": 2,
      "loss": 0.09290028363466263,
      "action_loss": 0.043212890625,
      "reference_rejected": 0.1875,
      "gradient_norm": 0.9128570556640625,
      "seconds": 0.2427880929899402
    },
    {
      "step": 76,
      "pair": 3,
      "loss": 0.30427131056785583,
      "action_loss": 0.1640625,
      "reference_rejected": 0.06982421875,
      "gradient_norm": 3.2066709995269775,
      "seconds": 0.2392811250028899
    },
    {
      "step": 77,
      "pair": 0,
      "loss": 0.17141281068325043,
      "action_loss": 0.1259765625,
      "reference_rejected": 0.1953125,
      "gradient_norm": 1.2982064485549927,
      "seconds": 0.24197157700837124
    },
    {
      "step": 78,
      "pair": 1,
      "loss": 0.33086925745010376,
      "action_loss": 0.197265625,
      "reference_rejected": 0.232421875,
      "gradient_norm": 0.633086621761322,
      "seconds": 0.23911781400965992
    },
    {
      "step": 79,
      "pair": 2,
      "loss": 0.0940280631184578,
      "action_loss": 0.044189453125,
      "reference_rejected": 0.2158203125,
      "gradient_norm": 0.7686013579368591,
      "seconds": 0.24062474200036377
    },
    {
      "step": 80,
      "pair": 3,
      "loss": 0.23461240530014038,
      "action_loss": 0.11572265625,
      "reference_rejected": 0.10498046875,
      "gradient_norm": 1.0333342552185059,
      "seconds": 0.23876786799519323
    },
    {
      "step": 81,
      "pair": 0,
      "loss": 0.12027537822723389,
      "action_loss": 0.07470703125,
      "reference_rejected": 0.28515625,
      "gradient_norm": 0.7480546236038208,
      "seconds": 0.24165786198864225
    },
    {
      "step": 82,
      "pair": 1,
      "loss": 0.3097198009490967,
      "action_loss": 0.1767578125,
      "reference_rejected": 0.2353515625,
      "gradient_norm": 0.6803644895553589,
      "seconds": 0.23858355201082304
    },
    {
      "step": 83,
      "pair": 2,
      "loss": 0.08991719782352448,
      "action_loss": 0.0400390625,
      "reference_rejected": 0.09130859375,
      "gradient_norm": 0.8244583606719971,
      "seconds": 0.2404543169977842
    },
    {
      "step": 84,
      "pair": 3,
      "loss": 0.22525939345359802,
      "action_loss": 0.10986328125,
      "reference_rejected": 0.1337890625,
      "gradient_norm": 0.9398932456970215,
      "seconds": 0.2404157699929783
    },
    {
      "step": 85,
      "pair": 0,
      "loss": 0.12952162325382233,
      "action_loss": 0.083984375,
      "reference_rejected": 0.15625,
      "gradient_norm": 0.8187609910964966,
      "seconds": 0.24304812999616843
    },
    {
      "step": 86,
      "pair": 1,
      "loss": 0.3193303346633911,
      "action_loss": 0.185546875,
      "reference_rejected": 0.1796875,
      "gradient_norm": 1.0388308763504028,
      "seconds": 0.24100744900351856
    },
    {
      "step": 87,
      "pair": 2,
      "loss": 0.09993042051792145,
      "action_loss": 0.050048828125,
      "reference_rejected": 0.224609375,
      "gradient_norm": 0.9049339890480042,
      "seconds": 0.23996044999512378
    },
    {
      "step": 88,
      "pair": 3,
      "loss": 0.34880173206329346,
      "action_loss": 0.201171875,
      "reference_rejected": 0.0703125,
      "gradient_norm": 1.3657609224319458,
      "seconds": 0.24087994400179014
    },
    {
      "step": 89,
      "pair": 0,
      "loss": 0.12898027896881104,
      "action_loss": 0.083984375,
      "reference_rejected": 0.224609375,
      "gradient_norm": 0.9573492407798767,
      "seconds": 0.23726102900400292
    },
    {
      "step": 90,
      "pair": 1,
      "loss": 0.25005874037742615,
      "action_loss": 0.11767578125,
      "reference_rejected": 0.150390625,
      "gradient_norm": 0.7756547927856445,
      "seconds": 0.24251041599200107
    },
    {
      "step": 91,
      "pair": 2,
      "loss": 0.0824994295835495,
      "action_loss": 0.03369140625,
      "reference_rejected": 0.14453125,
      "gradient_norm": 0.7140287756919861,
      "seconds": 0.24025439699471463
    },
    {
      "step": 92,
      "pair": 3,
      "loss": 0.2443246841430664,
      "action_loss": 0.12890625,
      "reference_rejected": 0.150390625,
      "gradient_norm": 2.310572862625122,
      "seconds": 0.23977588801062666
    },
    {
      "step": 93,
      "pair": 0,
      "loss": 0.15157613158226013,
      "action_loss": 0.1083984375,
      "reference_rejected": 0.1826171875,
      "gradient_norm": 1.038011908531189,
      "seconds": 0.23914488599984907
    },
    {
      "step": 94,
      "pair": 1,
      "loss": 0.2497180998325348,
      "action_loss": 0.1162109375,
      "reference_rejected": 0.197265625,
      "gradient_norm": 0.8361451625823975,
      "seconds": 0.2399409219942754
    },
    {
      "step": 95,
      "pair": 2,
      "loss": 0.10830657929182053,
      "action_loss": 0.061767578125,
      "reference_rejected": 0.150390625,
      "gradient_norm": 1.0584036111831665,
      "seconds": 0.24234160700871143
    },
    {
      "step": 96,
      "pair": 3,
      "loss": 0.21514759957790375,
      "action_loss": 0.09765625,
      "reference_rejected": 0.103515625,
      "gradient_norm": 0.8771475553512573,
      "seconds": 0.2408124810026493
    },
    {
      "step": 97,
      "pair": 0,
      "loss": 0.15569156408309937,
      "action_loss": 0.1142578125,
      "reference_rejected": 0.263671875,
      "gradient_norm": 1.1549986600875854,
      "seconds": 0.2392343920073472
    },
    {
      "step": 98,
      "pair": 1,
      "loss": 0.2876479923725128,
      "action_loss": 0.1533203125,
      "reference_rejected": 0.1826171875,
      "gradient_norm": 0.781059980392456,
      "seconds": 0.24222215700137895
    },
    {
      "step": 99,
      "pair": 2,
      "loss": 0.12688055634498596,
      "action_loss": 0.08154296875,
      "reference_rejected": 0.11865234375,
      "gradient_norm": 0.8474649786949158,
      "seconds": 0.248300074992585
    },
    {
      "step": 100,
      "pair": 3,
      "loss": 0.20618624985218048,
      "action_loss": 0.08837890625,
      "reference_rejected": 0.0908203125,
      "gradient_norm": 1.0365610122680664,
      "seconds": 0.24374670900579076
    },
    {
      "step": 101,
      "pair": 0,
      "loss": 0.11721781641244888,
      "action_loss": 0.07666015625,
      "reference_rejected": 0.1494140625,
      "gradient_norm": 0.8741683959960938,
      "seconds": 0.24031948800256941
    },
    {
      "step": 102,
      "pair": 1,
      "loss": 0.23708520829677582,
      "action_loss": 0.10302734375,
      "reference_rejected": 0.1416015625,
      "gradient_norm": 0.6586608290672302,
      "seconds": 0.24165271599486005
    },
    {
      "step": 103,
      "pair": 2,
      "loss": 0.10663358867168427,
      "action_loss": 0.0615234375,
      "reference_rejected": 0.251953125,
      "gradient_norm": 1.1495977640151978,
      "seconds": 0.23876147699775174
    },
    {
      "step": 104,
      "pair": 3,
      "loss": 0.23622764647006989,
      "action_loss": 0.119140625,
      "reference_rejected": 0.1337890625,
      "gradient_norm": 1.4451996088027954,
      "seconds": 0.2404716369928792
    },
    {
      "step": 105,
      "pair": 0,
      "loss": 0.12244642525911331,
      "action_loss": 0.08203125,
      "reference_rejected": 0.1474609375,
      "gradient_norm": 0.9456424117088318,
      "seconds": 0.23989782799617387
    },
    {
      "step": 106,
      "pair": 1,
      "loss": 0.2967030704021454,
      "action_loss": 0.1630859375,
      "reference_rejected": 0.1806640625,
      "gradient_norm": 0.9500542879104614,
      "seconds": 0.24103769000794273
    },
    {
      "step": 107,
      "pair": 2,
      "loss": 0.10137347131967545,
      "action_loss": 0.056396484375,
      "reference_rejected": 0.2099609375,
      "gradient_norm": 0.892137348651886,
      "seconds": 0.2420580850011902
    },
    {
      "step": 108,
      "pair": 3,
      "loss": 0.30819839239120483,
      "action_loss": 0.19140625,
      "reference_rejected": 0.283203125,
      "gradient_norm": 1.1134095191955566,
      "seconds": 0.23867608699947596
    },
    {
      "step": 109,
      "pair": 0,
      "loss": 0.10463067144155502,
      "action_loss": 0.064453125,
      "reference_rejected": 0.259765625,
      "gradient_norm": 0.7585698962211609,
      "seconds": 0.24098080699332058
    },
    {
      "step": 110,
      "pair": 1,
      "loss": 0.26200416684150696,
      "action_loss": 0.12890625,
      "reference_rejected": 0.166015625,
      "gradient_norm": 1.0591610670089722,
      "seconds": 0.23881585399794858
    },
    {
      "step": 111,
      "pair": 2,
      "loss": 0.2953246235847473,
      "action_loss": 0.25,
      "reference_rejected": 0.2490234375,
      "gradient_norm": 1.1438580751419067,
      "seconds": 0.24078220200317446
    },
    {
      "step": 112,
      "pair": 3,
      "loss": 0.3028821349143982,
      "action_loss": 0.166015625,
      "reference_rejected": 0.08251953125,
      "gradient_norm": 1.1204843521118164,
      "seconds": 0.2384812460077228
    },
    {
      "step": 113,
      "pair": 0,
      "loss": 0.23159746825695038,
      "action_loss": 0.19140625,
      "reference_rejected": 0.263671875,
      "gradient_norm": 3.094827890396118,
      "seconds": 0.24125120299868286
    },
    {
      "step": 114,
      "pair": 1,
      "loss": 0.3235584795475006,
      "action_loss": 0.19140625,
      "reference_rejected": 0.2216796875,
      "gradient_norm": 0.7260240316390991,
      "seconds": 0.23961460799910128
    },
    {
      "step": 115,
      "pair": 2,
      "loss": 0.1035723015666008,
      "action_loss": 0.057861328125,
      "reference_rejected": 0.08837890625,
      "gradient_norm": 0.6580569744110107,
      "seconds": 0.24152091900759842
    },
    {
      "step": 116,
      "pair": 3,
      "loss": 0.30929768085479736,
      "action_loss": 0.1953125,
      "reference_rejected": 0.21875,
      "gradient_norm": 1.7335048913955688,
      "seconds": 0.23985664000792895
    },
    {
      "step": 117,
      "pair": 0,
      "loss": 0.1839635670185089,
      "action_loss": 0.142578125,
      "reference_rejected": 0.1943359375,
      "gradient_norm": 0.6951513886451721,
      "seconds": 0.24136358000396285
    },
    {
      "step": 118,
      "pair": 1,
      "loss": 0.24055613577365875,
      "action_loss": 0.10986328125,
      "reference_rejected": 0.1611328125,
      "gradient_norm": 0.6785526275634766,
      "seconds": 0.24014970600546803
    },
    {
      "step": 119,
      "pair": 2,
      "loss": 0.10093662142753601,
      "action_loss": 0.0546875,
      "reference_rejected": 0.166015625,
      "gradient_norm": 0.7991756200790405,
      "seconds": 0.24088865199883003
    },
    {
      "step": 120,
      "pair": 3,
      "loss": 0.22059296071529388,
      "action_loss": 0.103515625,
      "reference_rejected": 0.0869140625,
      "gradient_norm": 0.7568894624710083,
      "seconds": 0.24009483099507634
    },
    {
      "step": 121,
      "pair": 0,
      "loss": 0.12705276906490326,
      "action_loss": 0.08544921875,
      "reference_rejected": 0.130859375,
      "gradient_norm": 0.7272419929504395,
      "seconds": 0.24165335400903132
    },
    {
      "step": 122,
      "pair": 1,
      "loss": 0.26471176743507385,
      "action_loss": 0.134765625,
      "reference_rejected": 0.162109375,
      "gradient_norm": 0.8410302996635437,
      "seconds": 0.23848397699475754
    },
    {
      "step": 123,
      "pair": 2,
      "loss": 0.09975476562976837,
      "action_loss": 0.053466796875,
      "reference_rejected": 0.1650390625,
      "gradient_norm": 0.6904968619346619,
      "seconds": 0.24309738399460912
    },
    {
      "step": 124,
      "pair": 3,
      "loss": 0.21726994216442108,
      "action_loss": 0.10205078125,
      "reference_rejected": 0.08984375,
      "gradient_norm": 0.8113781213760376,
      "seconds": 0.24190611099766102
    },
    {
      "step": 125,
      "pair": 0,
      "loss": 0.12500059604644775,
      "action_loss": 0.08349609375,
      "reference_rejected": 0.2734375,
      "gradient_norm": 0.7092786431312561,
      "seconds": 0.24170574299932923
    },
    {
      "step": 126,
      "pair": 1,
      "loss": 0.2515663504600525,
      "action_loss": 0.1201171875,
      "reference_rejected": 0.11279296875,
      "gradient_norm": 0.7222296595573425,
      "seconds": 0.24211879599897657
    },
    {
      "step": 127,
      "pair": 2,
      "loss": 0.11556469649076462,
      "action_loss": 0.0693359375,
      "reference_rejected": 0.1826171875,
      "gradient_norm": 0.9925702810287476,
      "seconds": 0.24115787200571503
    },
    {
      "step": 128,
      "pair": 3,
      "loss": 0.24333329498767853,
      "action_loss": 0.1318359375,
      "reference_rejected": 0.2216796875,
      "gradient_norm": 1.8237501382827759,
      "seconds": 0.2419046239956515
    }
  ],
  "independent_evaluation": false,
  "scope": "two training seeds, four local action decisions; capability fit only, not recovery or generalization"
}
```
