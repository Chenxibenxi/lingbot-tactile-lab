# 夹爪、其余动作与辅助梯度分解

加载真实触觉128步模块，只计算四训练决策×三个固定flow-matching时间点，不更新参数。夹爪和其余动作先分别求均值，再显示原全动作平均的1/14与13/14贡献；辅助梯度已经乘0.1。夹爪与辅助方向余弦只作局部诊断，不能证明优化全程冲突；不包含额外偏好hinge或路由项，不是总更新方向。

![gradients](gradients.png)

```json
{
  "status": "completed",
  "error": null,
  "rows": [
    {
      "pair": 0,
      "preferred": "closed",
      "time": 0.1,
      "losses": {
        "gripper": 0.150390625,
        "other": 0.19921875,
        "auxiliary": 0.03958002105355263
      },
      "gradients": {
        "touch": {
          "gripper_norm": 0.32165560126304626,
          "other_norm": 0.3536248207092285,
          "auxiliary_norm": 0.15737801790237427,
          "gripper_aux_cosine": -0.1013992503285408,
          "weighted_gripper_norm": 0.02297540009021759,
          "weighted_other_norm": 0.32836589217185974
        },
        "proprio": {
          "gripper_norm": 0.08525213599205017,
          "other_norm": 0.16474097967147827,
          "auxiliary_norm": 0.0069924709387123585,
          "gripper_aux_cosine": -0.0020527716260403395,
          "weighted_gripper_norm": 0.0060894382186234,
          "weighted_other_norm": 0.15297377109527588
        },
        "history": {
          "gripper_norm": 0.4671921730041504,
          "other_norm": 0.4267570376396179,
          "auxiliary_norm": 0.029014481231570244,
          "gripper_aux_cosine": -0.025361936539411545,
          "weighted_gripper_norm": 0.03337087109684944,
          "weighted_other_norm": 0.3962743878364563
        },
        "contact_head": {
          "gripper_norm": 0.0,
          "other_norm": 0.0,
          "auxiliary_norm": 0.6203715801239014,
          "gripper_aux_cosine": null,
          "weighted_gripper_norm": 0.0,
          "weighted_other_norm": 0.0
        }
      }
    },
    {
      "pair": 0,
      "preferred": "closed",
      "time": 0.5,
      "losses": {
        "gripper": 0.03759765625,
        "other": 0.1533203125,
        "auxiliary": 0.03958002105355263
      },
      "gradients": {
        "touch": {
          "gripper_norm": 0.06189114600419998,
          "other_norm": 0.45890673995018005,
          "auxiliary_norm": 0.15737801790237427,
          "gripper_aux_cosine": 0.04985103756189346,
          "weighted_gripper_norm": 0.004420795943588018,
          "weighted_other_norm": 0.42612767219543457
        },
        "proprio": {
          "gripper_norm": 0.050163596868515015,
          "other_norm": 0.06927214562892914,
          "auxiliary_norm": 0.0069924709387123585,
          "gripper_aux_cosine": 0.016319995746016502,
          "weighted_gripper_norm": 0.003583114128559828,
          "weighted_other_norm": 0.06432413309812546
        },
        "history": {
          "gripper_norm": 0.04520482197403908,
          "other_norm": 0.1193399503827095,
          "auxiliary_norm": 0.029014481231570244,
          "gripper_aux_cosine": 0.012172698974609375,
          "weighted_gripper_norm": 0.0032289158552885056,
          "weighted_other_norm": 0.11081566661596298
        },
        "contact_head": {
          "gripper_norm": 0.0,
          "other_norm": 0.0,
          "auxiliary_norm": 0.6203715801239014,
          "gripper_aux_cosine": null,
          "weighted_gripper_norm": 0.0,
          "weighted_other_norm": 0.0
        }
      }
    },
    {
      "pair": 0,
      "preferred": "closed",
      "time": 0.9,
      "losses": {
        "gripper": 0.0279541015625,
        "other": 0.1103515625,
        "auxiliary": 0.03958002105355263
      },
      "gradients": {
        "touch": {
          "gripper_norm": 0.2205865979194641,
          "other_norm": 0.4946821331977844,
          "auxiliary_norm": 0.15737801790237427,
          "gripper_aux_cosine": -0.029269477352499962,
          "weighted_gripper_norm": 0.015756186097860336,
          "weighted_other_norm": 0.4593476951122284
        },
        "proprio": {
          "gripper_norm": 0.054418619722127914,
          "other_norm": 0.1367974430322647,
          "auxiliary_norm": 0.0069924709387123585,
          "gripper_aux_cosine": -0.0018350026803091168,
          "weighted_gripper_norm": 0.0038870442658662796,
          "weighted_other_norm": 0.12702620029449463
        },
        "history": {
          "gripper_norm": 0.1841292679309845,
          "other_norm": 0.4286075532436371,
          "auxiliary_norm": 0.029014481231570244,
          "gripper_aux_cosine": -0.018602736294269562,
          "weighted_gripper_norm": 0.013152090832591057,
          "weighted_other_norm": 0.39799270033836365
        },
        "contact_head": {
          "gripper_norm": 0.0,
          "other_norm": 0.0,
          "auxiliary_norm": 0.6203715801239014,
          "gripper_aux_cosine": null,
          "weighted_gripper_norm": 0.0,
          "weighted_other_norm": 0.0
        }
      }
    },
    {
      "pair": 1,
      "preferred": "abort",
      "time": 0.1,
      "losses": {
        "gripper": 0.1865234375,
        "other": 0.1708984375,
        "auxiliary": 0.12794478237628937
      },
      "gradients": {
        "touch": {
          "gripper_norm": 0.8301981687545776,
          "other_norm": 0.22725391387939453,
          "auxiliary_norm": 0.12886738777160645,
          "gripper_aux_cosine": -0.0228370800614357,
          "weighted_gripper_norm": 0.05929986760020256,
          "weighted_other_norm": 0.21102149784564972
        },
        "proprio": {
          "gripper_norm": 0.2294006049633026,
          "other_norm": 0.1379191279411316,
          "auxiliary_norm": 0.005951909348368645,
          "gripper_aux_cosine": -0.015080713666975498,
          "weighted_gripper_norm": 0.01638575829565525,
          "weighted_other_norm": 0.1280677616596222
        },
        "history": {
          "gripper_norm": 2.4638254642486572,
          "other_norm": 0.18576663732528687,
          "auxiliary_norm": 0.024675408378243446,
          "gripper_aux_cosine": 0.01332945004105568,
          "weighted_gripper_norm": 0.17598752677440643,
          "weighted_other_norm": 0.17249760031700134
        },
        "contact_head": {
          "gripper_norm": 0.0,
          "other_norm": 0.0,
          "auxiliary_norm": 0.5205193758010864,
          "gripper_aux_cosine": null,
          "weighted_gripper_norm": 0.0,
          "weighted_other_norm": 0.0
        }
      }
    },
    {
      "pair": 1,
      "preferred": "abort",
      "time": 0.5,
      "losses": {
        "gripper": 0.79296875,
        "other": 0.1416015625,
        "auxiliary": 0.12794478237628937
      },
      "gradients": {
        "touch": {
          "gripper_norm": 0.9800135493278503,
          "other_norm": 0.38599440455436707,
          "auxiliary_norm": 0.12886738777160645,
          "gripper_aux_cosine": 0.06287293881177902,
          "weighted_gripper_norm": 0.07000096887350082,
          "weighted_other_norm": 0.3584233820438385
        },
        "proprio": {
          "gripper_norm": 0.08865458518266678,
          "other_norm": 0.051099687814712524,
          "auxiliary_norm": 0.005951909348368645,
          "gripper_aux_cosine": 0.046795859932899475,
          "weighted_gripper_norm": 0.006332470569759607,
          "weighted_other_norm": 0.047449707984924316
        },
        "history": {
          "gripper_norm": 0.3300166130065918,
          "other_norm": 0.1454877108335495,
          "auxiliary_norm": 0.024675408378243446,
          "gripper_aux_cosine": 0.0011480818502604961,
          "weighted_gripper_norm": 0.023572614416480064,
          "weighted_other_norm": 0.1350957304239273
        },
        "contact_head": {
          "gripper_norm": 0.0,
          "other_norm": 0.0,
          "auxiliary_norm": 0.5205193758010864,
          "gripper_aux_cosine": null,
          "weighted_gripper_norm": 0.0,
          "weighted_other_norm": 0.0
        }
      }
    },
    {
      "pair": 1,
      "preferred": "abort",
      "time": 0.9,
      "losses": {
        "gripper": 1.7421875,
        "other": 0.1240234375,
        "auxiliary": 0.12794478237628937
      },
      "gradients": {
        "touch": {
          "gripper_norm": 0.29206106066703796,
          "other_norm": 0.38281795382499695,
          "auxiliary_norm": 0.12886738777160645,
          "gripper_aux_cosine": 0.0020360401831567287,
          "weighted_gripper_norm": 0.02086150459945202,
          "weighted_other_norm": 0.3554738163948059
        },
        "proprio": {
          "gripper_norm": 0.15950149297714233,
          "other_norm": 0.15600760281085968,
          "auxiliary_norm": 0.005951909348368645,
          "gripper_aux_cosine": 0.018223075196146965,
          "weighted_gripper_norm": 0.01139296405017376,
          "weighted_other_norm": 0.14486420154571533
        },
        "history": {
          "gripper_norm": 0.35467711091041565,
          "other_norm": 0.5015896558761597,
          "auxiliary_norm": 0.024675408378243446,
          "gripper_aux_cosine": 0.004535478074103594,
          "weighted_gripper_norm": 0.025334078818559647,
          "weighted_other_norm": 0.46576184034347534
        },
        "contact_head": {
          "gripper_norm": 0.0,
          "other_norm": 0.0,
          "auxiliary_norm": 0.5205193758010864,
          "gripper_aux_cosine": null,
          "weighted_gripper_norm": 0.0,
          "weighted_other_norm": 0.0
        }
      }
    },
    {
      "pair": 2,
      "preferred": "closed",
      "time": 0.1,
      "losses": {
        "gripper": 0.1728515625,
        "other": 0.1455078125,
        "auxiliary": 0.044407762587070465
      },
      "gradients": {
        "touch": {
          "gripper_norm": 0.5743141770362854,
          "other_norm": 0.34973207116127014,
          "auxiliary_norm": 0.17146892845630646,
          "gripper_aux_cosine": -0.051268912851810455,
          "weighted_gripper_norm": 0.041022442281246185,
          "weighted_other_norm": 0.32475119829177856
        },
        "proprio": {
          "gripper_norm": 0.08952197432518005,
          "other_norm": 0.10664298385381699,
          "auxiliary_norm": 0.006228470243513584,
          "gripper_aux_cosine": 0.02246001549065113,
          "weighted_gripper_norm": 0.006394426804035902,
          "weighted_other_norm": 0.09902562201023102
        },
        "history": {
          "gripper_norm": 0.9719944000244141,
          "other_norm": 0.12451473623514175,
          "auxiliary_norm": 0.02629857137799263,
          "gripper_aux_cosine": -0.020388875156641006,
          "weighted_gripper_norm": 0.06942816823720932,
          "weighted_other_norm": 0.11562082916498184
        },
        "contact_head": {
          "gripper_norm": 0.0,
          "other_norm": 0.0,
          "auxiliary_norm": 0.5690321326255798,
          "gripper_aux_cosine": null,
          "weighted_gripper_norm": 0.0,
          "weighted_other_norm": 0.0
        }
      }
    },
    {
      "pair": 2,
      "preferred": "closed",
      "time": 0.5,
      "losses": {
        "gripper": 0.029541015625,
        "other": 0.054443359375,
        "auxiliary": 0.044407762587070465
      },
      "gradients": {
        "touch": {
          "gripper_norm": 0.0329626128077507,
          "other_norm": 0.4474636912345886,
          "auxiliary_norm": 0.17146892845630646,
          "gripper_aux_cosine": -0.03408811241388321,
          "weighted_gripper_norm": 0.0023544724099338055,
          "weighted_other_norm": 0.41550201177597046
        },
        "proprio": {
          "gripper_norm": 0.0037216644268482924,
          "other_norm": 0.04654969274997711,
          "auxiliary_norm": 0.006228470243513584,
          "gripper_aux_cosine": 0.0006625704118050635,
          "weighted_gripper_norm": 0.00026583316503092647,
          "weighted_other_norm": 0.04322471469640732
        },
        "history": {
          "gripper_norm": 0.1640852838754654,
          "other_norm": 0.11165441572666168,
          "auxiliary_norm": 0.02629857137799263,
          "gripper_aux_cosine": -0.021721256896853447,
          "weighted_gripper_norm": 0.011720377020537853,
          "weighted_other_norm": 0.1036791056394577
        },
        "contact_head": {
          "gripper_norm": 0.0,
          "other_norm": 0.0,
          "auxiliary_norm": 0.5690321326255798,
          "gripper_aux_cosine": null,
          "weighted_gripper_norm": 0.0,
          "weighted_other_norm": 0.0
        }
      }
    },
    {
      "pair": 2,
      "preferred": "closed",
      "time": 0.9,
      "losses": {
        "gripper": 0.0303955078125,
        "other": 0.03955078125,
        "auxiliary": 0.044407762587070465
      },
      "gradients": {
        "touch": {
          "gripper_norm": 0.054450929164886475,
          "other_norm": 0.213251531124115,
          "auxiliary_norm": 0.17146892845630646,
          "gripper_aux_cosine": 0.012626152485609055,
          "weighted_gripper_norm": 0.0038893520832061768,
          "weighted_other_norm": 0.19801928102970123
        },
        "proprio": {
          "gripper_norm": 0.015634145587682724,
          "other_norm": 0.0519651360809803,
          "auxiliary_norm": 0.006228470243513584,
          "gripper_aux_cosine": 0.034211933612823486,
          "weighted_gripper_norm": 0.0011167246848344803,
          "weighted_other_norm": 0.048253338783979416
        },
        "history": {
          "gripper_norm": 0.16667410731315613,
          "other_norm": 0.16313660144805908,
          "auxiliary_norm": 0.02629857137799263,
          "gripper_aux_cosine": -0.0031753627117723227,
          "weighted_gripper_norm": 0.011905292980372906,
          "weighted_other_norm": 0.15148398280143738
        },
        "contact_head": {
          "gripper_norm": 0.0,
          "other_norm": 0.0,
          "auxiliary_norm": 0.5690321326255798,
          "gripper_aux_cosine": null,
          "weighted_gripper_norm": 0.0,
          "weighted_other_norm": 0.0
        }
      }
    },
    {
      "pair": 3,
      "preferred": "abort",
      "time": 0.1,
      "losses": {
        "gripper": 0.2314453125,
        "other": 0.162109375,
        "auxiliary": 0.1098821759223938
      },
      "gradients": {
        "touch": {
          "gripper_norm": 0.4499060809612274,
          "other_norm": 0.4722110629081726,
          "auxiliary_norm": 0.1892680674791336,
          "gripper_aux_cosine": -0.009515737183392048,
          "weighted_gripper_norm": 0.03213614970445633,
          "weighted_other_norm": 0.43848171830177307
        },
        "proprio": {
          "gripper_norm": 0.1396232396364212,
          "other_norm": 0.1359238475561142,
          "auxiliary_norm": 0.007132430095225573,
          "gripper_aux_cosine": -0.025727540254592896,
          "weighted_gripper_norm": 0.009973088279366493,
          "weighted_other_norm": 0.12621499598026276
        },
        "history": {
          "gripper_norm": 0.22157402336597443,
          "other_norm": 0.1032542735338211,
          "auxiliary_norm": 0.03008441813290119,
          "gripper_aux_cosine": -0.014938446693122387,
          "weighted_gripper_norm": 0.015826715156435966,
          "weighted_other_norm": 0.095878966152668
        },
        "contact_head": {
          "gripper_norm": 0.0,
          "other_norm": 0.0,
          "auxiliary_norm": 0.6610583662986755,
          "gripper_aux_cosine": null,
          "weighted_gripper_norm": 0.0,
          "weighted_other_norm": 0.0
        }
      }
    },
    {
      "pair": 3,
      "preferred": "abort",
      "time": 0.5,
      "losses": {
        "gripper": 0.68359375,
        "other": 0.048095703125,
        "auxiliary": 0.1098821759223938
      },
      "gradients": {
        "touch": {
          "gripper_norm": 2.2410728931427,
          "other_norm": 0.3327447474002838,
          "auxiliary_norm": 0.1892680674791336,
          "gripper_aux_cosine": -0.019281793385744095,
          "weighted_gripper_norm": 0.16007663309574127,
          "weighted_other_norm": 0.30897727608680725
        },
        "proprio": {
          "gripper_norm": 0.20045875012874603,
          "other_norm": 0.03604885935783386,
          "auxiliary_norm": 0.007132430095225573,
          "gripper_aux_cosine": -0.06019701808691025,
          "weighted_gripper_norm": 0.014318482019007206,
          "weighted_other_norm": 0.033473942428827286
        },
        "history": {
          "gripper_norm": 0.9093941450119019,
          "other_norm": 0.06584704667329788,
          "auxiliary_norm": 0.03008441813290119,
          "gripper_aux_cosine": 0.016604745760560036,
          "weighted_gripper_norm": 0.06495672464370728,
          "weighted_other_norm": 0.06114368885755539
        },
        "contact_head": {
          "gripper_norm": 0.0,
          "other_norm": 0.0,
          "auxiliary_norm": 0.6610583662986755,
          "gripper_aux_cosine": null,
          "weighted_gripper_norm": 0.0,
          "weighted_other_norm": 0.0
        }
      }
    },
    {
      "pair": 3,
      "preferred": "abort",
      "time": 0.9,
      "losses": {
        "gripper": 1.78125,
        "other": 0.0419921875,
        "auxiliary": 0.1098821759223938
      },
      "gradients": {
        "touch": {
          "gripper_norm": 0.27469030022621155,
          "other_norm": 0.19792932271957397,
          "auxiliary_norm": 0.1892680674791336,
          "gripper_aux_cosine": 0.06737330555915833,
          "weighted_gripper_norm": 0.019620735198259354,
          "weighted_other_norm": 0.18379151821136475
        },
        "proprio": {
          "gripper_norm": 0.14205020666122437,
          "other_norm": 0.07001814991235733,
          "auxiliary_norm": 0.007132430095225573,
          "gripper_aux_cosine": 0.025403747335076332,
          "weighted_gripper_norm": 0.010146443732082844,
          "weighted_other_norm": 0.06501685082912445
        },
        "history": {
          "gripper_norm": 0.26404714584350586,
          "other_norm": 0.24235084652900696,
          "auxiliary_norm": 0.03008441813290119,
          "gripper_aux_cosine": -0.0010253289947286248,
          "weighted_gripper_norm": 0.018860509619116783,
          "weighted_other_norm": 0.22504007816314697
        },
        "contact_head": {
          "gripper_norm": 0.0,
          "other_norm": 0.0,
          "auxiliary_norm": 0.6610583662986755,
          "gripper_aux_cosine": null,
          "weighted_gripper_norm": 0.0,
          "weighted_other_norm": 0.0
        }
      }
    }
  ],
  "optimizer_steps": 0,
  "scope": "trained true model; fixed training observations and three FM times; no generation or task success claim"
}
```
