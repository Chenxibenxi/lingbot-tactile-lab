# VLA局部动作学习对照：zero

实际更新触觉时序适配器和动作条件接触头，主干冻结。micro-batch=1，global-batch=1，AdamW学习率1e-4，上限8次更新。四个训练决策循环两遍，各步固定噪声与训练前参考；辅助权重0.1、排序权重0.25。此为训练能力试验，尚无匹配对照或独立仿真评测；不同步的样本和噪声不同，曲线不可直接视为收敛趋势。

![loss](loss.png)

```json
{
  "status": "completed",
  "error": null,
  "optimizer_steps": 8,
  "elapsed_seconds": 29.29648208618164,
  "rows": [
    {
      "step": 1,
      "pair": 0,
      "loss": 0.4296613335609436,
      "action_loss": 0.255859375,
      "reference_rejected": 0.263671875,
      "gradient_norm": 1.1909338235855103,
      "seconds": 0.3428750370076159
    },
    {
      "step": 2,
      "pair": 1,
      "loss": 0.40571558475494385,
      "action_loss": 0.244140625,
      "reference_rejected": 0.2099609375,
      "gradient_norm": 0.5562477707862854,
      "seconds": 0.24257344000216108
    },
    {
      "step": 3,
      "pair": 2,
      "loss": 0.22717417776584625,
      "action_loss": 0.068359375,
      "reference_rejected": 0.166015625,
      "gradient_norm": 0.856295645236969,
      "seconds": 0.24508735501149204
    },
    {
      "step": 4,
      "pair": 3,
      "loss": 0.3191937208175659,
      "action_loss": 0.1650390625,
      "reference_rejected": 0.154296875,
      "gradient_norm": 0.7018609642982483,
      "seconds": 0.2410658270091517
    },
    {
      "step": 5,
      "pair": 0,
      "loss": 0.36230897903442383,
      "action_loss": 0.216796875,
      "reference_rejected": 0.244140625,
      "gradient_norm": 1.0582913160324097,
      "seconds": 0.24009987400495447
    },
    {
      "step": 6,
      "pair": 1,
      "loss": 0.4783991575241089,
      "action_loss": 0.306640625,
      "reference_rejected": 0.1982421875,
      "gradient_norm": 1.0328139066696167,
      "seconds": 0.24287342600291595
    },
    {
      "step": 7,
      "pair": 2,
      "loss": 0.26320239901542664,
      "action_loss": 0.12451171875,
      "reference_rejected": 0.15234375,
      "gradient_norm": 0.8217713236808777,
      "seconds": 0.23898929699498694
    },
    {
      "step": 8,
      "pair": 3,
      "loss": 0.3283129036426544,
      "action_loss": 0.1748046875,
      "reference_rejected": 0.1396484375,
      "gradient_norm": 0.6819482445716858,
      "seconds": 0.2419188260100782
    }
  ],
  "independent_evaluation": false,
  "modality": "zero",
  "scope": "two training seeds, four local action decisions; capability fit only, not recovery or generalization"
}
```
