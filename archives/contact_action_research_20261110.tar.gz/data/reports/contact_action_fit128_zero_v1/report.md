# VLA局部动作学习对照：zero

实际更新触觉时序适配器和动作条件接触头，主干冻结。micro-batch=1，global-batch=1，AdamW学习率1e-4，上限128次更新。四个训练决策循环32遍，各步固定噪声与训练前参考；辅助权重0.1、排序权重0.25。此为训练能力试验，尚无匹配对照或独立仿真评测；不同步的样本和噪声不同，曲线不可直接视为收敛趋势。

![loss](loss.png)

```json
{
  "status": "completed",
  "error": null,
  "optimizer_steps": 128,
  "elapsed_seconds": 71.08665823936462,
  "rows": [
    {
      "step": 1,
      "pair": 0,
      "loss": 0.4296613335609436,
      "action_loss": 0.255859375,
      "reference_rejected": 0.263671875,
      "gradient_norm": 1.1909338235855103,
      "seconds": 0.3189493069949094
    },
    {
      "step": 2,
      "pair": 1,
      "loss": 0.40571558475494385,
      "action_loss": 0.244140625,
      "reference_rejected": 0.2099609375,
      "gradient_norm": 0.5562477707862854,
      "seconds": 0.2439949060062645
    },
    {
      "step": 3,
      "pair": 2,
      "loss": 0.22717417776584625,
      "action_loss": 0.068359375,
      "reference_rejected": 0.166015625,
      "gradient_norm": 0.856295645236969,
      "seconds": 0.24240613100118935
    },
    {
      "step": 4,
      "pair": 3,
      "loss": 0.3191937208175659,
      "action_loss": 0.1650390625,
      "reference_rejected": 0.154296875,
      "gradient_norm": 0.7018609642982483,
      "seconds": 0.2430547959957039
    },
    {
      "step": 5,
      "pair": 0,
      "loss": 0.36230897903442383,
      "action_loss": 0.216796875,
      "reference_rejected": 0.244140625,
      "gradient_norm": 1.0582913160324097,
      "seconds": 0.2429187660018215
    },
    {
      "step": 6,
      "pair": 1,
      "loss": 0.4783991575241089,
      "action_loss": 0.306640625,
      "reference_rejected": 0.1982421875,
      "gradient_norm": 1.0328139066696167,
      "seconds": 0.2433598530042218
    },
    {
      "step": 7,
      "pair": 2,
      "loss": 0.26320239901542664,
      "action_loss": 0.12451171875,
      "reference_rejected": 0.15234375,
      "gradient_norm": 0.8217713236808777,
      "seconds": 0.2421523770026397
    },
    {
      "step": 8,
      "pair": 3,
      "loss": 0.3283129036426544,
      "action_loss": 0.1748046875,
      "reference_rejected": 0.1396484375,
      "gradient_norm": 0.6819482445716858,
      "seconds": 0.24530608899658546
    },
    {
      "step": 9,
      "pair": 0,
      "loss": 0.3675369918346405,
      "action_loss": 0.2431640625,
      "reference_rejected": 0.2890625,
      "gradient_norm": 1.0066121816635132,
      "seconds": 0.24122183199506253
    },
    {
      "step": 10,
      "pair": 1,
      "loss": 0.30682867765426636,
      "action_loss": 0.1630859375,
      "reference_rejected": 0.1416015625,
      "gradient_norm": 0.494395911693573,
      "seconds": 0.2412366210046457
    },
    {
      "step": 11,
      "pair": 2,
      "loss": 0.24214868247509003,
      "action_loss": 0.11865234375,
      "reference_rejected": 0.11279296875,
      "gradient_norm": 0.7772915959358215,
      "seconds": 0.2440496609924594
    },
    {
      "step": 12,
      "pair": 3,
      "loss": 0.3853365182876587,
      "action_loss": 0.216796875,
      "reference_rejected": 0.10009765625,
      "gradient_norm": 0.6669929027557373,
      "seconds": 0.24463555599504616
    },
    {
      "step": 13,
      "pair": 0,
      "loss": 0.28637564182281494,
      "action_loss": 0.1796875,
      "reference_rejected": 0.2470703125,
      "gradient_norm": 0.9223575592041016,
      "seconds": 0.2426913550007157
    },
    {
      "step": 14,
      "pair": 1,
      "loss": 0.42045313119888306,
      "action_loss": 0.25390625,
      "reference_rejected": 0.1259765625,
      "gradient_norm": 0.49602988362312317,
      "seconds": 0.24255767998693045
    },
    {
      "step": 15,
      "pair": 2,
      "loss": 0.19858334958553314,
      "action_loss": 0.0908203125,
      "reference_rejected": 0.1162109375,
      "gradient_norm": 0.7210982441902161,
      "seconds": 0.2451009479991626
    },
    {
      "step": 16,
      "pair": 3,
      "loss": 0.2686556875705719,
      "action_loss": 0.125,
      "reference_rejected": 0.09228515625,
      "gradient_norm": 0.588657796382904,
      "seconds": 0.2437355430010939
    },
    {
      "step": 17,
      "pair": 0,
      "loss": 0.22689853608608246,
      "action_loss": 0.134765625,
      "reference_rejected": 0.1630859375,
      "gradient_norm": 0.9113913774490356,
      "seconds": 0.24107288700179197
    },
    {
      "step": 18,
      "pair": 1,
      "loss": 0.4271158277988434,
      "action_loss": 0.263671875,
      "reference_rejected": 0.140625,
      "gradient_norm": 1.0117840766906738,
      "seconds": 0.24232670999481343
    },
    {
      "step": 19,
      "pair": 2,
      "loss": 0.18841594457626343,
      "action_loss": 0.0927734375,
      "reference_rejected": 0.1337890625,
      "gradient_norm": 0.6911195516586304,
      "seconds": 0.24431578199437354
    },
    {
      "step": 20,
      "pair": 3,
      "loss": 0.3473226726055145,
      "action_loss": 0.1875,
      "reference_rejected": 0.0791015625,
      "gradient_norm": 0.5976004600524902,
      "seconds": 0.24160022199794184
    },
    {
      "step": 21,
      "pair": 0,
      "loss": 0.25793370604515076,
      "action_loss": 0.177734375,
      "reference_rejected": 0.28125,
      "gradient_norm": 0.8279064893722534,
      "seconds": 0.242350180997164
    },
    {
      "step": 22,
      "pair": 1,
      "loss": 0.3564187288284302,
      "action_loss": 0.2197265625,
      "reference_rejected": 0.201171875,
      "gradient_norm": 0.4887121021747589,
      "seconds": 0.24175928499607835
    },
    {
      "step": 23,
      "pair": 2,
      "loss": 0.2125767320394516,
      "action_loss": 0.126953125,
      "reference_rejected": 0.197265625,
      "gradient_norm": 0.6912593841552734,
      "seconds": 0.2421426189976046
    },
    {
      "step": 24,
      "pair": 3,
      "loss": 0.3648911714553833,
      "action_loss": 0.2041015625,
      "reference_rejected": 0.0849609375,
      "gradient_norm": 0.6111702919006348,
      "seconds": 0.2423322379909223
    },
    {
      "step": 25,
      "pair": 0,
      "loss": 0.17581744492053986,
      "action_loss": 0.10498046875,
      "reference_rejected": 0.1689453125,
      "gradient_norm": 0.7651183605194092,
      "seconds": 0.24478458399244118
    },
    {
      "step": 26,
      "pair": 1,
      "loss": 0.3210621476173401,
      "action_loss": 0.1884765625,
      "reference_rejected": 0.1923828125,
      "gradient_norm": 0.48743242025375366,
      "seconds": 0.24016200700134505
    },
    {
      "step": 27,
      "pair": 2,
      "loss": 0.14108768105506897,
      "action_loss": 0.0634765625,
      "reference_rejected": 0.1484375,
      "gradient_norm": 0.6145706176757812,
      "seconds": 0.24366604200622533
    },
    {
      "step": 28,
      "pair": 3,
      "loss": 0.3811255395412445,
      "action_loss": 0.21875,
      "reference_rejected": 0.0888671875,
      "gradient_norm": 1.3991916179656982,
      "seconds": 0.24327068201091606
    },
    {
      "step": 29,
      "pair": 0,
      "loss": 0.22550944983959198,
      "action_loss": 0.162109375,
      "reference_rejected": 0.2138671875,
      "gradient_norm": 0.7114980220794678,
      "seconds": 0.24159993800276425
    },
    {
      "step": 30,
      "pair": 1,
      "loss": 0.27157148718833923,
      "action_loss": 0.1376953125,
      "reference_rejected": 0.166015625,
      "gradient_norm": 0.5442965030670166,
      "seconds": 0.24390046000189614
    },
    {
      "step": 31,
      "pair": 2,
      "loss": 0.1393715739250183,
      "action_loss": 0.068359375,
      "reference_rejected": 0.1396484375,
      "gradient_norm": 0.5830572843551636,
      "seconds": 0.24630948100821115
    },
    {
      "step": 32,
      "pair": 3,
      "loss": 0.23745286464691162,
      "action_loss": 0.10498046875,
      "reference_rejected": 0.09375,
      "gradient_norm": 0.6317157745361328,
      "seconds": 0.24342746399634052
    },
    {
      "step": 33,
      "pair": 0,
      "loss": 0.2304479032754898,
      "action_loss": 0.1728515625,
      "reference_rejected": 0.203125,
      "gradient_norm": 0.6851643919944763,
      "seconds": 0.24410718999570236
    },
    {
      "step": 34,
      "pair": 1,
      "loss": 0.2731073796749115,
      "action_loss": 0.1376953125,
      "reference_rejected": 0.1708984375,
      "gradient_norm": 0.5483580231666565,
      "seconds": 0.24092447700968478
    },
    {
      "step": 35,
      "pair": 2,
      "loss": 0.12137475609779358,
      "action_loss": 0.055419921875,
      "reference_rejected": 0.20703125,
      "gradient_norm": 0.592193603515625,
      "seconds": 0.2418411329999799
    },
    {
      "step": 36,
      "pair": 3,
      "loss": 0.28266632556915283,
      "action_loss": 0.1533203125,
      "reference_rejected": 0.2275390625,
      "gradient_norm": 0.7250951528549194,
      "seconds": 0.24336193599447142
    },
    {
      "step": 37,
      "pair": 0,
      "loss": 0.23415164649486542,
      "action_loss": 0.1806640625,
      "reference_rejected": 0.279296875,
      "gradient_norm": 0.6753686666488647,
      "seconds": 0.23981276000267826
    },
    {
      "step": 38,
      "pair": 1,
      "loss": 0.2880077660083771,
      "action_loss": 0.1513671875,
      "reference_rejected": 0.154296875,
      "gradient_norm": 0.5911808013916016,
      "seconds": 0.24344652899890207
    },
    {
      "step": 39,
      "pair": 2,
      "loss": 0.13353519141674042,
      "action_loss": 0.0712890625,
      "reference_rejected": 0.12353515625,
      "gradient_norm": 0.5518932342529297,
      "seconds": 0.24153651400411036
    },
    {
      "step": 40,
      "pair": 3,
      "loss": 0.35115522146224976,
      "action_loss": 0.1953125,
      "reference_rejected": 0.08642578125,
      "gradient_norm": 0.654502272605896,
      "seconds": 0.2415609570016386
    },
    {
      "step": 41,
      "pair": 0,
      "loss": 0.18431641161441803,
      "action_loss": 0.1337890625,
      "reference_rejected": 0.16796875,
      "gradient_norm": 0.6595715284347534,
      "seconds": 0.2987223300006008
    },
    {
      "step": 42,
      "pair": 1,
      "loss": 0.4032333195209503,
      "action_loss": 0.244140625,
      "reference_rejected": 0.158203125,
      "gradient_norm": 0.8138489127159119,
      "seconds": 0.25019459299801383
    },
    {
      "step": 43,
      "pair": 2,
      "loss": 0.2580634653568268,
      "action_loss": 0.1982421875,
      "reference_rejected": 0.306640625,
      "gradient_norm": 0.6886383295059204,
      "seconds": 0.24236127799667884
    },
    {
      "step": 44,
      "pair": 3,
      "loss": 0.2786659896373749,
      "action_loss": 0.1396484375,
      "reference_rejected": 0.09423828125,
      "gradient_norm": 0.6366089582443237,
      "seconds": 0.24461229899316095
    },
    {
      "step": 45,
      "pair": 0,
      "loss": 0.23419226706027985,
      "action_loss": 0.185546875,
      "reference_rejected": 0.263671875,
      "gradient_norm": 0.7110022902488708,
      "seconds": 0.24322104500606656
    },
    {
      "step": 46,
      "pair": 1,
      "loss": 0.2556423842906952,
      "action_loss": 0.11767578125,
      "reference_rejected": 0.1318359375,
      "gradient_norm": 0.574769914150238,
      "seconds": 0.24396021600114182
    },
    {
      "step": 47,
      "pair": 2,
      "loss": 0.1212637647986412,
      "action_loss": 0.0634765625,
      "reference_rejected": 0.1982421875,
      "gradient_norm": 0.5497133731842041,
      "seconds": 0.24359831199399196
    },
    {
      "step": 48,
      "pair": 3,
      "loss": 0.21108892560005188,
      "action_loss": 0.08447265625,
      "reference_rejected": 0.1435546875,
      "gradient_norm": 0.6462852358818054,
      "seconds": 0.24432011200406123
    },
    {
      "step": 49,
      "pair": 0,
      "loss": 0.17502161860466003,
      "action_loss": 0.1279296875,
      "reference_rejected": 0.1923828125,
      "gradient_norm": 0.6172831654548645,
      "seconds": 0.2412261099962052
    },
    {
      "step": 50,
      "pair": 1,
      "loss": 0.2923716902732849,
      "action_loss": 0.154296875,
      "reference_rejected": 0.16796875,
      "gradient_norm": 0.5840538144111633,
      "seconds": 0.24275901100190822
    },
    {
      "step": 51,
      "pair": 2,
      "loss": 0.12977303564548492,
      "action_loss": 0.0732421875,
      "reference_rejected": 0.1513671875,
      "gradient_norm": 0.5450286865234375,
      "seconds": 0.2410486220032908
    },
    {
      "step": 52,
      "pair": 3,
      "loss": 0.21556460857391357,
      "action_loss": 0.09033203125,
      "reference_rejected": 0.1650390625,
      "gradient_norm": 0.6586707830429077,
      "seconds": 0.24490013600734528
    },
    {
      "step": 53,
      "pair": 0,
      "loss": 0.18105143308639526,
      "action_loss": 0.134765625,
      "reference_rejected": 0.19140625,
      "gradient_norm": 0.6101841330528259,
      "seconds": 0.24044752400368452
    },
    {
      "step": 54,
      "pair": 1,
      "loss": 0.42199426889419556,
      "action_loss": 0.259765625,
      "reference_rejected": 0.1630859375,
      "gradient_norm": 0.8627554178237915,
      "seconds": 0.2421459430042887
    },
    {
      "step": 55,
      "pair": 2,
      "loss": 0.1172785758972168,
      "action_loss": 0.0615234375,
      "reference_rejected": 0.13671875,
      "gradient_norm": 0.5850558280944824,
      "seconds": 0.24261326200212352
    },
    {
      "step": 56,
      "pair": 3,
      "loss": 0.22133994102478027,
      "action_loss": 0.09765625,
      "reference_rejected": 0.10986328125,
      "gradient_norm": 0.6332746744155884,
      "seconds": 0.24121830500371289
    },
    {
      "step": 57,
      "pair": 0,
      "loss": 0.19620752334594727,
      "action_loss": 0.150390625,
      "reference_rejected": 0.26953125,
      "gradient_norm": 0.6564075350761414,
      "seconds": 0.24136594499577768
    },
    {
      "step": 58,
      "pair": 1,
      "loss": 0.26209211349487305,
      "action_loss": 0.12451171875,
      "reference_rejected": 0.150390625,
      "gradient_norm": 0.6016824245452881,
      "seconds": 0.2438738639903022
    },
    {
      "step": 59,
      "pair": 2,
      "loss": 0.09952176362276077,
      "action_loss": 0.044189453125,
      "reference_rejected": 0.2275390625,
      "gradient_norm": 0.529455840587616,
      "seconds": 0.24154964700574055
    },
    {
      "step": 60,
      "pair": 3,
      "loss": 0.285319447517395,
      "action_loss": 0.150390625,
      "reference_rejected": 0.09912109375,
      "gradient_norm": 0.7608851194381714,
      "seconds": 0.24138053199567366
    },
    {
      "step": 61,
      "pair": 0,
      "loss": 0.23021693527698517,
      "action_loss": 0.1845703125,
      "reference_rejected": 0.271484375,
      "gradient_norm": 0.6319147944450378,
      "seconds": 0.24506541699520312
    },
    {
      "step": 62,
      "pair": 1,
      "loss": 0.34121960401535034,
      "action_loss": 0.1923828125,
      "reference_rejected": 0.1455078125,
      "gradient_norm": 1.464389681816101,
      "seconds": 0.2439193210011581
    },
    {
      "step": 63,
      "pair": 2,
      "loss": 0.13312028348445892,
      "action_loss": 0.078125,
      "reference_rejected": 0.10009765625,
      "gradient_norm": 1.5326862335205078,
      "seconds": 0.24420123800518923
    },
    {
      "step": 64,
      "pair": 3,
      "loss": 0.3624584972858429,
      "action_loss": 0.212890625,
      "reference_rejected": 0.09765625,
      "gradient_norm": 0.8743967413902283,
      "seconds": 0.24176918101147749
    },
    {
      "step": 65,
      "pair": 0,
      "loss": 0.18186211585998535,
      "action_loss": 0.13671875,
      "reference_rejected": 0.251953125,
      "gradient_norm": 0.6965420246124268,
      "seconds": 0.24468004000664223
    },
    {
      "step": 66,
      "pair": 1,
      "loss": 0.3440713882446289,
      "action_loss": 0.20703125,
      "reference_rejected": 0.30078125,
      "gradient_norm": 0.7011890411376953,
      "seconds": 0.241901532994234
    },
    {
      "step": 67,
      "pair": 2,
      "loss": 0.12696096301078796,
      "action_loss": 0.072265625,
      "reference_rejected": 0.2001953125,
      "gradient_norm": 0.7179042100906372,
      "seconds": 0.244625688996166
    },
    {
      "step": 68,
      "pair": 3,
      "loss": 0.3310110867023468,
      "action_loss": 0.185546875,
      "reference_rejected": 0.08154296875,
      "gradient_norm": 0.6297500133514404,
      "seconds": 0.24051550100557506
    },
    {
      "step": 69,
      "pair": 0,
      "loss": 0.16936016082763672,
      "action_loss": 0.12451171875,
      "reference_rejected": 0.2314453125,
      "gradient_norm": 0.6979711651802063,
      "seconds": 0.24265366001054645
    },
    {
      "step": 70,
      "pair": 1,
      "loss": 0.2602299451828003,
      "action_loss": 0.12353515625,
      "reference_rejected": 0.12890625,
      "gradient_norm": 0.7348743081092834,
      "seconds": 0.24089078299584799
    },
    {
      "step": 71,
      "pair": 2,
      "loss": 0.12124066799879074,
      "action_loss": 0.06689453125,
      "reference_rejected": 0.1611328125,
      "gradient_norm": 0.5912764668464661,
      "seconds": 0.24413605900190305
    },
    {
      "step": 72,
      "pair": 3,
      "loss": 0.30115506052970886,
      "action_loss": 0.1826171875,
      "reference_rejected": 0.24609375,
      "gradient_norm": 0.7016642093658447,
      "seconds": 0.24007609799446072
    },
    {
      "step": 73,
      "pair": 0,
      "loss": 0.17545443773269653,
      "action_loss": 0.130859375,
      "reference_rejected": 0.2001953125,
      "gradient_norm": 0.6605658531188965,
      "seconds": 0.2446782089973567
    },
    {
      "step": 74,
      "pair": 1,
      "loss": 0.2955062687397003,
      "action_loss": 0.1591796875,
      "reference_rejected": 0.17578125,
      "gradient_norm": 0.5505093336105347,
      "seconds": 0.2399174130114261
    },
    {
      "step": 75,
      "pair": 2,
      "loss": 0.09814160317182541,
      "action_loss": 0.0439453125,
      "reference_rejected": 0.1953125,
      "gradient_norm": 0.5495786666870117,
      "seconds": 0.24301162399933673
    },
    {
      "step": 76,
      "pair": 3,
      "loss": 0.3105629086494446,
      "action_loss": 0.171875,
      "reference_rejected": 0.08544921875,
      "gradient_norm": 0.6857460141181946,
      "seconds": 0.2433982630027458
    },
    {
      "step": 77,
      "pair": 0,
      "loss": 0.17621701955795288,
      "action_loss": 0.1318359375,
      "reference_rejected": 0.2001953125,
      "gradient_norm": 0.6631627678871155,
      "seconds": 0.24246709600265604
    },
    {
      "step": 78,
      "pair": 1,
      "loss": 0.34890326857566833,
      "action_loss": 0.212890625,
      "reference_rejected": 0.2470703125,
      "gradient_norm": 0.6090511083602905,
      "seconds": 0.2414782989944797
    },
    {
      "step": 79,
      "pair": 2,
      "loss": 0.09379533678293228,
      "action_loss": 0.039794921875,
      "reference_rejected": 0.224609375,
      "gradient_norm": 0.5408623814582825,
      "seconds": 0.24513967899838462
    },
    {
      "step": 80,
      "pair": 3,
      "loss": 0.22934703528881073,
      "action_loss": 0.1123046875,
      "reference_rejected": 0.1083984375,
      "gradient_norm": 0.6334360837936401,
      "seconds": 0.2417296899948269
    },
    {
      "step": 81,
      "pair": 0,
      "loss": 0.12189093232154846,
      "action_loss": 0.07763671875,
      "reference_rejected": 0.2890625,
      "gradient_norm": 0.6174709796905518,
      "seconds": 0.24357007099024486
    },
    {
      "step": 82,
      "pair": 1,
      "loss": 0.3261154294013977,
      "action_loss": 0.1904296875,
      "reference_rejected": 0.2431640625,
      "gradient_norm": 0.6262986660003662,
      "seconds": 0.24142549200041685
    },
    {
      "step": 83,
      "pair": 2,
      "loss": 0.09882326424121857,
      "action_loss": 0.044921875,
      "reference_rejected": 0.095703125,
      "gradient_norm": 0.5639804601669312,
      "seconds": 0.2398373040050501
    },
    {
      "step": 84,
      "pair": 3,
      "loss": 0.21369078755378723,
      "action_loss": 0.0986328125,
      "reference_rejected": 0.1328125,
      "gradient_norm": 0.6030829548835754,
      "seconds": 0.24206693700398318
    },
    {
      "step": 85,
      "pair": 0,
      "loss": 0.137848362326622,
      "action_loss": 0.09375,
      "reference_rejected": 0.16796875,
      "gradient_norm": 0.6208500862121582,
      "seconds": 0.24202783999498934
    },
    {
      "step": 86,
      "pair": 1,
      "loss": 0.31298020482063293,
      "action_loss": 0.177734375,
      "reference_rejected": 0.1845703125,
      "gradient_norm": 0.5938742756843567,
      "seconds": 0.322317316007684
    },
    {
      "step": 87,
      "pair": 2,
      "loss": 0.10463356226682663,
      "action_loss": 0.05078125,
      "reference_rejected": 0.228515625,
      "gradient_norm": 0.5425893068313599,
      "seconds": 0.24293366199708544
    },
    {
      "step": 88,
      "pair": 3,
      "loss": 0.3709212839603424,
      "action_loss": 0.21875,
      "reference_rejected": 0.06689453125,
      "gradient_norm": 0.928218424320221,
      "seconds": 0.24467315700894687
    },
    {
      "step": 89,
      "pair": 0,
      "loss": 0.13522180914878845,
      "action_loss": 0.09130859375,
      "reference_rejected": 0.23046875,
      "gradient_norm": 0.657433807849884,
      "seconds": 0.24098261499602813
    },
    {
      "step": 90,
      "pair": 1,
      "loss": 0.2501237988471985,
      "action_loss": 0.115234375,
      "reference_rejected": 0.150390625,
      "gradient_norm": 0.5919683575630188,
      "seconds": 0.2435397869994631
    },
    {
      "step": 91,
      "pair": 2,
      "loss": 0.09321010112762451,
      "action_loss": 0.03955078125,
      "reference_rejected": 0.17578125,
      "gradient_norm": 0.5495055317878723,
      "seconds": 0.24252462699951138
    },
    {
      "step": 92,
      "pair": 3,
      "loss": 0.2482050210237503,
      "action_loss": 0.134765625,
      "reference_rejected": 0.158203125,
      "gradient_norm": 1.0473464727401733,
      "seconds": 0.24461980799969751
    },
    {
      "step": 93,
      "pair": 0,
      "loss": 0.15195679664611816,
      "action_loss": 0.1083984375,
      "reference_rejected": 0.185546875,
      "gradient_norm": 0.6472870111465454,
      "seconds": 0.24162052899191622
    },
    {
      "step": 94,
      "pair": 1,
      "loss": 0.2518821954727173,
      "action_loss": 0.1171875,
      "reference_rejected": 0.201171875,
      "gradient_norm": 0.5501522421836853,
      "seconds": 0.24286073600524105
    },
    {
      "step": 95,
      "pair": 2,
      "loss": 0.10553042590618134,
      "action_loss": 0.05224609375,
      "reference_rejected": 0.1640625,
      "gradient_norm": 0.5854580998420715,
      "seconds": 0.2429147950024344
    },
    {
      "step": 96,
      "pair": 3,
      "loss": 0.19640310108661652,
      "action_loss": 0.08349609375,
      "reference_rejected": 0.1044921875,
      "gradient_norm": 0.6441064476966858,
      "seconds": 0.24301496699627023
    },
    {
      "step": 97,
      "pair": 0,
      "loss": 0.14684903621673584,
      "action_loss": 0.103515625,
      "reference_rejected": 0.26953125,
      "gradient_norm": 0.7649534940719604,
      "seconds": 0.24156809200940188
    },
    {
      "step": 98,
      "pair": 1,
      "loss": 0.2937299907207489,
      "action_loss": 0.1591796875,
      "reference_rejected": 0.197265625,
      "gradient_norm": 0.5990982055664062,
      "seconds": 0.24232144599955063
    },
    {
      "step": 99,
      "pair": 2,
      "loss": 0.11884116381406784,
      "action_loss": 0.06591796875,
      "reference_rejected": 0.12353515625,
      "gradient_norm": 0.6638158559799194,
      "seconds": 0.2414177310129162
    },
    {
      "step": 100,
      "pair": 3,
      "loss": 0.203205868601799,
      "action_loss": 0.09033203125,
      "reference_rejected": 0.08837890625,
      "gradient_norm": 0.6054691672325134,
      "seconds": 0.24181174198747613
    },
    {
      "step": 101,
      "pair": 0,
      "loss": 0.10867968946695328,
      "action_loss": 0.06591796875,
      "reference_rejected": 0.15234375,
      "gradient_norm": 0.6250717043876648,
      "seconds": 0.24178189999656752
    },
    {
      "step": 102,
      "pair": 1,
      "loss": 0.23438425362110138,
      "action_loss": 0.10009765625,
      "reference_rejected": 0.1455078125,
      "gradient_norm": 0.5544847249984741,
      "seconds": 0.24479012399388012
    },
    {
      "step": 103,
      "pair": 2,
      "loss": 0.10129185020923615,
      "action_loss": 0.048583984375,
      "reference_rejected": 0.2578125,
      "gradient_norm": 0.569581151008606,
      "seconds": 0.24056117099826224
    },
    {
      "step": 104,
      "pair": 3,
      "loss": 0.23885101079940796,
      "action_loss": 0.126953125,
      "reference_rejected": 0.1396484375,
      "gradient_norm": 0.8810259103775024,
      "seconds": 0.2422824329987634
    },
    {
      "step": 105,
      "pair": 0,
      "loss": 0.12397225201129913,
      "action_loss": 0.08154296875,
      "reference_rejected": 0.13671875,
      "gradient_norm": 0.7875232696533203,
      "seconds": 0.24292684999818448
    },
    {
      "step": 106,
      "pair": 1,
      "loss": 0.296218603849411,
      "action_loss": 0.162109375,
      "reference_rejected": 0.1875,
      "gradient_norm": 0.6515799164772034,
      "seconds": 0.24132865499996115
    },
    {
      "step": 107,
      "pair": 2,
      "loss": 0.0938548669219017,
      "action_loss": 0.04150390625,
      "reference_rejected": 0.22265625,
      "gradient_norm": 0.5399984121322632,
      "seconds": 0.2413468470040243
    },
    {
      "step": 108,
      "pair": 3,
      "loss": 0.3343038558959961,
      "action_loss": 0.22265625,
      "reference_rejected": 0.322265625,
      "gradient_norm": 1.2885006666183472,
      "seconds": 0.24185390998900402
    },
    {
      "step": 109,
      "pair": 0,
      "loss": 0.10580731928348541,
      "action_loss": 0.06396484375,
      "reference_rejected": 0.26171875,
      "gradient_norm": 0.5934036374092102,
      "seconds": 0.24102505500195548
    },
    {
      "step": 110,
      "pair": 1,
      "loss": 0.2327778935432434,
      "action_loss": 0.0986328125,
      "reference_rejected": 0.171875,
      "gradient_norm": 0.5442332625389099,
      "seconds": 0.24379669000336435
    },
    {
      "step": 111,
      "pair": 2,
      "loss": 0.23934811353683472,
      "action_loss": 0.1875,
      "reference_rejected": 0.2578125,
      "gradient_norm": 0.6593528985977173,
      "seconds": 0.24264252500142902
    },
    {
      "step": 112,
      "pair": 3,
      "loss": 0.29094424843788147,
      "action_loss": 0.16015625,
      "reference_rejected": 0.0830078125,
      "gradient_norm": 0.5998708009719849,
      "seconds": 0.24413771800755057
    },
    {
      "step": 113,
      "pair": 0,
      "loss": 0.1984522044658661,
      "action_loss": 0.1572265625,
      "reference_rejected": 0.271484375,
      "gradient_norm": 1.9083629846572876,
      "seconds": 0.2436962039937498
    },
    {
      "step": 114,
      "pair": 1,
      "loss": 0.31674376130104065,
      "action_loss": 0.1826171875,
      "reference_rejected": 0.2353515625,
      "gradient_norm": 0.7370758056640625,
      "seconds": 0.27822604999528266
    },
    {
      "step": 115,
      "pair": 2,
      "loss": 0.10933889448642731,
      "action_loss": 0.05810546875,
      "reference_rejected": 0.1005859375,
      "gradient_norm": 0.5407231450080872,
      "seconds": 0.24312292400281876
    },
    {
      "step": 116,
      "pair": 3,
      "loss": 0.2859310805797577,
      "action_loss": 0.1748046875,
      "reference_rejected": 0.234375,
      "gradient_norm": 0.7786083817481995,
      "seconds": 0.24020906300575007
    },
    {
      "step": 117,
      "pair": 0,
      "loss": 0.1729440987110138,
      "action_loss": 0.1318359375,
      "reference_rejected": 0.2119140625,
      "gradient_norm": 0.6055562496185303,
      "seconds": 0.24412150800344534
    },
    {
      "step": 118,
      "pair": 1,
      "loss": 0.23949101567268372,
      "action_loss": 0.10595703125,
      "reference_rejected": 0.166015625,
      "gradient_norm": 0.5603813529014587,
      "seconds": 0.24330179700336885
    },
    {
      "step": 119,
      "pair": 2,
      "loss": 0.09809692949056625,
      "action_loss": 0.046875,
      "reference_rejected": 0.1826171875,
      "gradient_norm": 0.6051456928253174,
      "seconds": 0.24305013800039887
    },
    {
      "step": 120,
      "pair": 3,
      "loss": 0.21446029841899872,
      "action_loss": 0.1005859375,
      "reference_rejected": 0.0859375,
      "gradient_norm": 0.5903238654136658,
      "seconds": 0.24023560399655253
    },
    {
      "step": 121,
      "pair": 0,
      "loss": 0.10653536021709442,
      "action_loss": 0.0654296875,
      "reference_rejected": 0.125,
      "gradient_norm": 0.6349352598190308,
      "seconds": 0.2444042649876792
    },
    {
      "step": 122,
      "pair": 1,
      "loss": 0.2619052529335022,
      "action_loss": 0.12890625,
      "reference_rejected": 0.16796875,
      "gradient_norm": 0.6973075866699219,
      "seconds": 0.24241447400709148
    },
    {
      "step": 123,
      "pair": 2,
      "loss": 0.10188141465187073,
      "action_loss": 0.05078125,
      "reference_rejected": 0.1630859375,
      "gradient_norm": 0.5454728007316589,
      "seconds": 0.24262453000119422
    },
    {
      "step": 124,
      "pair": 3,
      "loss": 0.21448375284671783,
      "action_loss": 0.10205078125,
      "reference_rejected": 0.0908203125,
      "gradient_norm": 0.6109136343002319,
      "seconds": 0.24099078499421012
    },
    {
      "step": 125,
      "pair": 0,
      "loss": 0.1082967147231102,
      "action_loss": 0.0673828125,
      "reference_rejected": 0.27734375,
      "gradient_norm": 0.6528484225273132,
      "seconds": 0.2433578740019584
    },
    {
      "step": 126,
      "pair": 1,
      "loss": 0.23868201673030853,
      "action_loss": 0.10595703125,
      "reference_rejected": 0.11865234375,
      "gradient_norm": 0.5652812123298645,
      "seconds": 0.2424993829918094
    },
    {
      "step": 127,
      "pair": 2,
      "loss": 0.1149313673377037,
      "action_loss": 0.06396484375,
      "reference_rejected": 0.2001953125,
      "gradient_norm": 0.5924811363220215,
      "seconds": 0.24284401700424496
    },
    {
      "step": 128,
      "pair": 3,
      "loss": 0.24688853323459625,
      "action_loss": 0.1376953125,
      "reference_rejected": 0.228515625,
      "gradient_norm": 0.9524603486061096,
      "seconds": 0.24155141599476337
    }
  ],
  "independent_evaluation": false,
  "modality": "zero",
  "scope": "two training seeds, four local action decisions; capability fit only, not recovery or generalization"
}
```
