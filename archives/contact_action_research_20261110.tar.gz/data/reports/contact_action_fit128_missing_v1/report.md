# VLA局部动作学习对照：missing

实际更新触觉时序适配器和动作条件接触头，主干冻结。micro-batch=1，global-batch=1，AdamW学习率1e-4，上限128次更新。四个训练决策循环32遍，各步固定噪声与训练前参考；辅助权重0.1、排序权重0.25。此为训练能力试验，尚无匹配对照或独立仿真评测；不同步的样本和噪声不同，曲线不可直接视为收敛趋势。

![loss](loss.png)

```json
{
  "status": "completed",
  "error": null,
  "optimizer_steps": 128,
  "elapsed_seconds": 70.71025681495667,
  "rows": [
    {
      "step": 1,
      "pair": 0,
      "loss": 0.40397173166275024,
      "action_loss": 0.22265625,
      "reference_rejected": 0.2255859375,
      "gradient_norm": 1.6885790824890137,
      "seconds": 0.3330226839898387
    },
    {
      "step": 2,
      "pair": 1,
      "loss": 0.3662674129009247,
      "action_loss": 0.208984375,
      "reference_rejected": 0.1826171875,
      "gradient_norm": 0.743169367313385,
      "seconds": 0.24053810100303963
    },
    {
      "step": 3,
      "pair": 2,
      "loss": 0.23111461102962494,
      "action_loss": 0.0634765625,
      "reference_rejected": 0.177734375,
      "gradient_norm": 1.2633994817733765,
      "seconds": 0.2408359769906383
    },
    {
      "step": 4,
      "pair": 3,
      "loss": 0.31172892451286316,
      "action_loss": 0.158203125,
      "reference_rejected": 0.134765625,
      "gradient_norm": 0.9343484044075012,
      "seconds": 0.23944728099741042
    },
    {
      "step": 5,
      "pair": 0,
      "loss": 0.33157703280448914,
      "action_loss": 0.1806640625,
      "reference_rejected": 0.234375,
      "gradient_norm": 1.5345057249069214,
      "seconds": 0.2401985140022589
    },
    {
      "step": 6,
      "pair": 1,
      "loss": 0.45126810669898987,
      "action_loss": 0.28125,
      "reference_rejected": 0.162109375,
      "gradient_norm": 1.0543839931488037,
      "seconds": 0.24100795299455058
    },
    {
      "step": 7,
      "pair": 2,
      "loss": 0.26255467534065247,
      "action_loss": 0.115234375,
      "reference_rejected": 0.1396484375,
      "gradient_norm": 1.2064342498779297,
      "seconds": 0.2434652150113834
    },
    {
      "step": 8,
      "pair": 3,
      "loss": 0.33387452363967896,
      "action_loss": 0.181640625,
      "reference_rejected": 0.1259765625,
      "gradient_norm": 0.8670505881309509,
      "seconds": 0.23909180599730462
    },
    {
      "step": 9,
      "pair": 0,
      "loss": 0.34182634949684143,
      "action_loss": 0.212890625,
      "reference_rejected": 0.25,
      "gradient_norm": 1.4550235271453857,
      "seconds": 0.24260874099854846
    },
    {
      "step": 10,
      "pair": 1,
      "loss": 0.28448590636253357,
      "action_loss": 0.1455078125,
      "reference_rejected": 0.1201171875,
      "gradient_norm": 0.548803985118866,
      "seconds": 0.23957129899645224
    },
    {
      "step": 11,
      "pair": 2,
      "loss": 0.24737954139709473,
      "action_loss": 0.115234375,
      "reference_rejected": 0.10791015625,
      "gradient_norm": 1.1606624126434326,
      "seconds": 0.24199096900701988
    },
    {
      "step": 12,
      "pair": 3,
      "loss": 0.4284708499908447,
      "action_loss": 0.2578125,
      "reference_rejected": 0.09912109375,
      "gradient_norm": 0.7832207679748535,
      "seconds": 0.2461432470008731
    },
    {
      "step": 13,
      "pair": 0,
      "loss": 0.2699456810951233,
      "action_loss": 0.1591796875,
      "reference_rejected": 0.216796875,
      "gradient_norm": 1.3356075286865234,
      "seconds": 0.24089099898992572
    },
    {
      "step": 14,
      "pair": 1,
      "loss": 0.4124220311641693,
      "action_loss": 0.2490234375,
      "reference_rejected": 0.1083984375,
      "gradient_norm": 0.5398256182670593,
      "seconds": 0.23972912000317592
    },
    {
      "step": 15,
      "pair": 2,
      "loss": 0.2056015282869339,
      "action_loss": 0.08984375,
      "reference_rejected": 0.10302734375,
      "gradient_norm": 1.0868021249771118,
      "seconds": 0.24119675700785592
    },
    {
      "step": 16,
      "pair": 3,
      "loss": 0.2885154187679291,
      "action_loss": 0.1484375,
      "reference_rejected": 0.09130859375,
      "gradient_norm": 0.7563110589981079,
      "seconds": 0.24055493499326985
    },
    {
      "step": 17,
      "pair": 0,
      "loss": 0.2306242138147354,
      "action_loss": 0.134765625,
      "reference_rejected": 0.15234375,
      "gradient_norm": 1.2478049993515015,
      "seconds": 0.2422613939997973
    },
    {
      "step": 18,
      "pair": 1,
      "loss": 0.3964311182498932,
      "action_loss": 0.23828125,
      "reference_rejected": 0.111328125,
      "gradient_norm": 0.6607900857925415,
      "seconds": 0.24022069199418183
    },
    {
      "step": 19,
      "pair": 2,
      "loss": 0.2020171880722046,
      "action_loss": 0.0986328125,
      "reference_rejected": 0.12060546875,
      "gradient_norm": 1.0345330238342285,
      "seconds": 0.24168492898752447
    },
    {
      "step": 20,
      "pair": 3,
      "loss": 0.338696151971817,
      "action_loss": 0.1875,
      "reference_rejected": 0.072265625,
      "gradient_norm": 0.8371049165725708,
      "seconds": 0.2401344359968789
    },
    {
      "step": 21,
      "pair": 0,
      "loss": 0.2604016959667206,
      "action_loss": 0.1767578125,
      "reference_rejected": 0.263671875,
      "gradient_norm": 1.1944189071655273,
      "seconds": 0.2405026589985937
    },
    {
      "step": 22,
      "pair": 1,
      "loss": 0.32459479570388794,
      "action_loss": 0.19140625,
      "reference_rejected": 0.1640625,
      "gradient_norm": 0.5993447303771973,
      "seconds": 0.24015774599683937
    },
    {
      "step": 23,
      "pair": 2,
      "loss": 0.21897733211517334,
      "action_loss": 0.1259765625,
      "reference_rejected": 0.1943359375,
      "gradient_norm": 1.0085923671722412,
      "seconds": 0.24119785799121018
    },
    {
      "step": 24,
      "pair": 3,
      "loss": 0.37181854248046875,
      "action_loss": 0.216796875,
      "reference_rejected": 0.0791015625,
      "gradient_norm": 0.7443320155143738,
      "seconds": 0.24448665499221534
    },
    {
      "step": 25,
      "pair": 0,
      "loss": 0.18017910420894623,
      "action_loss": 0.1064453125,
      "reference_rejected": 0.146484375,
      "gradient_norm": 1.0913077592849731,
      "seconds": 0.2402379050035961
    },
    {
      "step": 26,
      "pair": 1,
      "loss": 0.29586997628211975,
      "action_loss": 0.1650390625,
      "reference_rejected": 0.15234375,
      "gradient_norm": 0.6013530492782593,
      "seconds": 0.24364369100658223
    },
    {
      "step": 27,
      "pair": 2,
      "loss": 0.1595393866300583,
      "action_loss": 0.0751953125,
      "reference_rejected": 0.150390625,
      "gradient_norm": 0.9325050115585327,
      "seconds": 0.2408332680060994
    },
    {
      "step": 28,
      "pair": 3,
      "loss": 0.3414720594882965,
      "action_loss": 0.1923828125,
      "reference_rejected": 0.0751953125,
      "gradient_norm": 0.8415565490722656,
      "seconds": 0.2421729940106161
    },
    {
      "step": 29,
      "pair": 0,
      "loss": 0.21023443341255188,
      "action_loss": 0.14453125,
      "reference_rejected": 0.1806640625,
      "gradient_norm": 1.0183125734329224,
      "seconds": 0.24032367099425755
    },
    {
      "step": 30,
      "pair": 1,
      "loss": 0.2864847779273987,
      "action_loss": 0.150390625,
      "reference_rejected": 0.125,
      "gradient_norm": 0.7396087646484375,
      "seconds": 0.24006730799737852
    },
    {
      "step": 31,
      "pair": 2,
      "loss": 0.14856040477752686,
      "action_loss": 0.0712890625,
      "reference_rejected": 0.166015625,
      "gradient_norm": 0.8865151405334473,
      "seconds": 0.24309537300723605
    },
    {
      "step": 32,
      "pair": 3,
      "loss": 0.22048969566822052,
      "action_loss": 0.09912109375,
      "reference_rejected": 0.09228515625,
      "gradient_norm": 0.7733904719352722,
      "seconds": 0.24267369500012137
    },
    {
      "step": 33,
      "pair": 0,
      "loss": 0.21457228064537048,
      "action_loss": 0.1552734375,
      "reference_rejected": 0.1826171875,
      "gradient_norm": 0.9645161032676697,
      "seconds": 0.24181777499325108
    },
    {
      "step": 34,
      "pair": 1,
      "loss": 0.27862751483917236,
      "action_loss": 0.14453125,
      "reference_rejected": 0.13671875,
      "gradient_norm": 0.723305344581604,
      "seconds": 0.243281241011573
    },
    {
      "step": 35,
      "pair": 2,
      "loss": 0.12768007814884186,
      "action_loss": 0.05615234375,
      "reference_rejected": 0.1953125,
      "gradient_norm": 0.8499910235404968,
      "seconds": 0.24293024600774515
    },
    {
      "step": 36,
      "pair": 3,
      "loss": 0.2918207049369812,
      "action_loss": 0.171875,
      "reference_rejected": 0.2099609375,
      "gradient_norm": 0.8807322382926941,
      "seconds": 0.24168977299996186
    },
    {
      "step": 37,
      "pair": 0,
      "loss": 0.22228047251701355,
      "action_loss": 0.16796875,
      "reference_rejected": 0.251953125,
      "gradient_norm": 0.9300733208656311,
      "seconds": 0.2401988950005034
    },
    {
      "step": 38,
      "pair": 1,
      "loss": 0.2846307158470154,
      "action_loss": 0.1474609375,
      "reference_rejected": 0.13671875,
      "gradient_norm": 0.7269648313522339,
      "seconds": 0.24078123600338586
    },
    {
      "step": 39,
      "pair": 2,
      "loss": 0.1383453905582428,
      "action_loss": 0.0712890625,
      "reference_rejected": 0.12353515625,
      "gradient_norm": 0.8256557583808899,
      "seconds": 0.24068231899582315
    },
    {
      "step": 40,
      "pair": 3,
      "loss": 0.38133174180984497,
      "action_loss": 0.2255859375,
      "reference_rejected": 0.0830078125,
      "gradient_norm": 0.8064984679222107,
      "seconds": 0.24175056000240147
    },
    {
      "step": 41,
      "pair": 0,
      "loss": 0.1784123331308365,
      "action_loss": 0.1279296875,
      "reference_rejected": 0.1474609375,
      "gradient_norm": 0.8768625259399414,
      "seconds": 0.2399701480026124
    },
    {
      "step": 42,
      "pair": 1,
      "loss": 0.41827091574668884,
      "action_loss": 0.25390625,
      "reference_rejected": 0.142578125,
      "gradient_norm": 1.0163027048110962,
      "seconds": 0.24074205401120707
    },
    {
      "step": 43,
      "pair": 2,
      "loss": 0.2962172031402588,
      "action_loss": 0.232421875,
      "reference_rejected": 0.265625,
      "gradient_norm": 0.9015506505966187,
      "seconds": 0.24165833099687006
    },
    {
      "step": 44,
      "pair": 3,
      "loss": 0.2768954932689667,
      "action_loss": 0.142578125,
      "reference_rejected": 0.0859375,
      "gradient_norm": 0.8153175711631775,
      "seconds": 0.24044154900184367
    },
    {
      "step": 45,
      "pair": 0,
      "loss": 0.2489706575870514,
      "action_loss": 0.201171875,
      "reference_rejected": 0.244140625,
      "gradient_norm": 0.9122439026832581,
      "seconds": 0.24200007699255366
    },
    {
      "step": 46,
      "pair": 1,
      "loss": 0.260171502828598,
      "action_loss": 0.12060546875,
      "reference_rejected": 0.1142578125,
      "gradient_norm": 0.7704694271087646,
      "seconds": 0.23952622400247492
    },
    {
      "step": 47,
      "pair": 2,
      "loss": 0.1245284378528595,
      "action_loss": 0.0634765625,
      "reference_rejected": 0.1875,
      "gradient_norm": 0.8244878649711609,
      "seconds": 0.2438513770030113
    },
    {
      "step": 48,
      "pair": 3,
      "loss": 0.22599083185195923,
      "action_loss": 0.10595703125,
      "reference_rejected": 0.13671875,
      "gradient_norm": 0.8479007482528687,
      "seconds": 0.2414578879979672
    },
    {
      "step": 49,
      "pair": 0,
      "loss": 0.16333205997943878,
      "action_loss": 0.11767578125,
      "reference_rejected": 0.166015625,
      "gradient_norm": 0.8096809387207031,
      "seconds": 0.24137378799787257
    },
    {
      "step": 50,
      "pair": 1,
      "loss": 0.2895926833152771,
      "action_loss": 0.1474609375,
      "reference_rejected": 0.134765625,
      "gradient_norm": 0.802091121673584,
      "seconds": 0.24123764300020412
    },
    {
      "step": 51,
      "pair": 2,
      "loss": 0.1452016979455948,
      "action_loss": 0.0859375,
      "reference_rejected": 0.1640625,
      "gradient_norm": 0.768325924873352,
      "seconds": 0.239708741006325
    },
    {
      "step": 52,
      "pair": 3,
      "loss": 0.2514352798461914,
      "action_loss": 0.1318359375,
      "reference_rejected": 0.1474609375,
      "gradient_norm": 0.8444247245788574,
      "seconds": 0.24052028699952643
    },
    {
      "step": 53,
      "pair": 0,
      "loss": 0.18099099397659302,
      "action_loss": 0.13671875,
      "reference_rejected": 0.173828125,
      "gradient_norm": 0.7908195853233337,
      "seconds": 0.24249138400773518
    },
    {
      "step": 54,
      "pair": 1,
      "loss": 0.4132947623729706,
      "action_loss": 0.2490234375,
      "reference_rejected": 0.150390625,
      "gradient_norm": 0.9139080047607422,
      "seconds": 0.2401099209964741
    },
    {
      "step": 55,
      "pair": 2,
      "loss": 0.13459919393062592,
      "action_loss": 0.07666015625,
      "reference_rejected": 0.150390625,
      "gradient_norm": 0.7635355591773987,
      "seconds": 0.24235069399583153
    },
    {
      "step": 56,
      "pair": 3,
      "loss": 0.23621079325675964,
      "action_loss": 0.1142578125,
      "reference_rejected": 0.10205078125,
      "gradient_norm": 0.8243385553359985,
      "seconds": 0.24163772800238803
    },
    {
      "step": 57,
      "pair": 0,
      "loss": 0.20351693034172058,
      "action_loss": 0.16015625,
      "reference_rejected": 0.23828125,
      "gradient_norm": 0.7934105396270752,
      "seconds": 0.24103244800062384
    },
    {
      "step": 58,
      "pair": 1,
      "loss": 0.282781720161438,
      "action_loss": 0.1396484375,
      "reference_rejected": 0.1259765625,
      "gradient_norm": 0.7978271842002869,
      "seconds": 0.24094156800128985
    },
    {
      "step": 59,
      "pair": 2,
      "loss": 0.12008977681398392,
      "action_loss": 0.06298828125,
      "reference_rejected": 0.23046875,
      "gradient_norm": 0.7531439661979675,
      "seconds": 0.24202287298976444
    },
    {
      "step": 60,
      "pair": 3,
      "loss": 0.37535321712493896,
      "action_loss": 0.2255859375,
      "reference_rejected": 0.0986328125,
      "gradient_norm": 0.8711140155792236,
      "seconds": 0.24237956599972676
    },
    {
      "step": 61,
      "pair": 0,
      "loss": 0.2186039537191391,
      "action_loss": 0.17578125,
      "reference_rejected": 0.2353515625,
      "gradient_norm": 0.832362949848175,
      "seconds": 0.24001353098719846
    },
    {
      "step": 62,
      "pair": 1,
      "loss": 0.42087283730506897,
      "action_loss": 0.251953125,
      "reference_rejected": 0.134765625,
      "gradient_norm": 0.8552017211914062,
      "seconds": 0.24063037399901077
    },
    {
      "step": 63,
      "pair": 2,
      "loss": 0.12484528869390488,
      "action_loss": 0.068359375,
      "reference_rejected": 0.134765625,
      "gradient_norm": 0.7496599555015564,
      "seconds": 0.2384333129884908
    },
    {
      "step": 64,
      "pair": 3,
      "loss": 0.3862591087818146,
      "action_loss": 0.232421875,
      "reference_rejected": 0.08544921875,
      "gradient_norm": 0.828843891620636,
      "seconds": 0.24319993000244722
    },
    {
      "step": 65,
      "pair": 0,
      "loss": 0.18691928684711456,
      "action_loss": 0.14453125,
      "reference_rejected": 0.21875,
      "gradient_norm": 0.7791128158569336,
      "seconds": 0.24091561399109196
    },
    {
      "step": 66,
      "pair": 1,
      "loss": 0.391335666179657,
      "action_loss": 0.251953125,
      "reference_rejected": 0.28515625,
      "gradient_norm": 0.827459990978241,
      "seconds": 0.2415204239950981
    },
    {
      "step": 67,
      "pair": 2,
      "loss": 0.18803386390209198,
      "action_loss": 0.1318359375,
      "reference_rejected": 0.166015625,
      "gradient_norm": 0.8011276721954346,
      "seconds": 0.2398251519916812
    },
    {
      "step": 68,
      "pair": 3,
      "loss": 0.3553076386451721,
      "action_loss": 0.2060546875,
      "reference_rejected": 0.07373046875,
      "gradient_norm": 0.8031365871429443,
      "seconds": 0.2449080570077058
    },
    {
      "step": 69,
      "pair": 0,
      "loss": 0.17110174894332886,
      "action_loss": 0.12890625,
      "reference_rejected": 0.1953125,
      "gradient_norm": 0.7817614078521729,
      "seconds": 0.24026199500076473
    },
    {
      "step": 70,
      "pair": 1,
      "loss": 0.30190542340278625,
      "action_loss": 0.154296875,
      "reference_rejected": 0.119140625,
      "gradient_norm": 0.9993823766708374,
      "seconds": 0.24185043800389394
    },
    {
      "step": 71,
      "pair": 2,
      "loss": 0.14471502602100372,
      "action_loss": 0.0888671875,
      "reference_rejected": 0.15625,
      "gradient_norm": 0.7535051703453064,
      "seconds": 0.24164961899805348
    },
    {
      "step": 72,
      "pair": 3,
      "loss": 0.2971157133579254,
      "action_loss": 0.181640625,
      "reference_rejected": 0.22265625,
      "gradient_norm": 0.8631224632263184,
      "seconds": 0.23991079699771944
    },
    {
      "step": 73,
      "pair": 0,
      "loss": 0.17482316493988037,
      "action_loss": 0.1328125,
      "reference_rejected": 0.166015625,
      "gradient_norm": 0.785004198551178,
      "seconds": 0.24014969400013797
    },
    {
      "step": 74,
      "pair": 1,
      "loss": 0.29139965772628784,
      "action_loss": 0.1513671875,
      "reference_rejected": 0.14453125,
      "gradient_norm": 0.7805079817771912,
      "seconds": 0.2422425559925614
    },
    {
      "step": 75,
      "pair": 2,
      "loss": 0.11103203892707825,
      "action_loss": 0.055419921875,
      "reference_rejected": 0.1982421875,
      "gradient_norm": 0.7522176504135132,
      "seconds": 0.24284605699358508
    },
    {
      "step": 76,
      "pair": 3,
      "loss": 0.33802568912506104,
      "action_loss": 0.1943359375,
      "reference_rejected": 0.07666015625,
      "gradient_norm": 0.7894956469535828,
      "seconds": 0.24141588099882938
    },
    {
      "step": 77,
      "pair": 0,
      "loss": 0.17663441598415375,
      "action_loss": 0.134765625,
      "reference_rejected": 0.173828125,
      "gradient_norm": 0.773123025894165,
      "seconds": 0.2397373330022674
    },
    {
      "step": 78,
      "pair": 1,
      "loss": 0.35661840438842773,
      "action_loss": 0.2138671875,
      "reference_rejected": 0.1943359375,
      "gradient_norm": 0.7664303779602051,
      "seconds": 0.24038794200168923
    },
    {
      "step": 79,
      "pair": 2,
      "loss": 0.11325301229953766,
      "action_loss": 0.057861328125,
      "reference_rejected": 0.23046875,
      "gradient_norm": 0.7579853534698486,
      "seconds": 0.23877238300337922
    },
    {
      "step": 80,
      "pair": 3,
      "loss": 0.2478375881910324,
      "action_loss": 0.1279296875,
      "reference_rejected": 0.10205078125,
      "gradient_norm": 0.789045512676239,
      "seconds": 0.24113025500264484
    },
    {
      "step": 81,
      "pair": 0,
      "loss": 0.1291544884443283,
      "action_loss": 0.08740234375,
      "reference_rejected": 0.279296875,
      "gradient_norm": 0.7784899473190308,
      "seconds": 0.24256872800469864
    },
    {
      "step": 82,
      "pair": 1,
      "loss": 0.38741692900657654,
      "action_loss": 0.2412109375,
      "reference_rejected": 0.2060546875,
      "gradient_norm": 0.8982225656509399,
      "seconds": 0.24310609999520238
    },
    {
      "step": 83,
      "pair": 2,
      "loss": 0.12550456821918488,
      "action_loss": 0.0703125,
      "reference_rejected": 0.0869140625,
      "gradient_norm": 0.7509337663650513,
      "seconds": 0.2410086870077066
    },
    {
      "step": 84,
      "pair": 3,
      "loss": 0.2386176437139511,
      "action_loss": 0.1259765625,
      "reference_rejected": 0.130859375,
      "gradient_norm": 0.7798707485198975,
      "seconds": 0.24190821500087623
    },
    {
      "step": 85,
      "pair": 0,
      "loss": 0.15240277349948883,
      "action_loss": 0.11083984375,
      "reference_rejected": 0.1533203125,
      "gradient_norm": 0.7728163599967957,
      "seconds": 0.24068007098685484
    },
    {
      "step": 86,
      "pair": 1,
      "loss": 0.32562965154647827,
      "action_loss": 0.181640625,
      "reference_rejected": 0.1533203125,
      "gradient_norm": 0.7565914988517761,
      "seconds": 0.3269130280095851
    },
    {
      "step": 87,
      "pair": 2,
      "loss": 0.1472645401954651,
      "action_loss": 0.09228515625,
      "reference_rejected": 0.251953125,
      "gradient_norm": 0.7451356649398804,
      "seconds": 0.24292254100146238
    },
    {
      "step": 88,
      "pair": 3,
      "loss": 0.3134614825248718,
      "action_loss": 0.173828125,
      "reference_rejected": 0.06298828125,
      "gradient_norm": 0.804205060005188,
      "seconds": 0.24069300999690313
    },
    {
      "step": 89,
      "pair": 0,
      "loss": 0.15416184067726135,
      "action_loss": 0.11279296875,
      "reference_rejected": 0.19140625,
      "gradient_norm": 0.7696558833122253,
      "seconds": 0.2433680859976448
    },
    {
      "step": 90,
      "pair": 1,
      "loss": 0.27394023537635803,
      "action_loss": 0.13671875,
      "reference_rejected": 0.1337890625,
      "gradient_norm": 0.766057014465332,
      "seconds": 0.24195787399366964
    },
    {
      "step": 91,
      "pair": 2,
      "loss": 0.11423549801111221,
      "action_loss": 0.0595703125,
      "reference_rejected": 0.173828125,
      "gradient_norm": 0.7446437478065491,
      "seconds": 0.240265503001865
    },
    {
      "step": 92,
      "pair": 3,
      "loss": 0.2695643901824951,
      "action_loss": 0.158203125,
      "reference_rejected": 0.1611328125,
      "gradient_norm": 0.7858551740646362,
      "seconds": 0.238258023004164
    },
    {
      "step": 93,
      "pair": 0,
      "loss": 0.16463853418827057,
      "action_loss": 0.12353515625,
      "reference_rejected": 0.1630859375,
      "gradient_norm": 0.7621092200279236,
      "seconds": 0.240785047004465
    },
    {
      "step": 94,
      "pair": 1,
      "loss": 0.25038325786590576,
      "action_loss": 0.1142578125,
      "reference_rejected": 0.166015625,
      "gradient_norm": 0.7588606476783752,
      "seconds": 0.23919483099598438
    },
    {
      "step": 95,
      "pair": 2,
      "loss": 0.14228534698486328,
      "action_loss": 0.087890625,
      "reference_rejected": 0.1552734375,
      "gradient_norm": 0.7524264454841614,
      "seconds": 0.24239943399152253
    },
    {
      "step": 96,
      "pair": 3,
      "loss": 0.23120667040348053,
      "action_loss": 0.1162109375,
      "reference_rejected": 0.09912109375,
      "gradient_norm": 0.7595395445823669,
      "seconds": 0.24043681599141564
    },
    {
      "step": 97,
      "pair": 0,
      "loss": 0.14401459693908691,
      "action_loss": 0.10302734375,
      "reference_rejected": 0.2578125,
      "gradient_norm": 0.8476660847663879,
      "seconds": 0.24303312199481297
    },
    {
      "step": 98,
      "pair": 1,
      "loss": 0.28422197699546814,
      "action_loss": 0.1484375,
      "reference_rejected": 0.1494140625,
      "gradient_norm": 0.7290078997612,
      "seconds": 0.24428425000223797
    },
    {
      "step": 99,
      "pair": 2,
      "loss": 0.14780433475971222,
      "action_loss": 0.09375,
      "reference_rejected": 0.1162109375,
      "gradient_norm": 0.7431808114051819,
      "seconds": 0.2452018160111038
    },
    {
      "step": 100,
      "pair": 3,
      "loss": 0.2168135643005371,
      "action_loss": 0.103515625,
      "reference_rejected": 0.09130859375,
      "gradient_norm": 0.754112184047699,
      "seconds": 0.2707163740124088
    },
    {
      "step": 101,
      "pair": 0,
      "loss": 0.14111965894699097,
      "action_loss": 0.1005859375,
      "reference_rejected": 0.1337890625,
      "gradient_norm": 0.7607742547988892,
      "seconds": 0.24318508700525854
    },
    {
      "step": 102,
      "pair": 1,
      "loss": 0.2980646789073944,
      "action_loss": 0.1533203125,
      "reference_rejected": 0.1162109375,
      "gradient_norm": 2.3832263946533203,
      "seconds": 0.24300283800403122
    },
    {
      "step": 103,
      "pair": 2,
      "loss": 0.11846113204956055,
      "action_loss": 0.06494140625,
      "reference_rejected": 0.259765625,
      "gradient_norm": 0.7355990409851074,
      "seconds": 0.2423734440089902
    },
    {
      "step": 104,
      "pair": 3,
      "loss": 0.2659657895565033,
      "action_loss": 0.150390625,
      "reference_rejected": 0.12890625,
      "gradient_norm": 0.7682446241378784,
      "seconds": 0.24141025499557145
    },
    {
      "step": 105,
      "pair": 0,
      "loss": 0.12503717839717865,
      "action_loss": 0.08544921875,
      "reference_rejected": 0.138671875,
      "gradient_norm": 0.7372674345970154,
      "seconds": 0.24252594899735413
    },
    {
      "step": 106,
      "pair": 1,
      "loss": 0.2910769581794739,
      "action_loss": 0.154296875,
      "reference_rejected": 0.1513671875,
      "gradient_norm": 0.8233096599578857,
      "seconds": 0.24551601499842945
    },
    {
      "step": 107,
      "pair": 2,
      "loss": 0.11755745857954025,
      "action_loss": 0.06494140625,
      "reference_rejected": 0.2255859375,
      "gradient_norm": 0.7285373210906982,
      "seconds": 0.2421787530038273
    },
    {
      "step": 108,
      "pair": 3,
      "loss": 0.31153514981269836,
      "action_loss": 0.201171875,
      "reference_rejected": 0.30078125,
      "gradient_norm": 0.948660671710968,
      "seconds": 0.24090666600386612
    },
    {
      "step": 109,
      "pair": 0,
      "loss": 0.11929549276828766,
      "action_loss": 0.08056640625,
      "reference_rejected": 0.263671875,
      "gradient_norm": 0.726929247379303,
      "seconds": 0.24134017199685331
    },
    {
      "step": 110,
      "pair": 1,
      "loss": 0.2749229371547699,
      "action_loss": 0.138671875,
      "reference_rejected": 0.142578125,
      "gradient_norm": 0.7525807023048401,
      "seconds": 0.2417235949978931
    },
    {
      "step": 111,
      "pair": 2,
      "loss": 0.27777770161628723,
      "action_loss": 0.2255859375,
      "reference_rejected": 0.23828125,
      "gradient_norm": 0.7395929098129272,
      "seconds": 0.24060740899585653
    },
    {
      "step": 112,
      "pair": 3,
      "loss": 0.3234946131706238,
      "action_loss": 0.185546875,
      "reference_rejected": 0.07373046875,
      "gradient_norm": 0.7486651539802551,
      "seconds": 0.241954529992654
    },
    {
      "step": 113,
      "pair": 0,
      "loss": 0.1886644810438156,
      "action_loss": 0.150390625,
      "reference_rejected": 0.26953125,
      "gradient_norm": 1.0202088356018066,
      "seconds": 0.24121156199544203
    },
    {
      "step": 114,
      "pair": 1,
      "loss": 0.2895359694957733,
      "action_loss": 0.1533203125,
      "reference_rejected": 0.1826171875,
      "gradient_norm": 0.7674070596694946,
      "seconds": 0.2429133109981194
    },
    {
      "step": 115,
      "pair": 2,
      "loss": 0.12131951004266739,
      "action_loss": 0.06982421875,
      "reference_rejected": 0.09716796875,
      "gradient_norm": 0.729731559753418,
      "seconds": 0.23943199499626644
    },
    {
      "step": 116,
      "pair": 3,
      "loss": 0.2780246436595917,
      "action_loss": 0.16796875,
      "reference_rejected": 0.1669921875,
      "gradient_norm": 0.7915618419647217,
      "seconds": 0.24191269199945964
    },
    {
      "step": 117,
      "pair": 0,
      "loss": 0.16087721288204193,
      "action_loss": 0.123046875,
      "reference_rejected": 0.171875,
      "gradient_norm": 0.7249718904495239,
      "seconds": 0.24113176799437497
    },
    {
      "step": 118,
      "pair": 1,
      "loss": 0.24672642350196838,
      "action_loss": 0.11083984375,
      "reference_rejected": 0.14453125,
      "gradient_norm": 0.7457945346832275,
      "seconds": 0.24226700099825393
    },
    {
      "step": 119,
      "pair": 2,
      "loss": 0.12936632335186005,
      "action_loss": 0.078125,
      "reference_rejected": 0.1796875,
      "gradient_norm": 0.7268080115318298,
      "seconds": 0.2418213610071689
    },
    {
      "step": 120,
      "pair": 3,
      "loss": 0.24654623866081238,
      "action_loss": 0.1259765625,
      "reference_rejected": 0.080078125,
      "gradient_norm": 0.7509738802909851,
      "seconds": 0.24332203999802005
    },
    {
      "step": 121,
      "pair": 0,
      "loss": 0.14116409420967102,
      "action_loss": 0.103515625,
      "reference_rejected": 0.12451171875,
      "gradient_norm": 0.7358688712120056,
      "seconds": 0.2410163340100553
    },
    {
      "step": 122,
      "pair": 1,
      "loss": 0.2574862539768219,
      "action_loss": 0.1220703125,
      "reference_rejected": 0.1416015625,
      "gradient_norm": 0.7294867038726807,
      "seconds": 0.24659767099365126
    },
    {
      "step": 123,
      "pair": 2,
      "loss": 0.12134262174367905,
      "action_loss": 0.0703125,
      "reference_rejected": 0.1767578125,
      "gradient_norm": 0.7328147292137146,
      "seconds": 0.24455576000036672
    },
    {
      "step": 124,
      "pair": 3,
      "loss": 0.2280275523662567,
      "action_loss": 0.11376953125,
      "reference_rejected": 0.0908203125,
      "gradient_norm": 0.7515011429786682,
      "seconds": 0.2518824250000762
    },
    {
      "step": 125,
      "pair": 0,
      "loss": 0.12881527841091156,
      "action_loss": 0.09130859375,
      "reference_rejected": 0.267578125,
      "gradient_norm": 0.7668105959892273,
      "seconds": 0.24235666399181355
    },
    {
      "step": 126,
      "pair": 1,
      "loss": 0.2615741789340973,
      "action_loss": 0.12353515625,
      "reference_rejected": 0.111328125,
      "gradient_norm": 0.7458035945892334,
      "seconds": 0.2436252760089701
    },
    {
      "step": 127,
      "pair": 2,
      "loss": 0.14956964552402496,
      "action_loss": 0.0986328125,
      "reference_rejected": 0.201171875,
      "gradient_norm": 0.7283995151519775,
      "seconds": 0.24059150701214094
    },
    {
      "step": 128,
      "pair": 3,
      "loss": 0.24177220463752747,
      "action_loss": 0.1337890625,
      "reference_rejected": 0.232421875,
      "gradient_norm": 0.7837532758712769,
      "seconds": 0.24199564800073858
    }
  ],
  "independent_evaluation": false,
  "modality": "missing",
  "scope": "two training seeds, four local action decisions; capability fit only, not recovery or generalization"
}
```
