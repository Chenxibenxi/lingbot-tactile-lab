# VLA局部动作学习首轮

实际更新触觉时序适配器和动作条件接触头，主干冻结。micro-batch=1，global-batch=1，AdamW学习率1e-4，上限8次更新。四个训练决策循环两遍，各步固定噪声与训练前参考；辅助权重0.1、排序权重0.25。此为训练能力试验，尚无匹配对照或独立仿真评测；不同步的样本和噪声不同，曲线不可直接视为收敛趋势。

![loss](loss.png)

```json
{
  "status": "completed",
  "error": null,
  "optimizer_steps": 8,
  "elapsed_seconds": 29.600502729415894,
  "rows": [
    {
      "step": 1,
      "pair": 0,
      "loss": 0.42349615693092346,
      "action_loss": 0.2412109375,
      "reference_rejected": 0.2412109375,
      "gradient_norm": 1.4002221822738647,
      "seconds": 0.3775466429942753
    },
    {
      "step": 2,
      "pair": 1,
      "loss": 0.40391528606414795,
      "action_loss": 0.240234375,
      "reference_rejected": 0.2119140625,
      "gradient_norm": 0.7124277949333191,
      "seconds": 0.2416254590061726
    },
    {
      "step": 3,
      "pair": 2,
      "loss": 0.21754226088523865,
      "action_loss": 0.0654296875,
      "reference_rejected": 0.1455078125,
      "gradient_norm": 1.0194931030273438,
      "seconds": 0.24052483000559732
    },
    {
      "step": 4,
      "pair": 3,
      "loss": 0.2918992340564728,
      "action_loss": 0.1376953125,
      "reference_rejected": 0.1484375,
      "gradient_norm": 0.8776595592498779,
      "seconds": 0.23832128000503872
    },
    {
      "step": 5,
      "pair": 0,
      "loss": 0.33168336749076843,
      "action_loss": 0.203125,
      "reference_rejected": 0.2314453125,
      "gradient_norm": 1.1882137060165405,
      "seconds": 0.2411281050008256
    },
    {
      "step": 6,
      "pair": 1,
      "loss": 0.41538822650909424,
      "action_loss": 0.25390625,
      "reference_rejected": 0.1806640625,
      "gradient_norm": 1.68355393409729,
      "seconds": 0.23943125100049656
    },
    {
      "step": 7,
      "pair": 2,
      "loss": 0.22945116460323334,
      "action_loss": 0.11572265625,
      "reference_rejected": 0.14453125,
      "gradient_norm": 0.9038814902305603,
      "seconds": 0.24023211099847686
    },
    {
      "step": 8,
      "pair": 3,
      "loss": 0.2984103262424469,
      "action_loss": 0.1494140625,
      "reference_rejected": 0.134765625,
      "gradient_norm": 0.8897081017494202,
      "seconds": 0.23954700600006618
    }
  ],
  "independent_evaluation": false,
  "scope": "two training seeds, four local action decisions; capability fit only, not recovery or generalization"
}
```
