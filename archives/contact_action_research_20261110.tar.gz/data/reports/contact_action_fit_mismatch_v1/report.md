# VLA局部动作学习对照：mismatch

实际更新触觉时序适配器和动作条件接触头，主干冻结。micro-batch=1，global-batch=1，AdamW学习率1e-4，上限8次更新。四个训练决策循环两遍，各步固定噪声与训练前参考；辅助权重0.1、排序权重0.25。此为训练能力试验，尚无匹配对照或独立仿真评测；不同步的样本和噪声不同，曲线不可直接视为收敛趋势。

![loss](loss.png)

```json
{
  "status": "completed",
  "error": null,
  "optimizer_steps": 8,
  "elapsed_seconds": 29.413158416748047,
  "rows": [
    {
      "step": 1,
      "pair": 0,
      "loss": 0.4233502745628357,
      "action_loss": 0.2412109375,
      "reference_rejected": 0.24609375,
      "gradient_norm": 1.393627405166626,
      "seconds": 0.3239151810121257
    },
    {
      "step": 2,
      "pair": 1,
      "loss": 0.40878209471702576,
      "action_loss": 0.244140625,
      "reference_rejected": 0.2119140625,
      "gradient_norm": 0.7178546786308289,
      "seconds": 0.24099403400032315
    },
    {
      "step": 3,
      "pair": 2,
      "loss": 0.21726086735725403,
      "action_loss": 0.06494140625,
      "reference_rejected": 0.1435546875,
      "gradient_norm": 1.0209907293319702,
      "seconds": 0.23789536299591418
    },
    {
      "step": 4,
      "pair": 3,
      "loss": 0.2909758687019348,
      "action_loss": 0.13671875,
      "reference_rejected": 0.1484375,
      "gradient_norm": 0.8754345178604126,
      "seconds": 0.24245920300018042
    },
    {
      "step": 5,
      "pair": 0,
      "loss": 0.33175423741340637,
      "action_loss": 0.203125,
      "reference_rejected": 0.232421875,
      "gradient_norm": 1.1980620622634888,
      "seconds": 0.23898726499464829
    },
    {
      "step": 6,
      "pair": 1,
      "loss": 0.41542109847068787,
      "action_loss": 0.25390625,
      "reference_rejected": 0.1806640625,
      "gradient_norm": 1.686354160308838,
      "seconds": 0.24122991198964883
    },
    {
      "step": 7,
      "pair": 2,
      "loss": 0.22971004247665405,
      "action_loss": 0.11572265625,
      "reference_rejected": 0.14453125,
      "gradient_norm": 0.9062840938568115,
      "seconds": 0.24014585198892746
    },
    {
      "step": 8,
      "pair": 3,
      "loss": 0.2959604263305664,
      "action_loss": 0.1474609375,
      "reference_rejected": 0.134765625,
      "gradient_norm": 0.9054089188575745,
      "seconds": 0.24598483899899293
    }
  ],
  "independent_evaluation": false,
  "modality": "mismatch",
  "scope": "two training seeds, four local action decisions; capability fit only, not recovery or generalization"
}
```
