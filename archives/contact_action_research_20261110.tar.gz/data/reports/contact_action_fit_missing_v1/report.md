# VLA局部动作学习对照：missing

实际更新触觉时序适配器和动作条件接触头，主干冻结。micro-batch=1，global-batch=1，AdamW学习率1e-4，上限8次更新。四个训练决策循环两遍，各步固定噪声与训练前参考；辅助权重0.1、排序权重0.25。此为训练能力试验，尚无匹配对照或独立仿真评测；不同步的样本和噪声不同，曲线不可直接视为收敛趋势。

![loss](loss.png)

```json
{
  "status": "completed",
  "error": null,
  "optimizer_steps": 8,
  "elapsed_seconds": 30.823909521102905,
  "rows": [
    {
      "step": 1,
      "pair": 0,
      "loss": 0.40397173166275024,
      "action_loss": 0.22265625,
      "reference_rejected": 0.2255859375,
      "gradient_norm": 1.6885790824890137,
      "seconds": 0.32008576799125876
    },
    {
      "step": 2,
      "pair": 1,
      "loss": 0.3662674129009247,
      "action_loss": 0.208984375,
      "reference_rejected": 0.1826171875,
      "gradient_norm": 0.743169367313385,
      "seconds": 0.2666666709992569
    },
    {
      "step": 3,
      "pair": 2,
      "loss": 0.23111461102962494,
      "action_loss": 0.0634765625,
      "reference_rejected": 0.177734375,
      "gradient_norm": 1.2633994817733765,
      "seconds": 0.24237115900905337
    },
    {
      "step": 4,
      "pair": 3,
      "loss": 0.31172892451286316,
      "action_loss": 0.158203125,
      "reference_rejected": 0.134765625,
      "gradient_norm": 0.9343484044075012,
      "seconds": 0.23835457900713664
    },
    {
      "step": 5,
      "pair": 0,
      "loss": 0.33157703280448914,
      "action_loss": 0.1806640625,
      "reference_rejected": 0.234375,
      "gradient_norm": 1.5345057249069214,
      "seconds": 0.24295195800368674
    },
    {
      "step": 6,
      "pair": 1,
      "loss": 0.45126810669898987,
      "action_loss": 0.28125,
      "reference_rejected": 0.162109375,
      "gradient_norm": 1.0543839931488037,
      "seconds": 0.24154676200123504
    },
    {
      "step": 7,
      "pair": 2,
      "loss": 0.26255467534065247,
      "action_loss": 0.115234375,
      "reference_rejected": 0.1396484375,
      "gradient_norm": 1.2064342498779297,
      "seconds": 0.24012333899736404
    },
    {
      "step": 8,
      "pair": 3,
      "loss": 0.33387452363967896,
      "action_loss": 0.181640625,
      "reference_rejected": 0.1259765625,
      "gradient_norm": 0.8670505881309509,
      "seconds": 0.24003642100433353
    }
  ],
  "independent_evaluation": false,
  "modality": "missing",
  "scope": "two training seeds, four local action decisions; capability fit only, not recovery or generalization"
}
```
